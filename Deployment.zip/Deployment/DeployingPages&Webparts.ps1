﻿$siteCollectionURL = "https://winwireinc.sharepoint.com/sites/GileadESRDev"
$credentials =  (Get-Credential)
Connect-PnPOnline -Url $siteCollectionURL -Credentials $credentials

$csvInput = Import-Csv C:\Deployment\createModernPageTest.csv 

foreach ($input in $csvInput) {

$pageExisit=Get-PnPClientSidePage $input.PageName
if($pageExisit -and ($input.PageName=$pageExisit.PageTitle))
{


 Add-PnPClientSideWebPart -Page $input.PageName -DefaultWebPartType $input.WebPartName 
 Set-PnPClientSidePage -Identity $input.PageName  -Publish:$true
 
  }
    else
    {
    Add-PnPClientSidePage -Name $input.PageName -CommentsEnabled:$false     
    Add-PnPClientSidePageSection -Page $input.PageName -SectionTemplate $input.SectionTemplate
    Add-PnPClientSideWebPart -Page $input.PageName -DefaultWebPartType $input.WebPartName 
    $pageExisit=Get-PnPClientSidePage $input.PageName
    if(-not($pageExisit.PageTitle -eq "Enroll1") -and -not($pageExisit.PageTitle -eq "Approve-Reject1"))
    {
    Set-PnPListItemPermission -List 'SitePages' -Identity $pageExisit.PageId -InheritPermissions:$false 
   Set-PnPListItemPermission -List 'SitePages' -Identity $pageExisit.PageId  -Group 'GileadESRDev Visitors' -ClearExisting
   Set-PnPListItemPermission -List 'SitePages' -Identity $pageExisit.PageId -AddRole 'Full Control' -Group 'GileadESRA PowerUsers'
    }
    }
}
  