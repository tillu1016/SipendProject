﻿Param(
 [Parameter(Mandatory=$true)]
 [string]$siteCollectionURL
 
 )
$credentials =  (Get-Credential)
Connect-PnPOnline -Url $siteCollectionURL -Credentials $credentials
$currentTime= $(get-date).ToString("yyyyMMddHHmmss")
$logFile = "\$currentTime LogReport.csv" 
$csvInput = Import-Csv C:\Deployment\createModernPageTest.csv 

foreach ($input in $csvInput) {

try{

$pageExisit=Get-PnPClientSidePage $input.PageName
if($pageExisit -and ($input.PageName=$pageExisit.PageTitle))
{
 write-host "$($input.WebPartName )"

 Add-PnPClientSideWebPart -Page $input.PageName -Component $input.WebPartName -Order $input.Order
 Set-PnPClientSidePage -Identity $input.PageName  -Publish:$true
 
  }
    else
    {
    Add-PnPClientSidePage -Name $input.PageName -CommentsEnabled:$false     
    Add-PnPClientSidePageSection -Page $input.PageName -SectionTemplate $input.SectionTemplate
    Add-PnPClientSideWebPart -Page $input.PageName -Component $input.WebPartName -Order $input.Order
    $pageExisit=Get-PnPClientSidePage $input.PageName
    if(-not($pageExisit.PageTitle -eq "Enroll") -and -not($pageExisit.PageTitle -eq "Approve-Reject"))
    {
    Set-PnPListItemPermission -List 'SitePages' -Identity $pageExisit.PageId -InheritPermissions:$false 
   Set-PnPListItemPermission -List 'SitePages' -Identity $pageExisit.PageId  -Group 'GileadESRDev Visitors' -ClearExisting
   Set-PnPListItemPermission -List 'SitePages' -Identity $pageExisit.PageId -AddRole 'Full Control' -Group 'GileadESRA PowerUsers'
    }
    }
    }
    Catch  
        {   
            add-content $logFile  "$($siteCollectionURL),No , $($_.Exception.Message)"   
            Continue;  
        } 
}

 