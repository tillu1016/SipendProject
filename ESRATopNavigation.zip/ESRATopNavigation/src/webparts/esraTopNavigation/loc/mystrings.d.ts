declare interface IEsraTopNavigationWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'EsraTopNavigationWebPartStrings' {
  const strings: IEsraTopNavigationWebPartStrings;
  export = strings;
}
