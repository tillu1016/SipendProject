import * as React from 'react';
import styles from './EsraTopNavigation.module.scss';
import { IEsraTopNavigationProps } from './IEsraTopNavigationProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { sp } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/navigation";
import {​​​​​ CommandBar }​​​​​ from'office-ui-fabric-react/lib/CommandBar';
import {​​​​​ IContextualMenuItem }​​​​​ from"office-ui-fabric-react/lib/ContextualMenu";

export interface ITopNavigation {
  TopNavigationItems:IContextualMenuItem[];
​
 }

export default class EsraTopNavigation extends React.Component<IEsraTopNavigationProps,ITopNavigation, {}> {
  constructor(props){
    super(props);   
    
    sp.setup({
      sp: {
        baseUrl:this.props.context.pageContext.web.absoluteUrl
        
      },
    });
    this.state={TopNavigationItems:[]};
    this.getNavigation();
  }

  
  public async getNavigation()
  {
    const TopNavLinks = await sp.web.navigation.quicklaunch();
console.log(TopNavLinks)
    const  NavigationLinks: IContextualMenuItem[]= [];
    var i = 0;
    var numLinkItems=TopNavLinks.length
  
    TopNavLinks.forEach(element => {	
      i++;
if(numLinkItems==i){
  NavigationLinks.push({  key: element.Id.toString(), text:element.Title,href:element.Url,target:"_blank"  });

}else{
  NavigationLinks.push({  key: element.Id.toString(), text:element.Title,href:element.Url,target:"_blank"  });
  NavigationLinks.push({key:"",text:"|"})
    }
      });
     
      this.setState({TopNavigationItems:NavigationLinks});
  }

  public render(): React.ReactElement<IEsraTopNavigationProps> {
    
    return (
      <div className={ styles.esraTopNavigation }>
        <div className={ styles.container }>
          <div className={ styles.row }>
          <div>
            <div  style={{color: "white",backgroundColor: "#dc002f",height:25,paddingLeft:10,paddingBottom:10,paddingTop:10}}>Mobile Access Management</div>
                   
        <CommandBar items={this.state.TopNavigationItems} className={ styles.commandBarStyle }  />
        </div>
          </div>
        </div>
      </div>
    );
  }
}
