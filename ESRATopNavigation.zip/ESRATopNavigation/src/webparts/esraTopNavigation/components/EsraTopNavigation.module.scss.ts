/* tslint:disable */
require("./EsraTopNavigation.module.css");
const styles = {
  esraTopNavigation: 'esraTopNavigation_d4a6f5d3',
  container: 'container_d4a6f5d3',
  commandBarStyle: 'commandBarStyle_d4a6f5d3',
  row: 'row_d4a6f5d3',
  column: 'column_d4a6f5d3',
  'ms-Grid': 'ms-Grid_d4a6f5d3',
  title: 'title_d4a6f5d3',
  subTitle: 'subTitle_d4a6f5d3',
  description: 'description_d4a6f5d3',
  button: 'button_d4a6f5d3',
  label: 'label_d4a6f5d3'
};

export default styles;
/* tslint:enable */