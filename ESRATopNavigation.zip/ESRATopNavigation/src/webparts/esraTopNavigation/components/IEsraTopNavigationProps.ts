import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IEsraTopNavigationProps {
  description: string;
  context:WebPartContext;
}
