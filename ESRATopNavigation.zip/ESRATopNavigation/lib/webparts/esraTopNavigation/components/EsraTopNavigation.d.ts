import * as React from 'react';
import { IEsraTopNavigationProps } from './IEsraTopNavigationProps';
import "@pnp/sp/webs";
import "@pnp/sp/navigation";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
export interface ITopNavigation {
    TopNavigationItems: IContextualMenuItem[];
}
export default class EsraTopNavigation extends React.Component<IEsraTopNavigationProps, ITopNavigation, {}> {
    constructor(props: any);
    getNavigation(): Promise<void>;
    render(): React.ReactElement<IEsraTopNavigationProps>;
}
//# sourceMappingURL=EsraTopNavigation.d.ts.map