declare const styles: {
    esraTopNavigation: string;
    container: string;
    commandBarStyle: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
};
export default styles;
//# sourceMappingURL=EsraTopNavigation.module.scss.d.ts.map