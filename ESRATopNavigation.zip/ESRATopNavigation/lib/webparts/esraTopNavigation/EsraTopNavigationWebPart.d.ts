import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart, WebPartContext } from '@microsoft/sp-webpart-base';
export interface IEsraTopNavigationWebPartProps {
    description: string;
    context: WebPartContext;
}
export default class EsraTopNavigationWebPart extends BaseClientSideWebPart<IEsraTopNavigationWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=EsraTopNavigationWebPart.d.ts.map