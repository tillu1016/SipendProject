import * as React from 'react';
import { IEsraBenefeciaryDetailProps } from './IEsraBenefeciaryDetailProps';
export interface IWelcomeMessage {
    WelcomeMessage: string;
    CurrentUser: string;
}
export default class EsraBenefeciaryDetail extends React.Component<IEsraBenefeciaryDetailProps, IWelcomeMessage, {}> {
    private _LocationProperty;
    private _CurrUserCountry;
    private _ServicesInstance;
    private _userInstance;
    constructor(props: any);
    getUserPropertiesValue(Propertyname: string, Userprop: any): any;
    getCurrentUserData(): Promise<void>;
    getWelcomeMsg(UserCountry: string): Promise<void>;
    render(): React.ReactElement<IEsraBenefeciaryDetailProps>;
}
//# sourceMappingURL=EsraBenefeciaryDetail.d.ts.map