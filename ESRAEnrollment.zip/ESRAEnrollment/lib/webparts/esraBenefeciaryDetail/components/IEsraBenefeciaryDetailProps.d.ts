import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IEsraBenefeciaryDetailProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IEsraBenefeciaryDetailProps.d.ts.map