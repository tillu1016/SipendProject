import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart, WebPartContext } from '@microsoft/sp-webpart-base';
export interface IEsraBenefeciaryDetailWebPartProps {
    description: string;
    context: WebPartContext;
}
export default class EsraBenefeciaryDetailWebPart extends BaseClientSideWebPart<IEsraBenefeciaryDetailWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=EsraBenefeciaryDetailWebPart.d.ts.map