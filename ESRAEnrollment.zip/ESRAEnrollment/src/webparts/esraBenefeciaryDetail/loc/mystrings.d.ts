declare interface IEsraBenefeciaryDetailWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'EsraBenefeciaryDetailWebPartStrings' {
  const strings: IEsraBenefeciaryDetailWebPartStrings;
  export = strings;
}
