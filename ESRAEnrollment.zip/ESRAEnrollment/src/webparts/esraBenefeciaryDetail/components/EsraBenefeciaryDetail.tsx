import * as React from 'react';
import styles from './EsraBenefeciaryDetail.module.scss';
import { IEsraBenefeciaryDetailProps } from './IEsraBenefeciaryDetailProps';
import { escape } from '@microsoft/sp-lodash-subset';
import {sp} from '@pnp/sp/presets/all';
import {ESRAListOperations, ESRAUserInfo} from 'esra-services'

export interface IWelcomeMessage {
  WelcomeMessage:string,
  CurrentUser:string
 }

export default class EsraBenefeciaryDetail extends React.Component<IEsraBenefeciaryDetailProps,IWelcomeMessage, {}> {
  
  private _LocationProperty: string="Office";
  private _CurrUserCountry:string="";
  private _ServicesInstance;
  private _userInstance;

  constructor(props){
    super(props);   
    
    sp.setup({
      sp: {
        baseUrl:this.props.context.pageContext.web.absoluteUrl
        
      },
    });
    this._ServicesInstance=new ESRAListOperations(this.props.context.pageContext.web.absoluteUrl);
    this,this._userInstance=new ESRAUserInfo(this.props.context.pageContext.web.absoluteUrl);
    this.state={WelcomeMessage:"",CurrentUser:""};   
    this.getCurrentUserData()
  }
 
  public   getUserPropertiesValue(Propertyname:string,Userprop:any): any{
    try{
let propval :string ="";
        var userProperties = Userprop.UserProfileProperties;  
        var userPropertyValues = "";  
        userProperties.forEach(function(property) {  
        
            if(property.Key === Propertyname)
            {
                propval =  property.Value;
            }  
        });  
        
          return propval;       
        
    } catch (error) {
        console.log(error);
        throw error;
    }
  }

  public async getCurrentUserData(){
    try{
      
      await  this._userInstance.getCurrentUserInfo().then((result)=>{
          this.setState({CurrentUser:result.DisplayName});
console.log(this._LocationProperty);
          this._CurrUserCountry = this.getUserPropertiesValue(this._LocationProperty,result);
          this.getWelcomeMsg( this._CurrUserCountry);
          console.log(this._CurrUserCountry);
          
        });
    } catch (error) {
        console.log(error);
    }
}

public async getWelcomeMsg(UserCountry:string){
  var fields=[{key:"Key",fieldType:""},{key:"Value",fieldType:""},{key:"Country",fieldType:"SP.FieldLookup"}];
  
  
  this._ServicesInstance.getAllDataForSelectedFieldsByListTitle('Application Configuration',fields,"Country/Title eq '"+this._CurrUserCountry+"'").then((items)=>{

this.setState({WelcomeMessage:items[0].Value})
  })
          

}
  public render(): React.ReactElement<IEsraBenefeciaryDetailProps> {
    return (
      <div className={ styles.esraBenefeciaryDetail }>
        <div className={ styles.container }>
          <div className={ styles.row }>
            <div><b>Enrollment Stipend Request Application</b> (U.S. Personnel Only)</div>
            <div><b>Beneficiary</b> : {this.state.CurrentUser}</div>
            <div style={{padding:10}}> {this.state.WelcomeMessage}</div>
          </div>
        </div>
      </div>
    );
  }
}
