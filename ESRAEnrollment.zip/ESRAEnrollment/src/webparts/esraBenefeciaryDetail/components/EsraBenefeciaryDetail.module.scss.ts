/* tslint:disable */
require("./EsraBenefeciaryDetail.module.css");
const styles = {
  esraBenefeciaryDetail: 'esraBenefeciaryDetail_86867cde',
  container: 'container_86867cde',
  row: 'row_86867cde',
  column: 'column_86867cde',
  'ms-Grid': 'ms-Grid_86867cde',
  title: 'title_86867cde',
  subTitle: 'subTitle_86867cde',
  description: 'description_86867cde',
  button: 'button_86867cde',
  label: 'label_86867cde'
};

export default styles;
/* tslint:enable */