export declare abstract class EmailService {
    static sendEmail(emailFrom: string, emailTo: string[], emailCC: string[], emailSubject: string, emailBody: string): Promise<boolean>;
}
//# sourceMappingURL=EmailService.d.ts.map