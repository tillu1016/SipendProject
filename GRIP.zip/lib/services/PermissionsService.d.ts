export declare abstract class PermissionsService {
    static isCurrentUserMemberOfGroup(groupName: any): Promise<boolean>;
    static getGroupMembers(groupName: any): Promise<any>;
}
//# sourceMappingURL=PermissionsService.d.ts.map