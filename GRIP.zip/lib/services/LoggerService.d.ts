export declare abstract class LoggerService {
    static EnableConsoleLog: boolean;
    static auditLog: (message: string, functionName: string) => Promise<any>;
    static errorLog: (error: any, functionName: string) => void;
    private static LogEntryInDatabase;
}
//# sourceMappingURL=LoggerService.d.ts.map