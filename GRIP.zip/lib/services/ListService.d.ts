export declare abstract class ListService {
    static GetAllData: (list: string) => Promise<any>;
    static GetDataByCAML: (list: string, caml: string) => Promise<any>;
    static GetDataByCAMLStream: (list: string, caml: string) => Promise<any>;
    static GetDataByFilterWithExpand: (list: string, filterStr: string, selectStr: string, expandStr: string) => Promise<any>;
    static getDataFromLargeList: (list: string, camlQ: string) => Promise<any>;
    static GetDataByFilterWithExpandTop: (list: string, filterStr: string, selectStr: string, expandStr: string, top: number, orderBy: string, asc: boolean) => Promise<any>;
    static GetDataByFilter: (list: string, filterStr: string, selectStr: string) => Promise<any>;
    static GetDataByCAMLColExpand: (list: string, caml: string, colExpand: string) => Promise<any>;
    static PostListData: (data: any, list: string) => Promise<any>;
    static GetDataBySelect: (list: string, selectStr: string) => Promise<any>;
    static UpdateListDataByID: (list: string, itemId: number, data: any) => Promise<any>;
    static DeleteListDataByID: (itemId: number, list: string) => Promise<any>;
    static RecycleListDataByID: (itemId: number, list: string) => Promise<any>;
    static AddFile: (path: string, fileName: string, file: any, isOverWrite: boolean) => Promise<any>;
    static addFolder: (list: string, foldName: string) => Promise<any>;
    static PostImmediateEmail: (data: any, apiPath: string) => Promise<any>;
}
//# sourceMappingURL=ListService.d.ts.map