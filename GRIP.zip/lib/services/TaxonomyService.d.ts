import "@pnp/polyfill-ie11";
import { ITerm } from "@pnp/sp-taxonomy";
export declare abstract class TaxonomyService {
    static getTermSetByID(termSetId: string): Promise<ITerm[]>;
}
//# sourceMappingURL=TaxonomyService.d.ts.map