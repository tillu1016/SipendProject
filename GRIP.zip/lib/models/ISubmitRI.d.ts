export interface ISubmitRI {
    id: number;
    title: string;
    summary: string;
    body: string;
    status: string;
    approvalStatus: string;
    region: string;
    documentType: string;
    regulatoryTopic: string;
    therapeuticArea: string;
}
//# sourceMappingURL=ISubmitRI.d.ts.map