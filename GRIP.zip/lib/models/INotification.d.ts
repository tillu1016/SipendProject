export declare enum NotificationType {
    info = 1,
    warn = 2,
    error = 3,
    success = 4
}
export interface INotification {
    type: NotificationType;
    message: string;
}
//# sourceMappingURL=INotification.d.ts.map