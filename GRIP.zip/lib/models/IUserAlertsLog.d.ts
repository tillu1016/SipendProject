export declare enum UserAlertsLogFrequency {
    Immediately = "Immediately",
    Daily = "Daily",
    Weekly = "Weekly"
}
export declare enum UserAlertsLogStatus {
    New = "New",
    EmailSent = "Email Sent"
}
export interface IUserAlertsLog {
    id: number;
    title: string;
    alertItemId: number;
    frequency: string;
    status: string;
    users: string;
}
//# sourceMappingURL=IUserAlertsLog.d.ts.map