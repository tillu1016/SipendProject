export declare enum AlertIconType {
    View = "View",
    Edit = "Edit",
    Delete = "Delete",
    PDF = "PDF",
    Share = "Share"
}
export declare enum AlertStatus {
    Draft = "Draft",
    Submitted = "Submitted",
    SubmitForReview = "Submit For Review",
    Delete = "Delete",
    Approved = "Approved",
    Reviewed = "Reviewed",
    Publish = "Published",
    Unpublish = "Unpublished",
    Rejected = "Rejected"
}
export interface IAlert {
    id: number;
    title: string;
    impact: string;
    body: string;
    publicationDate: Date;
    status: string;
    approvalStatus: string;
    region: string;
    documentType: string;
    regulatoryTopic: string;
    therapeuticArea: string;
    meetAgStTime: Date;
    meetAgendaStartTime: string;
    meetAgEndTime: Date;
    meetAgendaEndTime: string;
    author: string;
    authorId: number;
    createdBy: string;
    createdById: number;
    createdByEmail: string;
}
//# sourceMappingURL=IAlert.d.ts.map