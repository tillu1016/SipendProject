export declare enum DateRangeType {
    DateRange = "Date Range",
    Year = "Year",
    Quarter = "Quarter",
    Month = "Month"
}
export declare enum CategoryType {
    Region = "Region",
    TherapeuticArea = "TherapeuticArea",
    RegulatoryTopic = "RegulatoryTopic",
    DocumentType = "DocumentType",
    Author = "Author"
}
//# sourceMappingURL=IMetricsDashboard.d.ts.map