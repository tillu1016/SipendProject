import * as React from 'react';
import { ISearchAuditingProps } from './ISearchAuditingProps';
export interface ISearchAuditingState {
    searchTerm: string;
}
export default class SearchAuditing extends React.Component<ISearchAuditingProps, ISearchAuditingState> {
    componentDidMount(): void;
    _hashchange(): void;
    _addAuditLog(seachTerm: any): void;
    render(): React.ReactElement<ISearchAuditingProps>;
}
//# sourceMappingURL=SearchAuditing.d.ts.map