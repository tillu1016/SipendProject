export interface ISearchAuditingProps {
    description: string;
}
//# sourceMappingURL=ISearchAuditingProps.d.ts.map