import "@pnp/polyfill-ie11";
import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IMetricsAndDashboardWebPartProps {
    description: string;
}
export default class MetricsAndDashboardWebPart extends BaseClientSideWebPart<IMetricsAndDashboardWebPartProps> {
    protected onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=MetricsAndDashboardWebPart.d.ts.map