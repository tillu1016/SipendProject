import * as React from 'react';
import { IMetricsAndDashboardProps } from './IMetricsAndDashboardProps';
import { IConfiguration } from '../../../models/IConfiguration';
interface IMetricsAndDashboardState {
    chartData: any[];
    allAlerts: any[];
    allSubscriptions: any[];
    configData: IConfiguration[];
}
export default class MetricsAndDashboard extends React.Component<IMetricsAndDashboardProps, IMetricsAndDashboardState> {
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IMetricsAndDashboardProps>;
    private updateCharts;
}
export {};
//# sourceMappingURL=MetricsAndDashboard.d.ts.map