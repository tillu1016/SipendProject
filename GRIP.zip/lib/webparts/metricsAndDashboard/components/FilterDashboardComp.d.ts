import * as React from 'react';
import { IConfiguration } from '../../../models/IConfiguration';
interface FilterDashboardCompState {
    alertCount: number;
    subsCount: number;
    immediateSubsCount: number;
    dailySubsCount: number;
    weeklySubsCount: number;
    alertRegionOptions: any[];
    alertTAOptions: any[];
    alertRegTopicOptions: any[];
    alertDocTypeOptions: any[];
    alertAuthorOptions: any[];
    selRegion: any[];
    selTA: any[];
    selRegTopic: any[];
    selDocType: any[];
    selAuthor: any[];
    yearOptions: any[];
    selDateRange: string;
    selYears: number[];
    selYear: number;
    selQuarter: number[];
    selMonth: number[];
    selFromDate: Date;
    selToDate: Date;
    disableApply: boolean;
}
interface FilterDashboardCompProps {
    webURL: string;
    updateCharts: any;
    allAlerts: any[];
    allSubscriptions: any[];
    configData: IConfiguration[];
}
export default class FilterDashboardComp extends React.Component<FilterDashboardCompProps, FilterDashboardCompState> {
    private _selRegionsObj;
    private _selTAObj;
    private _selRegTopicObj;
    private _selDocTypeObj;
    private _selAuthorObj;
    private _dateRngOptions;
    private _quarterOptions;
    private _monthOptions;
    constructor(props: any);
    componentDidUpdate(prevProps: FilterDashboardCompProps): void;
    componentDidMount(): void;
    render(): JSX.Element;
    private _onDDLRegionChange;
    private _onDDLTAChange;
    private _onDDLRegTopicChange;
    private _onDDLDocTypeChange;
    private _onDDLAuthorChange;
    private _onDDLDateRangeChange;
    private _onDDLYearChange;
    private _onDDLYearsChange;
    private _onDDLQuarterChange;
    private _onDDLMonthChange;
    private onApplyClick;
    private onClearClick;
    private updateCharts;
    private onFromDateSelect;
    private onToDateSelect;
    private getDistinctAutorAndYear;
    private setMultiselectState;
    private validate;
    private getAlertSubscriptionSummary;
    private setAlertSubscriptionSummaryState;
}
export {};
//# sourceMappingURL=FilterDashboardComp.d.ts.map