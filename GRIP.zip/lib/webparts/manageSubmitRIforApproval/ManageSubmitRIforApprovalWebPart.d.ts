import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { INotification } from "../../models/INotification";
import { IDynamicDataPropertyDefinition } from '@microsoft/sp-dynamic-data';
export interface IManageSubmitRIforApprovalWebPartProps {
    description: string;
}
export default class ManageSubmitRIforApprovalWebPart extends BaseClientSideWebPart<IManageSubmitRIforApprovalWebPartProps> {
    private _appNotification;
    render(): void;
    protected onInit(): Promise<void>;
    getPropertyDefinitions(): ReadonlyArray<IDynamicDataPropertyDefinition>;
    getPropertyValue(propertyId: string): boolean | INotification;
    private handleSetNotification;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=ManageSubmitRIforApprovalWebPart.d.ts.map