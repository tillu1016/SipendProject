import "@pnp/polyfill-ie11";
import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IDynamicDataPropertyDefinition } from '@microsoft/sp-dynamic-data';
export interface ISubscribetoAlertsWebPartProps {
    description: string;
    context: string;
}
export default class SubscribetoAlertsWebPart extends BaseClientSideWebPart<ISubscribetoAlertsWebPartProps> {
    private _appNotification;
    protected onInit(): Promise<void>;
    render(): void;
    getPropertyDefinitions(): ReadonlyArray<IDynamicDataPropertyDefinition>;
    private handleSetNotification;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=SubscribetoAlertsWebPart.d.ts.map