import { WebPartContext } from '@microsoft/sp-webpart-base';
import { INotification } from "../../../models/INotification";
export interface ISubscribetoAlertsProps {
    description: string;
    context: WebPartContext;
    webURL: string;
    onSetNotification: (notification: INotification) => void;
}
//# sourceMappingURL=ISubscribetoAlertsProps.d.ts.map