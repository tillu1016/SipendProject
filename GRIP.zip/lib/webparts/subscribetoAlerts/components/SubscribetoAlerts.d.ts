import * as React from 'react';
import { ISubscribetoAlertsProps } from './ISubscribetoAlertsProps';
export interface ISubscribetoAlertsState {
    alertRegionOptions: any[];
    hideAll: boolean;
    disableSignUpButton: boolean;
    hideSignUpDialog: boolean;
    isUserAdmin: boolean;
    isUserSubscribed: boolean;
    toolTipMessage: string;
    toolTipManageSubMessage: string;
    showErrorMessage: boolean;
}
export default class SubscribetoAlerts extends React.Component<ISubscribetoAlertsProps, ISubscribetoAlertsState> {
    private _configData;
    private _currUser;
    private _manageSubscriptionsURL;
    private _metricsAndDBURL;
    private _itemId;
    private _title;
    private _disableSignUpButton;
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<ISubscribetoAlertsProps>;
    private onSignUpClick;
    private onManageSubscriptionClick;
    private onMetricsAndDBClick;
    private closeDialog;
    private getSubscriptionsData;
    private submitPanelSignUp;
    private _prepUserSubscriptionEmail;
    private _sendEmail;
}
//# sourceMappingURL=SubscribetoAlerts.d.ts.map