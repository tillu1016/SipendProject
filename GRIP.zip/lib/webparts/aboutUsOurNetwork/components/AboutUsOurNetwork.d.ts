import * as React from 'react';
import { IAboutUsOurNetworkProps } from './IAboutUsOurNetworkProps';
interface AboutUsOurNetworkState {
    ourNetworkData: any;
}
export default class AboutUsOurNetwork extends React.Component<IAboutUsOurNetworkProps, AboutUsOurNetworkState> {
    private _configData;
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IAboutUsOurNetworkProps>;
    private getOurNetworkData;
}
export {};
//# sourceMappingURL=AboutUsOurNetwork.d.ts.map