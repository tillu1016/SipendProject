import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IAboutUsOurNetworkWebPartProps {
    description: string;
}
export default class AboutUsOurNetworkWebPart extends BaseClientSideWebPart<IAboutUsOurNetworkWebPartProps> {
    protected onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=AboutUsOurNetworkWebPart.d.ts.map