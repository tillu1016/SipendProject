import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IViewAlertsByRegionTaWebPartProps {
    description: string;
}
export default class ViewAlertsByRegionTaWebPart extends BaseClientSideWebPart<IViewAlertsByRegionTaWebPartProps> {
    protected onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=ViewAlertsByRegionTaWebPart.d.ts.map