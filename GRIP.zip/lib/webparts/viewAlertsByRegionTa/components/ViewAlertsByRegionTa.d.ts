import * as React from 'react';
import { IViewAlertsByRegionTaProps } from './IViewAlertsByRegionTaProps';
export interface IViewAlertsByRegionTaState {
    alertRegions: any[];
    alertTAs: any[];
    distCategories: any;
}
export default class ViewAlertsByRegionTa extends React.Component<IViewAlertsByRegionTaProps, IViewAlertsByRegionTaState> {
    private _configData;
    private _manageAlertsPage;
    private _regionImagePath;
    private _taImagePath;
    private _taOrder;
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IViewAlertsByRegionTaProps>;
    private onLinkClicked;
    private compare;
}
//# sourceMappingURL=ViewAlertsByRegionTa.d.ts.map