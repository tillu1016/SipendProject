import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IViewAlertsByRegionTaProps {
    context: WebPartContext;
    webURL: string;
}
//# sourceMappingURL=IViewAlertsByRegionTaProps.d.ts.map