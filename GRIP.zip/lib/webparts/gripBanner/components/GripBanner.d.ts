import * as React from 'react';
import { IGripBannerProps } from './IGripBannerProps';
interface IGripBannerState {
    bannerHTML: string;
}
export default class GripBanner extends React.Component<IGripBannerProps, IGripBannerState> {
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IGripBannerProps>;
}
export {};
//# sourceMappingURL=GripBanner.d.ts.map