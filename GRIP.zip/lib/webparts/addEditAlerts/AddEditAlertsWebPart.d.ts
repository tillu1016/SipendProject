import "@pnp/polyfill-ie11";
import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { INotification } from "../../models/INotification";
import { IDynamicDataPropertyDefinition } from '@microsoft/sp-dynamic-data';
export interface IAddEditAlertsWebPartProps {
    context: string;
    listName: string;
}
export default class AddEditAlertsWebPart extends BaseClientSideWebPart<IAddEditAlertsWebPartProps> {
    private _appNotification;
    protected onInit(): Promise<void>;
    render(): void;
    getPropertyDefinitions(): ReadonlyArray<IDynamicDataPropertyDefinition>;
    getPropertyValue(propertyId: string): boolean | INotification;
    private handleSetNotification;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=AddEditAlertsWebPart.d.ts.map