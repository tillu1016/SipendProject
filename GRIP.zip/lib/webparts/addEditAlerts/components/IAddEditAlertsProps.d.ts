import { WebPartContext } from "@microsoft/sp-webpart-base";
import { INotification } from "../../../models/INotification";
export interface IAddEditAlertsProps {
    description: string;
    webURL: string;
    context: WebPartContext;
    listName: string;
    onSetNotification: (notification: INotification) => void;
}
//# sourceMappingURL=IAddEditAlertsProps.d.ts.map