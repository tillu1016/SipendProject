declare const styles: {
    manageSubscriptions: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
    hideelement: string;
};
export default styles;
//# sourceMappingURL=ManageSubscriptions.module.scss.d.ts.map