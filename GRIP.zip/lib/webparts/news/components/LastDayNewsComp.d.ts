import * as React from 'react';
import { CurrentUser } from '@pnp/sp/src/siteusers';
import { WebPartContext } from "@microsoft/sp-webpart-base";
interface LastDayNewsCompState {
    isDataLoaded: boolean;
    todaysAlerts: any;
    isUserAdmin: boolean;
    hideUnpubDialog: boolean;
    alertRegion: any[];
    alertTA: any[];
    isEmpty: boolean;
    currentUser: CurrentUser;
    configData: any[];
    regTADataLoaded: boolean;
}
interface LastDayNewsCompProps {
    webURL: string;
    context: WebPartContext;
    alertRegion: any[];
    alertTA: any[];
    isUserAdmin: boolean;
    currentUser: CurrentUser;
    configData: any[];
    updateData: (type: string, data: any) => void;
    todaysAlerts: any;
    regTADataLoaded: boolean;
}
export default class LastDayNewsComp extends React.Component<LastDayNewsCompProps, LastDayNewsCompState> {
    private _itemId;
    constructor(props: any);
    componentDidMount(): void;
    componentDidUpdate(prevProps: LastDayNewsCompProps): void;
    render(): JSX.Element;
    private getLastDayAlerts;
    private onViewMoreClick;
    private onMenuClick;
    private unpublishAlert;
    private closeUnpubDialog;
    private getIcon;
}
export {};
//# sourceMappingURL=LastDayNewsComp.d.ts.map