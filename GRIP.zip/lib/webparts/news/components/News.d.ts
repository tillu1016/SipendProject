import * as React from 'react';
import { INewsProps } from './INewsProps';
import { CurrentUser } from '@pnp/sp/src/siteusers';
interface NewsCompState {
    isUserAdmin: boolean;
    alertRegion: any[];
    alertTA: any[];
    currentUser: CurrentUser;
    configData: any[];
    weeksAlerts: any;
    todaysAlerts: any;
    regTADataLoaded: boolean;
}
export default class News extends React.Component<INewsProps, NewsCompState> {
    constructor(props: any);
    render(): React.ReactElement<INewsProps>;
    componentDidMount(): void;
    private getTaxonomyData;
    private updateData;
}
export {};
//# sourceMappingURL=News.d.ts.map