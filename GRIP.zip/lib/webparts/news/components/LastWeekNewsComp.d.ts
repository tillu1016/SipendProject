import * as React from 'react';
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { CurrentUser } from '@pnp/sp/src/siteusers';
interface LastWeekNewsCompState {
    isDataLoaded: boolean;
    weeksAlerts: any;
    isUserAdmin: boolean;
    hideUnpubDialog: boolean;
    alertRegion: any[];
    alertTA: any[];
    isEmpty: boolean;
    currentUser: CurrentUser;
    configData: any[];
    regTADataLoaded: boolean;
}
interface LastWeekNewsCompProps {
    webURL: string;
    context: WebPartContext;
    alertRegion: any[];
    alertTA: any[];
    isUserAdmin: boolean;
    currentUser: CurrentUser;
    configData: any[];
    updateData: (type: string, data: any) => void;
    weeksAlerts: any;
    regTADataLoaded: boolean;
}
export default class LastWeekNewsComp extends React.Component<LastWeekNewsCompProps, LastWeekNewsCompState> {
    private _itemId;
    constructor(props: any);
    componentDidMount(): void;
    componentDidUpdate(prevProps: LastWeekNewsCompProps): void;
    render(): JSX.Element;
    private getLastWeekAlerts;
    private onViewMoreClick;
    private onMenuClick;
    private unpublishAlert;
    private closeUnpubDialog;
    private getIcon;
}
export {};
//# sourceMappingURL=LastWeekNewsComp.d.ts.map