import * as React from 'react';
import { IAboutUsVisionMissionProps } from './IAboutUsVisionMissionProps';
interface AboutUsVisionMissionState {
    displayText: string;
}
export default class AboutUsVisionMission extends React.Component<IAboutUsVisionMissionProps, AboutUsVisionMissionState> {
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IAboutUsVisionMissionProps>;
}
export {};
//# sourceMappingURL=AboutUsVisionMission.d.ts.map