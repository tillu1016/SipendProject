import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IAboutUsVisionMissionProps {
    context: WebPartContext;
    webURL: string;
    display: string;
}
//# sourceMappingURL=IAboutUsVisionMissionProps.d.ts.map