import * as React from 'react';
import { GridCellProps } from '@progress/kendo-react-grid';
export declare class GridColumnTitleLink extends React.Component<Readonly<GridCellProps>, {}> {
    render(): JSX.Element;
}
//# sourceMappingURL=GridColumnTitleLinkComp.d.ts.map