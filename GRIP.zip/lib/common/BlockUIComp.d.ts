import * as React from 'react';
interface BlockUICompProps {
    hideLoadingDialog: boolean;
    loadingText: string;
}
export default class BlockUIComp extends React.Component<BlockUICompProps> {
    render(): JSX.Element;
}
export {};
//# sourceMappingURL=BlockUIComp.d.ts.map