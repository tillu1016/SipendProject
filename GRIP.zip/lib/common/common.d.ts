import { CurrentUser } from '@pnp/sp/src/siteusers';
import { IConfiguration } from '../models/IConfiguration';
export declare abstract class Common {
    static pageSize: number;
    static isIE: boolean;
    static errorLogList: string;
    static auditLogList: string;
    static timeZone: string;
    static notificationErrMsg: string;
    static getCurrentUserId(): Promise<CurrentUser>;
    static getQueryStringValue: (paramName: string) => string;
    static getManagedMetadataString(fieldData: any[]): string;
    static getConfigData(): Promise<any>;
    static getTermSetData(configData: IConfiguration[], category: string, key: string): Promise<any>;
    static getConfigValue: (configData: IConfiguration[], category: string, key: string) => string;
    static getConfigRichTextValue: (configData: IConfiguration[], category: string, key: string) => string;
    static checkIfUserAdmin(groupName: string): Promise<boolean>;
    static deleteAlert(configData: IConfiguration[], category: string, key: string, itemId: number): Promise<boolean>;
    static recycleAlert(configData: IConfiguration[], category: string, key: string, itemId: number): Promise<boolean>;
    static modifyRelativeURL(data: string, textToReplace: string, replacedText: string): any;
    static getEmailTemplate(emailTmplList: string, templateName: string): Promise<any[]>;
    static getUserProfileProps(userLogin: string): Promise<any>;
    static logSiteVisit(listName: string, pageName: string, isAdmin: boolean, currUserId: number, alertId?: number): void;
    private static isFirstVisit;
}
//# sourceMappingURL=common.d.ts.map