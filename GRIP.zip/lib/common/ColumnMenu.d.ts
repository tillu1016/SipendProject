import * as React from 'react';
import { GridColumnMenuProps, GridColumnMenuCheckboxFilterProps } from '@progress/kendo-react-grid';
import '@progress/kendo-theme-default/dist/all.css';
export declare class ColumnMenu extends React.Component<Readonly<GridColumnMenuProps>, {}> {
    render(): JSX.Element;
}
export declare class ColumnMenuCheckboxFilter extends React.Component<Readonly<GridColumnMenuCheckboxFilterProps>, {}> {
    render(): JSX.Element;
}
//# sourceMappingURL=ColumnMenu.d.ts.map