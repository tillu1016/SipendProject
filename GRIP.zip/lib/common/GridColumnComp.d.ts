import * as React from 'react';
import { GridCellProps } from '@progress/kendo-react-grid';
export declare class GridColumnCell extends React.Component<Readonly<GridCellProps>, {}> {
    render(): JSX.Element;
}
//# sourceMappingURL=GridColumnComp.d.ts.map