import * as React from 'react';
import {
  GridColumnMenuFilter,
  GridColumnMenuCheckboxFilter,
  GridColumnMenuProps, GridColumnMenuCheckboxFilterProps
} from '@progress/kendo-react-grid';
import { orderBy } from '@progress/kendo-data-query';
import '@progress/kendo-theme-default/dist/all.css';

export class ColumnMenu extends React.Component<Readonly<GridColumnMenuProps>, {}> {
  public render() {
    return (
      <div>
        <GridColumnMenuFilter {...this.props} expanded={true} />
      </div>
    );
  }
}

export class ColumnMenuCheckboxFilter extends React.Component<Readonly<GridColumnMenuCheckboxFilterProps>, {}> { // IColumnMenu
  public render() {
    const sortedData = orderBy(this.props.data, [{ field: this.props.column.field, dir: "asc" }]);
    return (
      <div>
        <GridColumnMenuCheckboxFilter {...this.props} data={sortedData} expanded={true} searchBox={() => null} />
      </div>
    );
  }
}
