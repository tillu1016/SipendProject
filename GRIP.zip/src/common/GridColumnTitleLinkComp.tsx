import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { Tooltip } from '@progress/kendo-react-tooltip';
import { Grid, GridColumn, GridCellProps } from '@progress/kendo-react-grid';
import { Link } from '@fluentui/react';

export class GridColumnTitleLink extends React.Component<Readonly<GridCellProps>, {}> {
    public render() {
        return (
            <td>
                <Link title={this.props.dataItem[this.props.field] ?
                    this.props.dataItem[this.props.field].length > 20 ? this.props.dataItem[this.props.field] : ''
                    : ''}
                    className="listViewTitleLink" target="_blank" href={this.props.dataItem['titleLink'].link}>
                    {this.props.dataItem[this.props.field]}</Link>
            </td>
        );
    }
}