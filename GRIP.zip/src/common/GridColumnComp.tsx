import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { Tooltip } from '@progress/kendo-react-tooltip';
import { Grid, GridColumn, GridCellProps } from '@progress/kendo-react-grid';

export class GridColumnCell extends React.Component<Readonly<GridCellProps>, {}> {
  public render() {
    return (
      <td title={this.props.dataItem[this.props.field] ?
        this.props.dataItem[this.props.field].length > 20 ? this.props.dataItem[this.props.field] : ''
        : ''}>
        {this.props.dataItem[this.props.field]}
      </td>
    );
  }
}
