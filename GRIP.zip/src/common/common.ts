import { sp } from '@pnp/sp';
import { CurrentUser } from '@pnp/sp/src/siteusers';
import { ListService } from '../services/ListService';
import { ConfigKey, ConfigType, IConfiguration } from '../models/IConfiguration';
import { TaxonomyService } from '../services/TaxonomyService';
import { ITerm } from '@pnp/sp-taxonomy';
import { PermissionsService } from '../services/PermissionsService';

const regExp = /\(([^)]+)\)/;

export abstract class Common {

    public static pageSize: number = 0;
    public static isIE = false || !!document['documentMode'];
    public static errorLogList: string = '';
    public static auditLogList: string = '';
    public static timeZone: string = '';
    public static notificationErrMsg: string = 'Something went wrong! Please contact administrator.';

    public static getCurrentUserId(): Promise<CurrentUser> {
        return new Promise<CurrentUser>((resolve, reject) => {
            sp.web.currentUser.get().then((rslt: CurrentUser) => {
                resolve(rslt);
            }).catch((ex) => {
                reject(ex);
            });
        });
    }

    public static getQueryStringValue = (paramName: string): string => {
        paramName.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regexS = "[\\?&#]" + paramName.toLowerCase() + "=([^&#]*)";
        var regex = new RegExp(regexS);
        var results = regex.exec(decodeURIComponent(window.location.href.toLowerCase()));
        if (results == null)
            return "";
        else
            return decodeURIComponent(results[1].replace(/\+/g, " "));
    }

    public static getManagedMetadataString(fieldData: any[]): string {
        try {
            if (fieldData.length <= 0)
                return "";

            let selValue: string = '';
            fieldData.map((meta) => {
                selValue += ", " + meta.Label;
            });
            return selValue.substr(2);
        } catch (error) {
            throw error;
        }
    }

    public static getConfigData(): Promise<any> {
        try {
            return new Promise<any>((resolve, reject) => {
                ListService.GetAllData(ConfigKey.Configurations).then(response => {
                    if (response) {
                        let arrConfigData = [];
                        response.map((item) => {
                            arrConfigData.push({ title: item['Title'], key: item['Key'], value: item['Value'], richTextValue: item["RichTextValue"] });
                        });
                        resolve(arrConfigData);
                    }
                }).catch(error => {
                    reject(error);
                });
            });
        } catch (error) {
            throw error;
        }
    }

    public static getTermSetData(configData: IConfiguration[], category: string, key: string): Promise<any> {
        try {
            let termSetId = this.getConfigValue(configData, category, key);
            return new Promise<any>((resolve, reject) => {
                TaxonomyService.getTermSetByID(termSetId)
                    .then((terms: ITerm[]) => {
                        if (terms) {
                            let arrTermSet: any[] = [];
                            if (key == ConfigKey.Region)
                                terms.map((term) => {
                                    arrTermSet.push({
                                        key: regExp.exec(term["Id"])[1],
                                        text: term["Name"],
                                        imagePath: term['LocalCustomProperties'].ImagePath,
                                        displayOrder: term['LocalCustomProperties'].DisplayOrder
                                    });
                                });
                            else if (key == ConfigKey.TherapeuticArea)
                                terms.map((term) => {
                                    arrTermSet.push({
                                        key: regExp.exec(term["Id"])[1],
                                        text: term["Name"],
                                        imagePath: term['LocalCustomProperties'].ImagePath,
                                        displayOrder: term['LocalCustomProperties'].DisplayOrder,
                                        category: term['LocalCustomProperties'].Category,
                                    });
                                });
                            else
                                terms.map((term) => {
                                    arrTermSet.push({
                                        key: regExp.exec(term["Id"])[1],
                                        text: term["Name"]
                                    });
                                });
                            resolve(arrTermSet);
                        }
                    }).catch(e => {
                        reject(e);
                    });
            });
        } catch (error) {
            throw error;
        }
    }

    public static getConfigValue = (configData: IConfiguration[], category: string, key: string): string => {
        try {
            let keyValue = configData.filter((item) => {
                return item.title == category && item.key == key;
            });
            if (keyValue && keyValue.length > 0)
                return keyValue[0].value;
            else return null;
        } catch (error) {
            throw error;
        }
    }

    public static getConfigRichTextValue = (configData: IConfiguration[], category: string, key: string): string => {
        try {
            let keyValue = configData.filter((item) => {
                return item.title == category && item.key == key;
            });
            if (keyValue && keyValue.length > 0)
                return keyValue[0].richTextValue;
            else return null;
        } catch (error) {
            throw error;
        }
    }

    public static checkIfUserAdmin(groupName: string): Promise<boolean> {
        try {
            return new Promise<boolean>((resolve, reject) => {
                PermissionsService.isCurrentUserMemberOfGroup(groupName).then(resp => {
                    resolve(resp);
                }).catch(e => {
                    reject(e);
                });
            });
        } catch (error) {
            throw error;
        }
    }

    public static deleteAlert(configData: IConfiguration[], category: string, key: string, itemId: number): Promise<boolean> {
        try {
            let alertsDBListName = this.getConfigValue(configData, category, key);

            return new Promise<boolean>((resolve, reject) => {
                if (itemId !== 0) {
                    ListService.DeleteListDataByID(itemId, alertsDBListName).then(resp => {
                        resolve(true);
                    }).catch(error => {
                        console.log(error);
                        reject(error);
                    });
                }
            });
        } catch (error) {
            throw error;
        }
    }

    public static recycleAlert(configData: IConfiguration[], category: string, key: string, itemId: number): Promise<boolean> {
        try {
            let alertsDBListName = this.getConfigValue(configData, category, key);

            return new Promise<boolean>((resolve, reject) => {
                if (itemId !== 0) {
                    ListService.RecycleListDataByID(itemId, alertsDBListName).then(resp => {
                        resolve(true);
                    }).catch(error => {
                        console.log(error);
                        reject(error);
                    });
                }
            });
        } catch (error) {
            throw error;
        }
    }

    public static modifyRelativeURL(data: string, textToReplace: string, replacedText: string) {
        let finalData;
        var re = new RegExp(textToReplace, "g");
        finalData = data ? data.replace(re, replacedText) : data;
        return finalData;
    }

    public static async getEmailTemplate(emailTmplList: string, templateName: string): Promise<any[]> {
        try {
            return await ListService.GetDataByFilterWithExpand(emailTmplList, `Title eq '${templateName}'`,
                '*, ETFrom/EMail, ETTo/EMail, ETCc/EMail', 'ETFrom, ETTo, ETCc').then(response => {
                    if (response) {
                        return response;
                    }
                })
                .catch(err => {
                    return err;
                });
        } catch (error) {
            throw error;
        }
    }

    public static async getUserProfileProps(userLogin: string): Promise<any> {
        try {
            return await new Promise<any>((resolve, reject) => {
                sp.profiles.getPropertiesFor(userLogin).then(usr => {
                    resolve(usr);
                })
                    .catch(err => {
                        reject(err);
                    });
            });
        } catch (error) {
            throw error;
        }
    }

    public static logSiteVisit(listName: string, pageName: string, isAdmin: boolean, currUserId: number, alertId?: number) {
        try {
            this.isFirstVisit(listName, currUserId, pageName, alertId).then(isFirVis => {
                let tmpObj: any = {
                    Title: pageName,
                    AACurrentURL: window.location.href,
                    AASourceURL: document.referrer,
                    AAIsAdmin: isAdmin,
                    ADBId: alertId,
                    AAIsFirstVisit: isFirVis,
                    AABrowser: navigator.appVersion
                };

                ListService.PostListData(tmpObj, listName).catch(exception => {

                });
            });

        } catch (error) {
            throw error;
        }
    }

    private static isFirstVisit(listName: string, currUserId: number, pageName?: string, alertId?: number): Promise<boolean> {
        try {
            let filtStr: string = "";
            if (alertId)
                filtStr = `ADBId eq ${alertId} and AAIsFirstVisit eq 1 and AuthorId eq ${currUserId}`;
            else
                filtStr = `Title eq '${pageName}' and AAIsFirstVisit eq 1 and AuthorId eq ${currUserId}`;

            return ListService.GetDataByFilter(listName, filtStr, '*').then(resp => {
                if (resp)
                    if (resp.length > 0)
                        return false;
                    else
                        return true;
                else
                    return true;
            }).catch(err => {
                return false;
            });

        } catch (error) {
            throw error;
        }
    }
}