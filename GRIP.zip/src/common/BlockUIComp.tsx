import * as React from 'react';
import { Dialog, Spinner, SpinnerSize } from '@fluentui/react';

interface BlockUICompProps {
    hideLoadingDialog: boolean;
    loadingText: string;
}

export default class BlockUIComp extends React.Component<BlockUICompProps>{

    public render(): JSX.Element {
        return (
            <Dialog
                hidden={this.props.hideLoadingDialog}
                modalProps={{
                    isBlocking: true,
                    styles: { main: { maxWidth: 450 } }
                }}>
                <div>
                    <Spinner size={SpinnerSize.large} label={this.props.loadingText} />
                </div>
            </Dialog>
        );
    }
}