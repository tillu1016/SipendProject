import "@pnp/polyfill-ie11";
import { taxonomy, ITermSet, ITerm } from "@pnp/sp-taxonomy";

export abstract class TaxonomyService {

    public static getTermSetByID(termSetId: string): Promise<ITerm[]> {
        const termset: ITermSet = taxonomy.getDefaultSiteCollectionTermStore().getTermSetById(termSetId).usingCaching().select('Id', 'Name');
        const terms: Promise<ITerm[]> = termset.terms.usingCaching().select('Id', 'Name', 'LocalCustomProperties').get();

        return terms.then((termsItems: ITerm[]) => {
            //termsItems.get
            return termsItems;
        })
            .catch((e) => {
                return e;
            });
    }
}