import { sp, EmailProperties } from "@pnp/sp";

export abstract class EmailService {
    public static async sendEmail(emailFrom: string, emailTo: string[], emailCC: string[], emailSubject: string, emailBody: string): Promise<boolean> {

        const emailProps: EmailProperties = {
            From: emailFrom,
            To: emailTo,
            CC: emailCC,
            Subject: emailSubject,
            Body: emailBody,
        };
        return await new Promise<boolean>(async (resolve, reject) => {
            await sp.utility.sendEmail(emailProps).then(_ => {
                resolve(true);
            }).catch((exception) => {
                reject(exception);
            });
        });
    }
}