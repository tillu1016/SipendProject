import { sp } from "@pnp/sp";
export abstract class PermissionsService {

    public static isCurrentUserMemberOfGroup(groupName): Promise<boolean> {
        return sp.web.currentUser.groups.get()
            .then((groups: any) => {
                let flag = false;
                groups.forEach((group) => {
                    if (group["Title"] == groupName) {
                        flag = true;
                    }
                });
                return flag;
            })
            .catch(err => {
                return false;
            });
    }

    public static getGroupMembers(groupName): Promise<any> {
        try {
            return sp.web.siteGroups.getByName(groupName).users.get()
                .then((users: any) => {
                    return users;
                })
                .catch(err => {
                    return err;
                });
        } catch (error) {
            console.log(error);
        }
    }
}