import { sp, Web, ItemAddResult, CamlQuery, SPBatch, List, PagedItemCollection } from "@pnp/sp";
import { ConfigKey } from "../models/IConfiguration";
import { DATA_IS_SCROLLABLE_ATTRIBUTE } from "@fluentui/react";

export abstract class ListService {

  public static GetAllData = (list: string): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      sp.web.lists.getByTitle(list).items.getAll().then(data => {
        resolve(data);
      }).catch((exception) => {
        reject(exception);
      });
    });
  }

  public static GetDataByCAML = (list: string, caml: string): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      const q: CamlQuery = {
        ViewXml: caml,
      };
      sp.web.lists.getByTitle(list)
        .getItemsByCAMLQuery(q)
        .then(data => {
          resolve(data);
        }).catch((exception) => {
          reject(exception);
        });
    });
  }

  public static GetDataByCAMLStream = (list: string, caml: string): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      const q: CamlQuery = {
        ViewXml: caml,
      };
      sp.web.lists.getByTitle(list)
        .renderListDataAsStream(q)
        .then(data => {
          resolve(data);
        }).catch((exception) => {
          reject(exception);
        });
    });
  }

  public static GetDataByFilterWithExpand = (list: string, filterStr: string, selectStr: string, expandStr: string): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      sp.web.lists.getByTitle(list).items
        .select(selectStr)
        .filter(filterStr)
        .expand(expandStr)
        .getAll()
        .then(data => {
          resolve(data);
        }).catch((exception) => {
          reject(exception);
        });
    });
  }

  public static getDataFromLargeList = (list: string, camlQ: string): Promise<any> => {
    //Title field is indexed, filter / orderBy fields should still be indexed for this endpoint
    return new Promise<any>((resolve, reject) => {
      const headers = {
        Accept: 'application/json;odata=nometadata'
      };
      sp.web.lists.getByTitle(list).configure({ headers }).renderListDataAsStream({
        ViewXml: camlQ
      }).then(data => {
        resolve(data);
      }).catch((exception) => {
        reject(exception);
      });
    });
  }

  public static GetDataByFilterWithExpandTop = (list: string, filterStr: string, selectStr: string,
    expandStr: string, top: number, orderBy: string, asc: boolean): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      sp.web.lists.getByTitle(list).items
        .orderBy(orderBy, asc)
        .select(selectStr)
        .filter(filterStr)
        .expand(expandStr)
        .top(top)
        .get()
        .then(data => {
          resolve(data);
        }).catch((exception) => {
          reject(exception);
        });
    });
  }

  public static GetDataByFilter = (list: string, filterStr: string, selectStr: string): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      sp.web.lists.getByTitle(list).items
        .select(selectStr)
        .filter(filterStr)
        .getAll()
        .then(data => {
          resolve(data);
        }).catch((exception) => {
          reject(exception);
        });
    });
  }
  public static GetDataByCAMLColExpand = (list: string, caml: string, colExpand: string): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      const q: CamlQuery = {
        ViewXml: caml,
      };
      sp.web.lists.getByTitle(list)
        .getItemsByCAMLQuery(q, colExpand)
        //.renderListDataAsStream(q)
        .then(data => {
          resolve(data);
        }).catch((exception) => {
          reject(exception);
        });
    });
  }

  public static PostListData = (data: any, list: string): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      sp.web.lists.getByTitle(list).items.add(data)
        .then(result => {
          resolve(result);
        }).catch((exception) => {
          reject(exception);
        });
    });
  }

  public static GetDataBySelect = (list: string, selectStr: string): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      sp.web.lists.getByTitle(list).items
        .select(selectStr)
        .getAll()
        .then(data => {
          resolve(data);
        }).catch((exception) => {
          reject(exception);
        });
    });
  }

  public static UpdateListDataByID = (list: string, itemId: number, data: any): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      sp.web.lists.getByTitle(list).items.getById(itemId).update(data)
        .then(result => {
          resolve(result);
        }).catch((exception) => {
          reject(exception);
        });
    });
  }

  public static DeleteListDataByID = (itemId: number, list: string): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      sp.web.lists.getByTitle(list).items.getById(itemId).delete()
        .then(result => {
          resolve(result);
        }).catch((exception) => {
          reject(exception);
        });
    });
  }

  public static RecycleListDataByID = (itemId: number, list: string): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      sp.web.lists.getByTitle(list).items.getById(itemId).recycle()
        .then(result => {
          resolve(result);
        }).catch((exception) => {
          reject(exception);
        });
    });
  }

  public static AddFile = (path: string, fileName: string, file: any, isOverWrite: boolean): Promise<any> => {
    let tmpFileName = fileName.replace(/'/gi, "''");
    return new Promise<any>((resolve, reject) => {
      sp.web.getFolderByServerRelativeUrl(path)
        .files
        .add(tmpFileName, file, isOverWrite)
        .then(data => {
          resolve(data);
        }).catch((exception) => {
          reject(exception);
        });
    });
  }

  public static addFolder = (list: string, foldName: string): Promise<any> => {
    let camlQ = "<View><Query><Where><And><Eq><FieldRef Name=\"FSObjType\"/>" +
      "<Value Type=\"Integer\">1</Value></Eq><Eq><FieldRef Name=\"FileLeafRef\" /><Value Type=\"Text\">" + foldName + "</Value>" +
      "</Eq></And></Where></Query><RowLimit>1</RowLimit></View>";
    return new Promise<any>((resolve, reject) => {
      const q: CamlQuery = {
        ViewXml: camlQ,
      };

      return sp.web.lists.getByTitle(list).getItemsByCAMLQuery(q)
        .then((docDetails) => {
          if (docDetails.length > 0) {
            return true;
          } else {
            sp.web.folders.getByName(list).folders.add(foldName).then((data) => {
              resolve(data);
            }).catch((error) => {
              reject(error);
            });
          }
        }).catch((exception) => {
          reject(exception);
        });
    });
  }

  public static PostImmediateEmail = (data: any, apiPath: string): Promise<any> => {
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    };

    return new Promise<any>((resolve, reject) => {
      fetch(apiPath, requestOptions)
        .then(resp => {
          resolve(resp);
        })
        .catch(error => {
          reject(error);
        });
    });
  }
}
