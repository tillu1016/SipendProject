import { Logger, LogLevel } from "@pnp/logging";
import { ListService } from "./ListService";
import { Common } from "../common/common";

export abstract class LoggerService {

    public static EnableConsoleLog: boolean = true;

    public static auditLog = (message: string, functionName: string): Promise<any> => {
        Logger.write(message);
        return new Promise<any>((resolve, reject) => {
            LoggerService.LogEntryInDatabase(message, LogLevel.Info, functionName)
                .then(data => { resolve(true); })
                .catch(exception => { reject(false); });
        });
    }

    public static errorLog = (error: any, functionName: string): void => {
        Logger.error(error);
        LoggerService.LogEntryInDatabase(error.stack, LogLevel.Error, functionName);
    }

    private static LogEntryInDatabase = (entry: string, logLevel: LogLevel, functionName: string): Promise<any> => {
        if (LoggerService.EnableConsoleLog) {
            console.log(functionName, logLevel, entry);
        }
        let tmpObj: any = {
            Title: functionName,
            G2LogDetails: entry,
            G2Browser: navigator.appVersion,
            G2FromURL: window.location.href
        };
        switch (logLevel) {
            case LogLevel.Error:
                return new Promise<any>((resolve, reject) => {
                    ListService.PostListData(tmpObj, Common.errorLogList)
                        .then(data => resolve(true))
                        .catch(exception => {
                            Logger.log({ level: LogLevel.Error, message: "Exception occurred during saving error log", data: exception });
                            console.log("Exception occurred during saving error log", exception);
                            reject(false);
                        });
                });
                break;
            case LogLevel.Info:
                return new Promise<any>((resolve, reject) => {
                    ListService.PostListData(tmpObj, Common.auditLogList).then(data => {
                        resolve(true);
                    }).catch(exception => {
                        Logger.log({ level: LogLevel.Error, message: "Exception occurred during saving audit log", data: exception });
                        console.log("Exception occurred during saving audit log - ", exception);
                        reject(false);
                    });
                });
                break;
            default:
                break;
        }
    }
}