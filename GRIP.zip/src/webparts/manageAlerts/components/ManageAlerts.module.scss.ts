/* tslint:disable */
require("./ManageAlerts.module.css");
const styles = {
  manageAlerts: 'manageAlerts_7a789eda',
  container: 'container_7a789eda',
  row: 'row_7a789eda',
  column: 'column_7a789eda',
  'ms-Grid': 'ms-Grid_7a789eda',
  title: 'title_7a789eda',
  subTitle: 'subTitle_7a789eda',
  description: 'description_7a789eda',
  button: 'button_7a789eda',
  label: 'label_7a789eda'
};

export default styles;
/* tslint:enable */