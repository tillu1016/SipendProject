import 'core-js/es7/map';
import 'core-js/es6/array';
import 'core-js/fn/string/includes';
import * as React from 'react';
import '@progress/kendo-theme-default/dist/all.css';
import styles from './ManageAlerts.module.scss';
import { IManageAlertsProps } from './IManageAlertsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { ListService } from '../../../services/ListService';
import { TaxonomyService } from '../../../services/TaxonomyService';
import {
  ProgressIndicator, Shimmer, Stack, Dropdown, TextField, SearchBox, DetailsList, IColumn, DetailsListLayoutMode, DefaultButton, Dialog, DialogType,
  SpinButton, ComboBox, DialogFooter, PrimaryButton, Link, SelectionMode, TooltipHost, IconButton, IIconProps, Label, IStackItemStyles, ShimmeredDetailsList, ActionButton, MessageBar, MessageBarType
} from '@fluentui/react';
import { IAlert, AlertIconType, AlertStatus } from '../../../models/IAlert';
import { ConfigType, IConfiguration, ConfigKey } from '../../../models/IConfiguration';
import { PermissionsService } from '../../../services/PermissionsService';
import { Common } from '../../../common/common';
import { CurrentUser } from '@pnp/sp/src/siteusers';
import { PDFExport } from '@progress/kendo-react-pdf';
import ReactHtmlParser from 'react-html-parser';
import { Pagination } from "@pnp/spfx-controls-react/lib/pagination";
import { stringIsNullOrEmpty } from "@pnp/common";
import { Grid, GridColumn, GridColumnMenuCheckboxFilter, GridColumnMenuFilter } from '@progress/kendo-react-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import {
  ColumnMenuTextColumn, ColumnMenuDateColumn
} from '@progress/kendo-react-data-tools';
import { LoggerService } from "../../../services/LoggerService";
import * as moment from 'moment-timezone';
import { PageName } from '../../../models/IAlertAnalytics';
import { NotificationType } from '../../../models/INotification';
import BlockUIComp from '../../../common/BlockUIComp';
import { ColumnMenu, ColumnMenuCheckboxFilter } from '../../../common/ColumnMenu';
import { Tooltip } from '@progress/kendo-react-tooltip';
import { GridColumnCell } from '../../../common/GridColumnComp';

const stackItemStyles: IStackItemStyles = {
  root: {
    padding: 5
  }
};

export interface IManageAlertsState {
  alertRegionOptions: any[]; alertTAOptions: any[]; alertRegTopicOptions: any[]; selRegion: any[];
  selTA: any[]; selRegTopic: any[]; selAuthor: any[];  searchText: string; listColumns: IColumn[];  allAlerts: IAlert[];
  hideSignUpDialog: boolean; isUserAdmin: boolean; showNewEditPanel: boolean; newEditPanelHeaderText: string;
  hideDeleteDialog: boolean; hideShareDialog: boolean; exportToPDFItem: IAlert;  showShimmer: boolean;  skip: number;
  take: number;  columns: any;  sort: any[];  filter: any;  alertAuthorOptions: any[];
  showSuccessMessage: boolean; successMessage: string; showErrorMessage: boolean; errorMessage: string; addEditAlertPage: string;
  disableAlertSubmit: boolean; hideLoadingDialog: boolean; loadingText: string; result: any; dataState: any; pageable: any;
}

export default class ManageAlerts extends React.Component<IManageAlertsProps, IManageAlertsState> {
  private _configData: IConfiguration[] = [];
  private _allAlerts: any[] = [];
  private _selRegionsObj: any[] = [];
  private _selTAObj: any[] = [];
  private _selRegTopicObj: any[] = [];
  private _selAuthorObj: any[] = [];
  private _currUser: CurrentUser;
  private _alertTitle: string;
  private _copyIcon: IIconProps = { iconName: 'Copy' };
  private _alertIdToDelete: number = 0;
  private _refTextToCopy;
  private _shareLink: string = "";
  private _pdfContainer;
  private _addNewAlertURL: string = "";
  private MSColumnMenuCheckboxFilter = (props) => <ColumnMenuCheckboxFilter {...props} data={this.state.allAlerts} />;
  private _searchText: string = "";

  constructor(props) {
    super(props);
    const dataState = this.createDataState({
      take: Common.pageSize,
      skip: 0,
      sort: [{ field: 'publicationDate', dir: 'desc' }]
    });

    this.state = {
      alertRegionOptions: [], alertTAOptions: [], alertRegTopicOptions: [], selRegion: [], selTA: [],
      selRegTopic: [], selAuthor: [], searchText: '', listColumns: [], allAlerts: [], hideSignUpDialog: true,
      isUserAdmin: false, showNewEditPanel: false, newEditPanelHeaderText: "",
      hideDeleteDialog: true, hideShareDialog: true, exportToPDFItem: {} as IAlert, showShimmer: false,
      skip: 0, take: Common.pageSize, columns: [], alertAuthorOptions: [],
       showSuccessMessage: false, successMessage: '', showErrorMessage: false, errorMessage: '', addEditAlertPage: '', disableAlertSubmit: true,
      hideLoadingDialog: true, loadingText: 'Please Wait...', result: [], dataState: [],
      sort: [
        { field: 'publicationDate', dir: 'desc' }
      ],
      filter: {
        logic: "and",
        filters: []
      },
      pageable: {
        buttonCount: 5,
        info: true,
        type: 'numeric',
        pageSizes: [50, 100, 200],
        previousNext: true
      }
    };
    this._refTextToCopy = React.createRef();
  }

  public componentDidMount() {
    try {
      Common.timeZone = moment.tz.guess();
      moment.tz.setDefault(Common.timeZone);

      this.setState({ hideLoadingDialog: false }, () => {
        Common.getConfigData().then(resp => {
          if (resp) {
            this._configData = resp;
            Common.errorLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ErrorLog);
            Common.auditLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AuditLog);
            Common.pageSize = Number.parseInt(Common.getConfigValue(resp, ConfigType.Grid, ConfigKey.PageSize));

            let adminGrpName: string = Common.getConfigValue(this._configData, ConfigType.Roles, ConfigKey.Administrator);
            this.setState({
              addEditAlertPage: Common.getConfigValue(resp, ConfigType.Page, ConfigKey.AddEditAlerts),
              take: Common.pageSize
            });

            Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.Region).then(regions => {
              this.setState({ alertRegionOptions: regions });
            });
            Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.RegulatoryTopic).then(regTopics => {
              this.setState({ alertRegTopicOptions: regTopics });
            });
            Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.TherapeuticArea).then(tas => {
              this.setState({ alertTAOptions: tas });
            });

            //get user details
            Common.getCurrentUserId().then((curUser: CurrentUser) => {
              this._currUser = curUser;
              //check if user is admin
              Common.checkIfUserAdmin(adminGrpName).then(isUsrAdm => {
                //log user visits          
                let AlertAnalyticsList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AlertAnalytics);
                Common.logSiteVisit(AlertAnalyticsList, PageName.ManageAlerts, isUsrAdm, this._currUser["Id"], null);

                this.setState({ isUserAdmin: isUsrAdm }, () => {
                   this.getAllAlertsDataTemp(isUsrAdm);                 
                });
              });
            });
          }
        });
      });
      
      this._addNewAlertURL = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.AddEditAlerts);
      this._addNewAlertURL = this.props.webURL + this._addNewAlertURL;
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > componentDidMount');
    }
  }

  private _getQueryParam = (): void => {
    try {
      let viewType = Common.getQueryStringValue('viewtype');
      let viewId = Common.getQueryStringValue('viewid');
      let viewName = Common.getQueryStringValue('viewname');

      if (viewType.length > 0 && viewId.length > 0 && viewName.length > 0) {

        let arrVal: any = { key: viewId, text: viewName, selected: true };
        switch (viewType) {
          case ConfigKey.Region.toLowerCase():
            this.setMultiselectState(ConfigKey.Region, "selRegion", arrVal);
            break;
          case ConfigKey.TherapeuticArea.toLowerCase():
            this.setMultiselectState(ConfigKey.TherapeuticArea, "selTA", arrVal);
            break;
          default:
            break;
        }
      } 
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > _getQueryParam');
    }
  }

  private onIconClick(type: string, item: any) {
    try {
      switch (type) {
        case AlertIconType.View:
          LoggerService.auditLog("Clicked on Icon - " + type, 'ManageAlerts > onIconClick')
            .then(data => {
              let viewLink = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ViewAlert);
              viewLink = this.props.webURL + viewLink + "#" + encodeURIComponent("Id=");
              window.location.href = viewLink + item.id;
            });
          break;
        case AlertIconType.Edit:
          LoggerService.auditLog("Clicked on Icon - " + type, 'ManageAlerts > onIconClick')
            .then(data => {
              let editLink = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.AddEditAlerts);
              editLink = this.props.webURL + editLink + "#" + encodeURIComponent("Id=");
              window.location.href = editLink + item.id;
            });
          break;
        case AlertIconType.PDF:
          LoggerService.auditLog("Clicked on Icon - " + type, 'ManageAlerts > onIconClick');
          this.setState({
            exportToPDFItem: {
              ...this.state.exportToPDFItem,
              id: item.id,
              title: item.title,
              impact: item.impact,
              body: item.body,
              status: item.status,
              publicationDate: item.publicationDate,              
              meetAgendaStartTime: item.meetAgStTime,
              meetAgendaEndTime: item.meetAgEndTime,
              region: item.region,
              therapeuticArea: item.therapeuticArea,
              regulatoryTopic: item.regulatoryTopic,
              documentType: item.documentType
            }
          }, () => {
            this._pdfContainer.save();
            this.props.onSetNotification({ 'type': NotificationType.success, 'message': `PDF generated successfully!` });
          });
          break;
        case AlertIconType.Share:
          LoggerService.auditLog("Clicked on Icon - " + type, 'ManageAlerts > onIconClick');
          let shareLnk = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ViewAlert);
          this._shareLink = this.props.webURL + shareLnk + "#" + encodeURIComponent("Id=") + item.id;
          this.setState({ hideShareDialog: false });
          break;
        case AlertIconType.Delete:
          LoggerService.auditLog("Clicked on Icon - " + type, 'ManageAlerts > onIconClick');
          this._alertIdToDelete = item.id;
          this.setState({ hideDeleteDialog: false });
          break;
        default:
          break;
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > onIconClick');
    }
  }

  private getAllAlertsDataTemp(isAdmin:boolean) {
    try {
       console.log("data preparation started" + new Date());
      let alertDBListName = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsDatabase);
      
      let camlQ: string = `<View>
      <Query>`;
      if (!isAdmin) {
         camlQ += `<Where><Eq><FieldRef Name='ADBStatus'/><Value Type='Text'>${AlertStatus.Publish}</Value></Eq></Where>`;
      }     
      camlQ += `<OrderBy><FieldRef Name='ADBPublicationDate' Ascending='False' /></OrderBy>
      </Query>
      <ViewFields><FieldRef Name='ID'/></ViewFields>
      <RowLimit Paged="TRUE">5000</RowLimit>
      </View>`;

      ListService.getDataFromLargeList(alertDBListName, camlQ).then(data => {
        if (data) {         
          this._allAlerts = [];
           data.Row.map((alert) => {
              this._allAlerts.push({
                id: alert['ID'],
                title: '', impact: '', body: '', publicationDate: '', meetAgStTime: '', meetAgEndTime: '', status: '',
                region: '', documentType: '', regulatoryTopic: '', therapeuticArea: '', author: '', icons: ''
              });
           });

          this.setState({
            allAlerts: this._allAlerts
          }, () => {
            this._getQueryParam();            
            this.createDataState({ take: this.state.take, skip: this.state.skip, sort: this.state.sort });
            if (this.state.allAlerts.length > 0) {
              this.getAllAlertsData(0, (this.state.allAlerts.length - 1 > 49) ? 49 : this.state.allAlerts.length - 1);
            }
            else {
              this.setState({ hideLoadingDialog: true });
            }
          });
        }
      }).catch(error => {
        LoggerService.errorLog(error, 'ManageAlerts > getAllAlertsData > GetDataByFilterWithExpand');
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > getAllAlertsData');
    }
  }

  private getAllAlertsData(startIndex: number, endIndex: number) {
    try {
      let alertDBListName = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsDatabase);
      let camlQ: string = `<View><Query><Where><In><FieldRef Name='ID' /><Values>`;
      for (let i = startIndex; i <= endIndex; i++) {
        camlQ += `<Value Type='Number'>${this.state.allAlerts[i].id}</Value>`;
      }
      camlQ += `</Values></In></Where>
      <OrderBy><FieldRef Name='ADBPublicationDate' Ascending='False' /></OrderBy></Query>
      <ViewFields><FieldRef Name='ID'/><FieldRef Name='Title'/><FieldRef Name='ADBStatus'/><FieldRef Name='G2Region'/><FieldRef Name='G2DocumentType'/>
      <FieldRef Name='G2RegulatoryTopic'/><FieldRef Name='G2TherapeuticArea'/><FieldRef Name='ADBMeetAgStTime'/><FieldRef Name='ADBMeetAgEndTime'/>
      <FieldRef Name='ADBImpact'/><FieldRef Name='ADBPublicationDate'/><FieldRef Name='ADBAuthor'/><FieldRef Name='ADBAlertBody'/></ViewFields>
      <ExpandUserField>True</ExpandUserField></View>`;

      ListService.getDataFromLargeList(alertDBListName, camlQ).then(data => {
        if (data) {
          data.Row.map((alert) => {           
            let alertItem = this._allAlerts.find(item => item.id == alert['ID']);
            if (alertItem) {
              alertItem.title = alert['Title'];
              alertItem.impact = alert["ADBImpact"];
              alertItem.body = Common.modifyRelativeURL(alert["ADBAlertBody"], this.props.context.pageContext.site.serverRelativeUrl, this.props.context.pageContext.site.absoluteUrl);
              alertItem.publicationDate = moment(alert["ADBPublicationDate"]).toDate();
              alertItem.meetAgStTime = alert['ADBMeetAgStTime'];
              alertItem.meetAgEndTime = alert['ADBMeetAgEndTime'];
              alertItem.status = alert["ADBStatus"];
              alertItem.region = Common.getManagedMetadataString(alert["G2Region"]);
              alertItem.documentType = Common.getManagedMetadataString(alert["G2DocumentType"]);
              alertItem.regulatoryTopic = Common.getManagedMetadataString(alert["G2RegulatoryTopic"]);
              alertItem.therapeuticArea = Common.getManagedMetadataString(alert["G2TherapeuticArea"]);
              alertItem.author = alert.ADBAuthor[0]['title'];
            } 
          });

          this.setState({
            allAlerts: this._allAlerts, hideLoadingDialog: true
          }, () => { 
            this.getDistinctAuthors();
              this.onDDLFilter();
           
            if (endIndex >= this.state.allAlerts.length - 1) {
              console.log("data prepared:" + new Date());
              this.setState({ showShimmer: false });
            }
            else if (endIndex + 400 > this.state.allAlerts.length - 1) {
              if (endIndex + 50 > this.state.allAlerts.length - 1) {
                this.getAllAlertsData(endIndex + 1, this.state.allAlerts.length - 1);
              }
              else {
                this.getAllAlertsData(endIndex + 1, endIndex + 50);
              }              
              this.setState({ showShimmer: true });
            }
            else {
              this.getAllAlertsData(endIndex + 1, endIndex + 400);
              this.setState({ showShimmer: true });
            }
          });
        }
      }).catch(error => {
        LoggerService.errorLog(error, 'ManageAlerts > getAllAlertsData > GetDataByFilterWithExpand');
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > getAllAlertsData');
    }
  }

  public render(): React.ReactElement<IManageAlertsProps> {
    return (
      <div className={styles.manageAlerts} >
        <Stack>
          {this.state.showSuccessMessage ?
            <Stack.Item className="report_mgs">
              <MessageBar messageBarType={MessageBarType.success} isMultiline={false} onDismiss={() => {
                this.setState({ ...this.state, showSuccessMessage: false });
              }}>
                {this.state.successMessage}
              </MessageBar>
            </Stack.Item> : null}
          {this.state.showErrorMessage ?
            <Stack.Item className="report_mgs">
              <MessageBar messageBarType={MessageBarType.error} isMultiline={false} onDismiss={() => {
                this.setState({ ...this.state, showErrorMessage: false });
              }}>
                {this.state.errorMessage}
              </MessageBar>
            </Stack.Item> : null}
          <Stack.Item>
            <h1>GRIP Alerts</h1>
          </Stack.Item>
          <Stack.Item className="filter_container">
            <div className="filterSectionLeft">
              <div className="maFiltersDropdown">
                <Dropdown
                  placeholder="Select an option"
                  label="Region"
                  options={this.state.alertRegionOptions}
                  multiSelect
                  onChange={this._onDDLRegionChange.bind(this)}
                  selectedKeys={this.state.selRegion}
                  dropdownWidth={350}
                />
              </div>
              <div className="maFiltersDropdown">
                <Dropdown
                  placeholder="Select an option"
                  label="Therapeutic Area"
                  multiSelect
                  options={this.state.alertTAOptions}
                  onChange={this._onDDLTAChange.bind(this)}
                  selectedKeys={this.state.selTA}
                  dropdownWidth={350}
                />
              </div>
              <div className="maFiltersDropdown">
                <Dropdown
                  placeholder="Select an option"
                  label="Regulatory Topic"
                  multiSelect
                  options={this.state.alertRegTopicOptions}
                  onChange={this._onDDLRegTopicChange.bind(this)}
                  selectedKeys={this.state.selRegTopic}
                  dropdownWidth={350}
                />
              </div>
              {this.state.isUserAdmin ?
                <div className="maFiltersDropdown">
                  <Dropdown
                    placeholder="Select an option"
                    label="Author"
                    multiSelect
                    options={this.state.alertAuthorOptions}
                    onChange={this._onDDLAuthorChange.bind(this)}
                    selectedKeys={this.state.selAuthor}
                    dropdownWidth={350}
                  />
                </div> : null}
            </div>
            <div className="filterSectionRight">
              <div className="maSignUpContainer">
                <PrimaryButton className="maSignUpButton" text="Sign Up for Alerts" onClick={this.onSignUpClick.bind(this)} />
              </div>
              <div className="maSignUpContainer">
                {this.state.isUserAdmin ?
                  <PrimaryButton className='maSignUpButton' text="Add New Alert" onClick={this.onAddNewClick.bind(this)} />
                  : null}
              </div>
              <div className="maSearchBox">
                <SearchBox className="searchBox" placeholder="Search Alerts"
                  onClear={ev => {
                    this._searchText = '';
                    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
                    this.onDDLFilter();
                  }}
                  onChange={(newValue) => {
                    let srchTxt: string = newValue ? newValue.currentTarget.value : "";
                    this._searchText = srchTxt;
                    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
                    this.onDDLFilter();
                  }}
                />
              </div>
            </div>
          </Stack.Item>
          <Stack.Item className="progressDiv" styles={stackItemStyles}>
            {
              this.state.showShimmer ?
                <ProgressIndicator />
                :
                ""
            }
          </Stack.Item>
          <Stack.Item>
            <Tooltip openDelay={100} position="auto" anchorElement="element">
              <Grid
                style={{ height: '600px' }}
                data={this.state.result.length > 0 ?
                  orderBy(this.state.result.data, this.state.sort) :
                  this.state.result}
                {...this.state.dataState}
                onDataStateChange={this.dataStateChange}
                total={this.state.result.total}
                pageable={this.state.pageable}
                reorderable={true}
                sortable
                sort={this.state.sort}
                resizable
                onSortChange={(e) => { this._sortChange(e); }}
              >
                {this.state.isUserAdmin ?
                  <GridColumn field="icons" title="Actions" width="135px" cell={this.showIcons}></GridColumn> :
                  <GridColumn field="icons" title="Actions" width="80px" cell={this.showIcons}></GridColumn>}
                {this.state.isUserAdmin ?
                  <GridColumn field="title" title="Title" width="280px" filter={'text'} columnMenu={ColumnMenu} cell={GridColumnCell}></GridColumn> :
                  <GridColumn field="title" title="Title" width="380px" filter={'text'} columnMenu={ColumnMenu} cell={GridColumnCell}></GridColumn>}
                {this.state.isUserAdmin ?
                  <GridColumn field="status" title="Status" width="100px" filter={'text'} columnMenu={ColumnMenu}></GridColumn>
                  : null}
                <GridColumn field="region" title="Region" width="150px" cell={GridColumnCell}></GridColumn>
                <GridColumn field="therapeuticArea" title="Therapeutic Area" width="200px" cell={GridColumnCell}></GridColumn>
                <GridColumn field="regulatoryTopic" title="Regulatory Topic" width="250px" cell={GridColumnCell}></GridColumn>                
                <GridColumn field="documentType" title="Document Type" width="200px" filter={'text'} columnMenu={ColumnMenu} cell={GridColumnCell}></GridColumn>                
                <GridColumn field="publicationDate" title="Publication Date" width="150px" format="{0:MMM dd, yyyy}" filter={'date'} columnMenu={ColumnMenu}></GridColumn>
                {this.state.isUserAdmin ?
                  <GridColumn field="author" title="Author" width="100px" cell={GridColumnCell}></GridColumn> : null}
              </Grid>
            </Tooltip>
          </Stack.Item>
          <Stack.Item>
            <Dialog
              hidden={this.state.hideDeleteDialog}
              onDismiss={this.closeDeleteDialog.bind(this)}
              dialogContentProps={{
                type: DialogType.normal,
                title: 'Delete Alert',
                subText: "Do you want to delete this alert?"
              }}
              modalProps={{
                isBlocking: true,
                containerClassName: 'ms-dialogMainOverride'
              }}
            >
              <DialogFooter>
                <PrimaryButton onClick={this.deleteAlert.bind(this)} text="Confirm" />
                <DefaultButton onClick={this.closeDeleteDialog.bind(this)} text="Cancel" />
              </DialogFooter>
            </Dialog>
            <Dialog
              hidden={this.state.hideShareDialog}
              onDismiss={this.closeShareDialog.bind(this)}
              dialogContentProps={{
                type: DialogType.normal,
                title: 'Share Alert',
              }}
              modalProps={{
                isBlocking: true,
                containerClassName: 'ms-dialogMainOverrideShare'
              }}
            >
              <div className="maShareDialog maShareDialogleft">
                <input className="maShareDialogTextField" value={this._shareLink} readOnly
                  ref={this._refTextToCopy}
                />
                <IconButton iconProps={this._copyIcon} title="Copy to Clipboard" ariaLabel="Copy to Clipboard"
                  className="maCopyIcon" onClick={this.copyToClipboard.bind(this)} />
              </div>
              <DialogFooter>
                <DefaultButton onClick={this.closeShareDialog.bind(this)} text="Cancel" />
              </DialogFooter>
            </Dialog>
          </Stack.Item>
          <div className="pdfDiv">
            <PDFExport
              scale={0.6}
              paperSize="auto"
              margin="1cm"
              fileName={`GRIP_Alert_${this.state.exportToPDFItem.id}.pdf`}
              author="GRIP Team"
              ref={(container) => (this._pdfContainer = container)}
            >
              <div className="pdfDiv_main">
                <div className="grip_pdf_logo"><img src={this.props.webURL + "/SiteAssets/Images/AboutUs/Gilead_GRIP_Logo.png"} /></div>
                <div className="pdfDiv_cont">
                  <Stack.Item styles={stackItemStyles}>
                    <div className='maFormControls'>
                      <Label className="maLabel">Region</Label>
                      {this.state.exportToPDFItem.region}
                    </div>
                    <div className='maFormControls'>
                      <Label className="maLabel">Document Type</Label>
                      {this.state.exportToPDFItem.documentType}
                    </div>
                  </Stack.Item>
                  <Stack.Item styles={stackItemStyles}>
                    <div className='maFormControls'>
                      <Label className="maLabel">Therapeutic Area</Label>
                      {this.state.exportToPDFItem.therapeuticArea}
                    </div>
                    <div className='maFormControls'>
                      <Label className="maLabel">Regulatory Topic</Label>
                      {this.state.exportToPDFItem.regulatoryTopic}
                    </div>
                  </Stack.Item>
                  {this.state.isUserAdmin ?
                    <Stack.Item styles={stackItemStyles}>
                      <div className='maFormControls'>
                        <Label className="maLabel">Meeting Agenda Start Time</Label>
                        {(this.state.exportToPDFItem.meetAgStTime == null ? "N/A" : moment(this.state.exportToPDFItem.meetAgStTime).format('ddd, MMM DD, YYYY')) +
                          (this.state.exportToPDFItem.meetAgendaStartTime ? ' - ' + this.state.exportToPDFItem.meetAgendaStartTime : "")}
                      </div>
                      <div className='maFormControls'>
                        <Label className="maLabel">Meeting Agenda End Time</Label>
                        {(this.state.exportToPDFItem.meetAgEndTime == null ? "N/A" : moment(this.state.exportToPDFItem.meetAgEndTime).format('ddd, MMM DD, YYYY')) +
                          (this.state.exportToPDFItem.meetAgendaEndTime ? ' - ' + this.state.exportToPDFItem.meetAgendaEndTime : "")}
                      </div>
                    </Stack.Item> : null}
                  <Stack.Item styles={stackItemStyles}>
                    <div className='maFormControls'>
                      <Label className="maLabel">Publication Date</Label>
                      {moment(this.state.exportToPDFItem.publicationDate).format('ddd, MMM DD, YYYY')}
                    </div>
                    {this.state.isUserAdmin ?
                      <div className='maFormControls'>
                        <Label className="maLabel">Status</Label>
                        {this.state.exportToPDFItem.status}
                      </div> : null}
                  </Stack.Item>
                  <Stack.Item styles={stackItemStyles}>
                    <Label className="maLabel">Title</Label>
                    <div className="maContent">{this.state.exportToPDFItem.title}</div>
                  </Stack.Item>
                  <Stack.Item styles={stackItemStyles}>
                    <Label className="maLabel">Impact</Label>
                    <div className="maContent">{this.state.exportToPDFItem.impact}</div>
                  </Stack.Item>
                  <Stack.Item styles={stackItemStyles}>
                    <Label className="maLabel">Body</Label>
                    <div className="maContent">
                      {this.state.exportToPDFItem.body ?
                        ReactHtmlParser(this.state.exportToPDFItem.body) :
                        ReactHtmlParser("")}</div>
                  </Stack.Item>
                </div>
              </div>
            </PDFExport>
          </div>
        </Stack>
        <BlockUIComp hideLoadingDialog={this.state.hideLoadingDialog} loadingText={this.state.loadingText}></BlockUIComp>
      </div>
    );
  }
 
  private closeDeleteDialog() {
    this.setState({ hideDeleteDialog: true });
  }

  private closeShareDialog() {
    this.setState({ hideShareDialog: true });
  } 

  private onAddNewClick() {
    LoggerService.auditLog("Clicked on Add New Alert button", 'ManageAlerts > onAddNewClick');
    window.location.href = this.props.webURL + this.state.addEditAlertPage;
  }

  private onSignUpClick() {
    try {
      LoggerService.auditLog("Clicked on sign up for alerts button", 'ManageAlerts > onSignUpClick');
      let manageSubPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageSubscriptions);
      let selReg: string = ""; let selTA: string = ""; let selRegT: string = "";
      let navigateTo: string = "";

      if (this._selRegionsObj.length > 0) {
        this._selRegionsObj.map(regEle => { selReg += "," + regEle.key; });
        selReg = selReg.substr(1);
      }
      if (this._selTAObj.length > 0) {
        this._selTAObj.map(regTA => { selTA += "," + regTA.key; });
        selTA = selTA.substr(1);
      }
      if (this._selRegTopicObj.length > 0) {
        this._selRegTopicObj.map(regTEle => { selRegT += "," + regTEle.key; });
        selRegT = selRegT.substr(1);
      }

      navigateTo = this.props.webURL + manageSubPage + "#" + encodeURIComponent("regions=" + selReg + "&tas=" + selTA + "&regtopics=" + selRegT);

      window.location.href = navigateTo;
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > onSignUpClick');
    }
  }

  private _onDDLRegionChange = (event, value): void => {
    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
    this.setMultiselectState(ConfigKey.Region, "selRegion", value);
  }

  private _onDDLTAChange = (event, value): void => {
    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
    this.setMultiselectState(ConfigKey.TherapeuticArea, "selTA", value);
  }

  private _onDDLRegTopicChange = (event, value): void => {
    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
    this.setMultiselectState(ConfigKey.RegulatoryTopic, "selRegTopic", value);
  }

  private _onDDLAuthorChange = (event, value): void => {
    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
    this.setMultiselectState('Author', "selAuthor", value);
  }

  private setMultiselectState = (stateName: string, selStateName: string, ddlVal: any[]) => {
    try {
      let selIDs = this.state[selStateName];
      let keyIdx: number = -1;

      if (ddlVal["selected"]) {
        selIDs.push(ddlVal["key"]);
      } else {
        var keyIdx2 = selIDs.findIndex(x => x == ddlVal["key"]);
        if (keyIdx2 !== -1) {
          selIDs.splice(keyIdx2, 1);
        }
      }

      switch (stateName) {
        case ConfigKey.Region:
          if (ddlVal["selected"]) {
            this._selRegionsObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
          } else {
            keyIdx = this._selRegionsObj.findIndex(x => x.key == ddlVal["key"]);
            if (keyIdx !== -1) {
              this._selRegionsObj.splice(keyIdx2, 1);
            }
          }
          this.setState({ selRegion: [...selIDs] }, () => this.onDDLFilter());
          break;
        case ConfigKey.TherapeuticArea:
          if (ddlVal["selected"]) {
            this._selTAObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
          } else {
            keyIdx = this._selTAObj.findIndex(x => x.key == ddlVal["key"]);
            if (keyIdx !== -1) {
              this._selTAObj.splice(keyIdx2, 1);
            }
          }
          this.setState({ selTA: [...selIDs] }, () => this.onDDLFilter());
          break;
        case ConfigKey.RegulatoryTopic:
          if (ddlVal["selected"]) {
            this._selRegTopicObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
          } else {
            keyIdx = this._selRegTopicObj.findIndex(x => x.key == ddlVal["key"]);
            if (keyIdx !== -1) {
              this._selRegTopicObj.splice(keyIdx2, 1);
            }
          }
          this.setState({ selRegTopic: [...selIDs] }, () => this.onDDLFilter());
          break;
        case "Author":
          if (ddlVal["selected"]) {
            this._selAuthorObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
          } else {
            keyIdx = this._selAuthorObj.findIndex(x => x.key == ddlVal["key"]);
            if (keyIdx !== -1) {
              this._selAuthorObj.splice(keyIdx2, 1);
            }
          }
          this.setState({ selAuthor: [...selIDs] }, () => this.onDDLFilter());
          break;
        default:
          break;
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > setMultiselectState');
    }
  }

  private onSearch(newVal) {
    try {    
      if (newVal.trim().length > 0) {
        newVal = newVal.toLowerCase();
        let filteredAlerts = this.state.allAlerts.filter(item => {
          return (this.state.isUserAdmin && item.status.toLowerCase().indexOf(newVal) >= 0) ||
            item.title.toLowerCase().indexOf(newVal) >= 0 || item.documentType.toLowerCase().indexOf(newVal) >= 0 ||
            item.region.toLowerCase().indexOf(newVal) >= 0 || item.regulatoryTopic.toLowerCase().indexOf(newVal) >= 0 ||
            item.therapeuticArea.toLowerCase().indexOf(newVal) >= 0 ||
            (this.state.isUserAdmin && item.author.toLowerCase().indexOf(newVal) >= 0);
        });
        this.setState({ allAlerts: filteredAlerts, result: process(filteredAlerts.slice(0), this.state.dataState) });
      }     
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > onSearch');
    }
  }

  private onDDLFilter() {
    try {      
      //get fresh data based on new selection of ddls
      let arrFilteredAlerts: any[] = [];
      if (this._selRegionsObj.length == 0 && this._selTAObj.length == 0 && this._selRegTopicObj.length == 0 && this._selAuthorObj.length == 0) {
        this.setState({ allAlerts: this._allAlerts, result: process(this._allAlerts.slice(0), this.state.dataState) }, () => {
          if (this._searchText) {
            this.onSearch(this._searchText);
          }
        });
      }
      else {        
        arrFilteredAlerts = this._allAlerts.filter(item => {
          let regionFlag = true, therapeuticFlag = true, regulatoryTopicFlag = true, authorFlag = true; 
          if (this._selRegionsObj.length > 0) {
            let regSelVals = item.region.split(',').map(reg => reg.toLowerCase().trim());
            if (this._selRegionsObj.filter(ele => regSelVals.indexOf(ele.text.toLowerCase()) !== -1).length == 0)
              regionFlag = false;
          }
          if (this._selTAObj.length > 0) {
            let taSelVals = item.therapeuticArea.split(',').map(ta => ta.toLowerCase().trim());
            if (this._selTAObj.filter(ele => taSelVals.indexOf(ele.text.toLowerCase()) !== -1).length == 0)
              therapeuticFlag = false;
          }
          if (this._selRegTopicObj.length > 0) {
            let regTopicSelVals = item.regulatoryTopic.split(',').map(regT => regT.toLowerCase().trim());
            if (this._selRegTopicObj.filter(ele => regTopicSelVals.indexOf(ele.text.toLowerCase()) !== -1).length == 0)
              regulatoryTopicFlag = false;
          }
          if (this._selAuthorObj.length > 0) {
            let authorSelVals = item.author.toLowerCase().trim();
            if (this._selAuthorObj.filter(ele => authorSelVals.indexOf(ele.text.toLowerCase()) !== -1).length == 0)
              authorFlag = false;
          }
          if (regionFlag && therapeuticFlag && regulatoryTopicFlag && authorFlag) {
            return true;
          }
        });
        
        this.setState({           
          allAlerts: arrFilteredAlerts, result: process(arrFilteredAlerts.slice(0), this.state.dataState)
        }, () => {
            if (this._searchText) {
              this.onSearch(this._searchText);
            }
        });
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > onDDLFilter');
    }
  }

  private deleteAlert = (): void => {
    try {
      Common.recycleAlert(this._configData, ConfigType.Lists, ConfigKey.AlertsDatabase, this._alertIdToDelete).then(resp => {
        LoggerService.auditLog("Alert deleted - " + this._alertIdToDelete, 'ManageAlerts > deleteAlert');
        this.props.onSetNotification({ 'type': NotificationType.success, 'message': `Alert deleted successfully!` });
        var itemIndex = 0;
        for (let index = 0; index < this._allAlerts.length; index++) {
          if (this._allAlerts[index].id == this._alertIdToDelete) {
            itemIndex = index;
            break;
          }
        }
        this._allAlerts.splice(itemIndex, 1);

        this.setState({ allAlerts: this._allAlerts }, () => {
          this.getDistinctAuthors();
          this.onDDLFilter();
        });        
        
        this._alertIdToDelete = 0;
        this.setState({ hideDeleteDialog: true });
      }).catch(error => {
        this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
        LoggerService.errorLog(error, 'ManageAlerts > deleteAlert > deleteAlert');
      });
     
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > deleteAlert');
    }
  }

  private copyToClipboard = (): void => {
    try {
      this._refTextToCopy.current.select();
      document.execCommand('copy');
      LoggerService.auditLog("Alert copied - " + this._refTextToCopy.current, 'ManageAlerts > copyToClipboard');
      this.props.onSetNotification({ 'type': NotificationType.success, 'message': `Alert link copied successfully!` });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > copyToClipboard');
    }
  } 

  private _sortChange = (event) => {
    try {
      this.setState({
        sort: event.sort
      }, () => {
        this.createDataState({
          take: this.state.take,
          skip: this.state.skip,
          sort: this.state.sort
        });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > _sortChange');
    }
  }

  private showIcons = (props) => {
    try {
      return (
        <td>
          <div>
            <Link className='ms-Icon ms-Icon--Preview maIcons' onClick={() => this.onIconClick(AlertIconType.View, props.dataItem)} title="View Alert"></Link>
            {this.state.isUserAdmin ? <Link className='ms-Icon ms-Icon--Edit maIcons' onClick={() => this.onIconClick(AlertIconType.Edit, props.dataItem)} title="Edit Alert"></Link> : null}
            <Link className='ms-Icon ms-Icon--PDF maIcons' onClick={() => this.onIconClick(AlertIconType.PDF, props.dataItem)} title="Export to PDF"></Link>
            <Link className='ms-Icon ms-Icon--Share maIcons' onClick={() => this.onIconClick(AlertIconType.Share, props.dataItem)} title="Share Alert"></Link>
            {this.state.isUserAdmin ? <Link className='ms-Icon ms-Icon--Delete maIcons' onClick={() => this.onIconClick(AlertIconType.Delete, props.dataItem)} title="Delete Alert"></Link> : null}
          </div>
        </td>
      );
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > showIcons');
    }
  }

  private getDistinctAuthors(): void {
    try {
      let arrAuthors: any[] = [];
      let unique = [];
      this.state.allAlerts.map(auth => {
        if (auth.author && !unique[auth.author]) {
          arrAuthors.push(auth.author);
          unique[auth.author] = 1;
        }
      });
      arrAuthors.sort();
      let arrAuthorObj: any[] = [];
      arrAuthors.map((item) => { arrAuthorObj.push({ key: item, text: item }); });
      this.setState({ alertAuthorOptions: arrAuthorObj });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > getDistinctAuthors');
    }
  }

  private dataStateChange = (event) => {
    this.createDataState(event.data);
  }

  private createDataState(dataState: any) {
    try {
      if (this.state)
        this.setState({ result: process(this.state.allAlerts.slice(0), dataState), dataState: dataState });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > createDataState');
    }
  }
}