declare interface IManageAlertsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ManageAlertsWebPartStrings' {
  const strings: IManageAlertsWebPartStrings;
  export = strings;
}
