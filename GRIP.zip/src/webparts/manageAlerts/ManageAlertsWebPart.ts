import "@pnp/polyfill-ie11";
import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'ManageAlertsWebPartStrings';
import ManageAlerts from './components/ManageAlerts';
import { IManageAlertsProps } from './components/IManageAlertsProps';
import { sp } from '@pnp/sp';
import { INotification } from "../../models/INotification";
import { IDynamicDataPropertyDefinition } from '@microsoft/sp-dynamic-data';

export interface IManageAlertsWebPartProps {
  context: string;
}

export default class ManageAlertsWebPart extends BaseClientSideWebPart<IManageAlertsWebPartProps> {
  private _appNotification: INotification;

  protected onInit(): Promise<void> {
    this.context.dynamicDataSourceManager.initializeSource(this);
    this.handleSetNotification = this.handleSetNotification.bind(this);

    return super.onInit().then(_ => {
      sp.setup({
        spfxContext: this.context
      });
    });
  }

  public render(): void {
    const element: React.ReactElement<IManageAlertsProps> = React.createElement(
      ManageAlerts,
      {
        context: this.context,
        webURL: this.context.pageContext.web.absoluteUrl,
        onSetNotification: this.handleSetNotification
      }
    );

    ReactDom.render(element, this.domElement);
  }

  public getPropertyDefinitions(): ReadonlyArray<IDynamicDataPropertyDefinition> {
    return [
      {
        id: 'appNotification',
        title: 'Get App Notification'
      }
    ];
  }

  public getPropertyValue(propertyId: string): boolean | INotification {
    switch (propertyId) {
      case 'publishToExtensions':
        return true;
      case 'appNotification':
        return this._appNotification;
    }
    throw new Error('Bad property ID');
  }

  private handleSetNotification = (appNotification: INotification): void => {
    this._appNotification = appNotification;
    // notify subscribers about the new app notification
    this.context.dynamicDataSourceManager.notifyPropertyChanged('appNotification');
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
