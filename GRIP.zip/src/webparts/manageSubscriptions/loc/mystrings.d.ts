declare interface IManageSubscriptionsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string; 
}

declare module 'ManageSubscriptionsWebPartStrings' {
  const strings: IManageSubscriptionsWebPartStrings;
  export = strings;
}
