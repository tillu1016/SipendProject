import "@pnp/polyfill-ie11";
import * as React from 'react';
import '@progress/kendo-theme-default/dist/all.css';
import styles from './ManageSubscriptions.module.scss';
import { IManageSubscriptionsProps } from './IManageSubscriptionsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { ListService } from '../../../services/ListService';
import { TaxonomyService } from '../../../services/TaxonomyService';
import {
  Stack, IStackStyles, IStackItemStyles, Dropdown, TextField, SearchBox, DetailsList, IColumn, DetailsListLayoutMode, DefaultButton, Dialog, DialogType, SpinButton,
  ComboBox, DialogFooter, PrimaryButton, Link, SelectionMode, TooltipHost, IconButton, IIconProps, Panel, PanelType, Pivot, PivotItem, ProgressIndicator,
  MessageBar, MessageBarType, Label, IComboBoxOption
} from '@fluentui/react';
//from 'office-ui-fabric-react';
import { ITerm, taxonomy } from '@pnp/sp-taxonomy';
import { IAlert, AlertIconType } from '../../../models/IAlert';
import { ISubscription, AlertFrequency, DayOfTheWeek, IUser } from '../../../models/ISubscription';
import { ConfigType, ConfigKey, IConfiguration } from '../../../models/IConfiguration';
import { EmailService } from '../../../services/EmailService';
import { PermissionsService } from '../../../services/PermissionsService';
import { Common } from '../../../common/common';
import { PeoplePicker, PrincipalType } from '@pnp/spfx-controls-react/lib/PeoplePicker';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { sp } from "@pnp/sp";
import { CurrentUser } from '@pnp/sp/src/siteusers';
import { stringIsNullOrEmpty } from "@pnp/common";
import { Pagination } from "@pnp/spfx-controls-react/lib/pagination";
import { Grid, GridColumn } from '@progress/kendo-react-grid';
import { orderBy, process, filterBy } from '@progress/kendo-data-query';
import {
  ColumnMenuTextColumn, ColumnMenuDateColumn
} from '@progress/kendo-react-data-tools';
import { MultiSelect } from '@progress/kendo-react-dropdowns';
import { Tooltip } from '@progress/kendo-react-tooltip';
import { LoggerService } from "../../../services/LoggerService";
import { Subscription } from "@pnp/sp/src/subscriptions";
import { PageName } from '../../../models/IAlertAnalytics';
import { NotificationType } from "../../../models/INotification";
import BlockUIComp from '../../../common/BlockUIComp';
import { ColumnMenu, ColumnMenuCheckboxFilter } from '../../../common/ColumnMenu';
import { GridColumnCell } from '../../../common/GridColumnComp';
import { ExcelExport, ExcelExportColumn } from "@progress/kendo-react-excel-export";

//import { sp } from "@microsoft/sp-page-context";
const stackStyles: IStackStyles = {
  root: {
    padding: 10,
    margin: 10
  }
};
const stackItemStyles: IStackItemStyles = {
  root: {
    padding: 5
  }
};

export interface IManageSubscriptionsState {
  subscriptionTitle: string; alertRegionOptions: any[]; alertTAOptions: any[]; alertRegTopicOptions: any[]; selRegion: any[]; selRegionAddEdit: any[];
  selTA: any[]; selTAAddEdit: any[]; selRegTopic: any[]; selRegTopicAddEdit: any[]; selAlertFrequencyAddEdit: any[]; selAlertDayoftheWeekAddEdit: any[];
  selSubscriber: any[]; searchText: string; listColumns: IColumn[]; allSubscriptions: ISubscription[]; hideSignUpDialog: boolean; isUserAdmin: boolean;
  showNewEditPanel: boolean; editSubmission: any; newEditPanelHeaderText: string; hideViewPanel: boolean; hideEditPanel: boolean; hideDeleteDialog: boolean;
  alertSubscribers: IUser[]; alertSubscribersOptions: any[]; alertSubscribersWithEmail: string[]; alertOnBehalf: IUser[]; alertOnBehalfWithEmail: string[];
  isShowPanel: boolean; showingLoadingBar: boolean; showSuccessMessage: boolean; showErrorMessage: boolean; alertFrequencyOptions: any[];
  isViewMode: boolean; isOnBehalfHide: boolean; skip: number; take: number; columns: any; sort: any[]; filter: any; pageable: any; hideLoadingDialog: boolean;
  loadingText: string; disableSubmitButton: boolean; isDuplicateSubscription: boolean; createDuplicateSubscription: boolean;
  titleErrorMessage: string; subscriberErrorMessage: string; regionErrorMessage: string; taErrorMessage: string; topicErrorMessage: string; frequencyErrorMessage: string;
  subscriptionsSelectionLimit: number; isDDLFiltered: boolean; isSearchingSubscriptions: boolean; result: any; dataState: any;
  showmessage: boolean; dailymessage: string; weeklymessage: string; showShimmer: boolean;
}

const regExp = /\(([^)]+)\)/;

export default class ManageSubscriptions extends React.Component<IManageSubscriptionsProps, IManageSubscriptionsState> {
  private _configData: IConfiguration[] = [];
  private _allSubscriptions: ISubscription[] = [];
  private _selRegionsObj: any[] = [];
  private _selRegionsAddEditObj: any[] = [];
  private _selTAObj: any[] = [];
  private _selTAAddEditObj: any[] = [];
  private _selRegTopicObj: any[] = [];
  private _selRegTopicAddEditObj: any[] = [];
  private _selAlertFrequencyAddEditObj: any[] = [];
  private _selSubscriberObj: any[] = [];
  private _subscriptionIdToEdit: number = 0;
  private _subscriptionIdToDelete: number = 0;
  private _subscriptionToDelete: ISubscription;
  private _currUser: CurrentUser;
  private _itemId: number = 0;
  private _isQueryStringRead: boolean = false;
  private _searchText: string = "";

  public _mngSubscriptionsGridExcelExport;

  constructor(props) {
    super(props);
    const dataState = this.createDataState({
      take: Common.pageSize,
      skip: 0,
      sort: []
    });

    this.state = {
      subscriptionTitle: '', alertRegionOptions: [], alertTAOptions: [], alertRegTopicOptions: [], selRegion: [], selRegionAddEdit: [],
      selTA: [], selTAAddEdit: [], selRegTopic: [], selRegTopicAddEdit: [], selAlertFrequencyAddEdit: [], selAlertDayoftheWeekAddEdit: [],
      selSubscriber: [], searchText: '', listColumns: [], allSubscriptions: [], hideSignUpDialog: true, isUserAdmin: false,
      showNewEditPanel: false, editSubmission: [], newEditPanelHeaderText: "", hideViewPanel: true, hideEditPanel: true,
      hideDeleteDialog: true, alertSubscribers: [], alertSubscribersOptions: [], alertSubscribersWithEmail: [], alertOnBehalf: [],
      alertOnBehalfWithEmail: [], isShowPanel: false, showingLoadingBar: false, showSuccessMessage: false, showErrorMessage: false,
      alertFrequencyOptions: [], isViewMode: false, isOnBehalfHide: true, skip: 0, take: Common.pageSize, columns: [],
      sort: [], filter: { logic: "and", filters: [] }, hideLoadingDialog: false, loadingText: "Please Wait...", disableSubmitButton: true,
      isDuplicateSubscription: false, createDuplicateSubscription: false, titleErrorMessage: '', subscriberErrorMessage: '',
      regionErrorMessage: '', taErrorMessage: '', topicErrorMessage: '', frequencyErrorMessage: '', subscriptionsSelectionLimit: 1000,
      isDDLFiltered: false, isSearchingSubscriptions: false, result: [], dataState: [], showmessage: true, dailymessage: "",
      weeklymessage: "", showShimmer: false,
      pageable: {
        buttonCount: 5,
        info: true,
        type: 'numeric',
        pageSizes: [50, 100, 200],
        previousNext: true
      }
    };
  }

  public componentDidMount() {
    this.setState({ ...this.state, showingLoadingBar: false, showSuccessMessage: false, showErrorMessage: false });

    try {
      Common.getConfigData().then(resp => {
        if (resp) {
          this._configData = resp;
          this._getAlertFrequency();
          Common.pageSize = Number.parseInt(Common.getConfigValue(resp, ConfigType.Grid, ConfigKey.PageSize));

          Common.getCurrentUserId().then((curUser: CurrentUser) => {
            this._currUser = curUser;
            let adminGrpName: string = Common.getConfigValue(this._configData, ConfigType.Roles, ConfigKey.Administrator);
            Common.checkIfUserAdmin(adminGrpName).then(isUsrAdm => {
              //log user visits          
              let AlertAnalyticsList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AlertAnalytics);
              Common.logSiteVisit(AlertAnalyticsList, PageName.ManageSubscriptions, isUsrAdm, this._currUser["Id"], null);

              this.setState({ isUserAdmin: isUsrAdm, take: Common.pageSize }, () => {
                this.getSubscriptionsDataTemp();
              });
            });
          });

          Common.errorLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ErrorLog);
          Common.auditLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AuditLog);

          Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.Region).then(regions => {
            this.setState({ alertRegionOptions: regions });
          });
          Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.RegulatoryTopic).then(regTopics => {
            this.setState({ alertRegTopicOptions: regTopics });
          });
          Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.TherapeuticArea).then(tas => {
            this.setState({ alertTAOptions: tas });
          });

          let subscriptionFlag = Common.getConfigValue(resp, ConfigType.Subscription, ConfigKey.SubscriptionShowMessage).toLowerCase() == "true" ? true : false;
          this.setState({
            showmessage: subscriptionFlag,
            weeklymessage: Common.getConfigValue(resp, ConfigType.Subscription, ConfigKey.SubscriptionWeeklyMessage),
            dailymessage: Common.getConfigValue(resp, ConfigType.Subscription, ConfigKey.SubscriptionDailyMessage)
          });
        }
      });
    }
    catch (error) {
      LoggerService.errorLog(error, 'ManageSubcriptions > componentDidMount');
    }
  }

  private onIconClick(type: string, item: any) {
    try {
      switch (type) {
        case AlertIconType.View:
          this._subscriptionIdToEdit = item.id;
          this.setState({ showingLoadingBar: true, alertSubscribersWithEmail: [], isViewMode: true, isShowPanel: true }, () => {
            //add audit log
            LoggerService.auditLog("Subscription with ID: " + item.id + " has been viewed", 'ManageSubscription > onIconClick');
            this.populateAddEditSubscription(this._subscriptionIdToEdit);
          });
          break;
        case AlertIconType.Edit: {
          this._subscriptionIdToEdit = item.id;
          this.setState({ showingLoadingBar: true, alertSubscribersWithEmail: [], isShowPanel: true, isViewMode: false, disableSubmitButton: true }, () => this.populateAddEditSubscription(this._subscriptionIdToEdit));
          break;
        }
        case AlertIconType.Delete:
          this.setState({ isViewMode: false, isShowPanel: false, hideDeleteDialog: false });
          this._subscriptionIdToDelete = item.id;
          this._subscriptionToDelete = item;
          break;
        default:
          break;
      }
      //console.log(type, item);
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubcriptions > onIconClick');
    }
  }

  private _getAlertFrequency() {
    let arrAlertFrequency: any[] = [];
    Object.keys(AlertFrequency).map((option, index) => {
      arrAlertFrequency.push({
        key: index + 1,
        text: option
      });
    });
    this.setState({ alertFrequencyOptions: arrAlertFrequency });
  }

  private async getSubscriptionsDataTemp() {
    try {

      let cmlQuery: string = "<View><Query>";

      if (!this.state.isUserAdmin) {
        cmlQuery += `<Where>
	                  <Or>
		                  <Eq>
			                  <FieldRef Name='ASSubscriber' LookupId='True'/>
			                  <Value Type='User'>${this._currUser["Id"]}</Value>
		                  </Eq>
		                  <Eq>
			                  <FieldRef Name='ASOnBehalf' LookupId='True'/>
			                  <Value Type='User'>${this._currUser["Id"]}</Value>
		                  </Eq>		
	                  </Or>
                  </Where>`;
      }
      cmlQuery += "<OrderBy><FieldRef Name='Modified' Ascending='False' /></OrderBy></Query>";
      cmlQuery += "<ViewFields><FieldRef Name='ID' /></ViewFields>";
      cmlQuery += "<RowLimit Paged='TRUE'>5000</RowLimit></View>";

      await ListService.getDataFromLargeList(ConfigKey.Subscriptions, cmlQuery).then(response => {
        if (response) {
          this._allSubscriptions = [];
          response.Row.map((subscription) => {
            this._allSubscriptions.push({
              id: subscription['ID'],
              title: '',
              region: '',
              regulatoryTopic: '',
              therapeuticArea: '',
              subscriber: '',
              subscriberId: null,
              subscriberEmail: '',
              onBehalf: '',
              onBehalfId: null,
              onBehalfEmail: '',
              frequency: '',
              createdDate: null,
              count: 0
            });
          });

          this.setState({ allSubscriptions: this._allSubscriptions }, () => {
            this.createDataState({ take: this.state.take, skip: this.state.skip, sort: this.state.sort });
            this._getQueryParam();
            if (this.state.allSubscriptions.length > 0) {
              this.getSubscriptionsData(0, (this.state.allSubscriptions.length - 1 > 49) ? 49 : this.state.allSubscriptions.length - 1);
            }
            else {
              this.setState({ hideLoadingDialog: true });
            }
          });
        }
      }).catch(error => {
        console.log(error);
        LoggerService.errorLog(error, 'ManageSubcriptions > > getDataFromLargeList > getSubscriptionsDataTemp');
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubcriptions > getSubscriptionsDataTemp');
    }
  }

  private async getSubscriptionsData(startIndex: number, endIndex: number) {
    try {
      let cmlQuery: string = "<View><Query><Where><In><FieldRef Name='ID' /><Values>";
      for (let i = startIndex; i <= endIndex; i++) {
        cmlQuery += `<Value Type='Number'>${this.state.allSubscriptions[i].id}</Value>`;
      }
      cmlQuery += "</Values></In></Where><OrderBy><FieldRef Name='Modified' Ascending='False' /></OrderBy></Query>";
      cmlQuery += "<ViewFields><FieldRef Name='ID' /><FieldRef Name='Title' /><FieldRef Name='G2Region' /><FieldRef Name='G2RegulatoryTopic' /><FieldRef Name='G2TherapeuticArea' /><FieldRef Name='ASSubscriber' /><FieldRef Name='ASOnBehalf' /><FieldRef Name='ASFrequency' /><FieldRef Name='Author' /><FieldRef Name='Created' /><FieldRef Name='Modified' /><FieldRef Name='Editor' /></ViewFields>";
      cmlQuery += "<ExpandUserField>True</ExpandUserField></View>";

      await ListService.getDataFromLargeList(ConfigKey.Subscriptions, cmlQuery).then(response => {
        if (response) {
          response.Row.map((subscription) => {
            let subscriptionItem = this._allSubscriptions.find(item => item.id == subscription['ID']);
            if (subscriptionItem) {
              let subscribertitle = '', subscriberid = '', subscriberEmail = '', onbehalf = '', onbehalfid = '', onbehalfEmail = '';
              if (subscription.ASSubscriber && subscription.ASSubscriber.length > 0) {
                subscribertitle = subscription.ASSubscriber[0].title;
                subscriberid = subscription.ASSubscriber[0].id;
                subscriberEmail = subscription.ASSubscriber[0].email;
              }
              if (subscription.ASOnBehalf && subscription.ASOnBehalf.length > 0) {
                onbehalf = subscription.ASOnBehalf[0].title;
                onbehalfid = subscription.ASOnBehalf[0].id;
                onbehalfEmail = subscription.ASOnBehalf[0].email;
              }

              subscriptionItem.title = subscription['Title'];
              subscriptionItem.region = Common.getManagedMetadataString(subscription['G2Region']);
              subscriptionItem.regulatoryTopic = Common.getManagedMetadataString(subscription['G2RegulatoryTopic']);
              subscriptionItem.therapeuticArea = Common.getManagedMetadataString(subscription['G2TherapeuticArea']);
              subscriptionItem.subscriber = subscribertitle;
              subscriptionItem.subscriberId = parseInt(subscriberid);
              subscriptionItem.subscriberEmail = subscriberEmail;
              subscriptionItem.onBehalf = onbehalf;
              subscriptionItem.onBehalfId = parseInt(onbehalfid);
              subscriptionItem.onBehalfEmail = onbehalfEmail;
              subscriptionItem.frequency = subscription['ASFrequency'];
              subscriptionItem.createdDate = subscription['Created'];
              subscriptionItem.count = 0;
            }
          });
        }

        this.setState({ allSubscriptions: this._allSubscriptions, hideLoadingDialog: true }, () => {
          this.createDataState({ take: this.state.take, skip: this.state.skip, sort: this.state.sort });
          this._getDistinctSubscriber();
          this.onDDLFilter();

          if (endIndex >= this.state.allSubscriptions.length - 1) {
            console.log("data prepared:" + new Date());
            this.setState({ showShimmer: false });
          }
          else if (endIndex + 400 > this.state.allSubscriptions.length - 1) {
            if (endIndex + 50 > this.state.allSubscriptions.length - 1) {
              this.getSubscriptionsData(endIndex + 1, this.state.allSubscriptions.length - 1);
            }
            else {
              this.getSubscriptionsData(endIndex + 1, endIndex + 50);
            }
            this.setState({ showShimmer: true });
          }
          else {
            this.getSubscriptionsData(endIndex, endIndex + 400);
            this.setState({ showShimmer: true });
          }
        });
      }).catch(error => {
        console.log(error);
        LoggerService.errorLog(error, 'ManageSubcriptions > getDataFromLargeList > getSubscriptionsData');
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubcriptions > getSubscriptionsData');
    }
  }

  private _getDistinctSubscriber(): void {
    try {
      let arrSubscribers: any[] = [];
      let unique = [];
      this.state.allSubscriptions.map(auth => {
        if (auth.subscriber && !unique[auth.subscriber]) {
          arrSubscribers.push(auth.subscriber);
          unique[auth.subscriber] = 1;
        }
      });
      arrSubscribers.sort();
      let arrSubscriberObj: any[] = [];
      arrSubscribers.map((item) => { arrSubscriberObj.push({ key: item, text: item }); });
      this.setState({ alertSubscribersOptions: arrSubscriberObj });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > getDistinctAuthors');
    }
  }

  private MSColumnMenuCheckboxFilter = (props) => <ColumnMenuCheckboxFilter {...props} data={this.state.allSubscriptions} />;

  private filterddlElements = (element) => {
    if (element.tagName === 'label') {
      return true;
    }
    return false;
  }

  public render(): React.ReactElement<IManageSubscriptionsProps> {
    return (
      <div className={styles.manageSubscriptions}>
        <Stack>
          <Stack.Item>
            <h1>Manage Subscriptions</h1>
          </Stack.Item>
          <Stack.Item className="filter_container">
            <div className="filterSectionLeft">
              <div className="maFiltersDropdown2">
                <Dropdown
                  placeholder="Select an option"
                  label="Region"
                  options={this.state.alertRegionOptions}
                  multiSelect
                  onChange={this._onDDLRegionChange.bind(this)}
                  selectedKeys={this.state.selRegion}
                  dropdownWidth={350}
                />
              </div>
              <div className="maFiltersDropdown2">
                <Dropdown
                  placeholder="Select an option"
                  label="Therapeutic Area"
                  multiSelect
                  options={this.state.alertTAOptions}
                  onChange={this._onDDLTAChange.bind(this)}
                  selectedKeys={this.state.selTA}
                  dropdownWidth={350}
                />
              </div>
              <div className="maFiltersDropdown2">
                <Dropdown
                  placeholder="Select an option"
                  label="Regulatory Topic"
                  multiSelect
                  options={this.state.alertRegTopicOptions}
                  onChange={this._onDDLRegTopicChange.bind(this)}
                  selectedKeys={this.state.selRegTopic}
                  dropdownWidth={350}
                />
              </div>
              {this.state.isUserAdmin ?
                <div className="maFiltersDropdown2">
                  <Dropdown
                    placeholder="Select Subscriber(s)"
                    label="Subscribers"
                    multiSelect
                    options={this.state.alertSubscribersOptions}
                    onChange={this._onDDLAlertSubscriberChange.bind(this)}
                    selectedKeys={this.state.selSubscriber}
                    dropdownWidth={350}
                  />
                </div>
                : null}
            </div>
            <div className="filterSectionRight">
              <div className="maSignUpContainer">
                <PrimaryButton className="maSignUpButton" text="Sign Up for Alerts" onClick={this.onSignUpClick.bind(this)} />
              </div>

              {this.state.isUserAdmin ?
                <div className="exportExcelContainer">
                  <PrimaryButton className="maSignUpButton" disabled={this.state.showShimmer} text="Export to Excel" onClick={this.onExportToExcelClick.bind(this)} />
                </div>
                : null}

              <div className="maSearchBox">
                <SearchBox className="searchBox" placeholder="Filter Subscriptions" //onSearch={newValue => this.onSearch(newValue)}
                  onClear={ev => {
                    this._searchText = '';
                    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
                    this.onDDLFilter();
                  }}
                  onChange={(newValue) => {
                    let srchTxt: string = newValue ? newValue.currentTarget.value : "";
                    this._searchText = srchTxt;
                    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
                    this.onDDLFilter();
                  }}
                />
              </div>
            </div>
          </Stack.Item>
          <Stack.Item className="progressDiv" styles={stackItemStyles}>
            {
              this.state.showShimmer ?
                <ProgressIndicator />
                :
                ""
            }
          </Stack.Item>
          <Stack.Item>
            <Tooltip openDelay={100} position="auto" anchorElement="element">
              <ExcelExport
                data={orderBy(this.state.allSubscriptions, this.state.sort)}
                fileName={"Manage Subscriptions.xlsx"}
                ref={excelExport => (this._mngSubscriptionsGridExcelExport = excelExport)}
              >
                <ExcelExportColumn field="title" title="Title" width={300} />
                <ExcelExportColumn field="frequency" title="Frequency" width={150} />
                <ExcelExportColumn field="region" title="Region" width={250} />
                <ExcelExportColumn field="therapeuticArea" title="Therapeutic Area" width={300} />
                <ExcelExportColumn field="regulatoryTopic" title="Regulatory Topic" width={350} />
                {this.state.isUserAdmin ?
                  <ExcelExportColumn field="subscriber" title="Subscriber" width={250} />
                  : null}
                {this.state.isUserAdmin ?
                  <ExcelExportColumn field="onBehalf" title="Subscribed By" width={250} />
                  : null}
              </ExcelExport>
              <Grid
                style={{ height: '600px' }}
                data={this.state.result.length > 0 ? orderBy(this.state.result.data, this.state.sort) : this.state.result}
                {...this.state.dataState}
                onDataStateChange={this.dataStateChange}
                total={this.state.result.total}
                sortable={true}
                sort={this.state.sort}
                onSortChange={(e) => { this._sortChange(e); }}
                pageable={this.state.pageable}
                resizable={true}
                reorderable={true}
              >
                <GridColumn field="icons" title="Actions" width="100px" cell={this.showIcons} sortable={false} filterable={false} resizable={false}></GridColumn>
                <GridColumn field="title" title="Title" width="300px" filter="text" columnMenu={ColumnMenu} cell={GridColumnCell}></GridColumn>
                <GridColumn field="frequency" title="Frequency" width="150px" resizable={false} columnMenu={this.MSColumnMenuCheckboxFilter}></GridColumn>
                <GridColumn field="region" title="Region" width="250px" filterable={false} cell={GridColumnCell}></GridColumn>
                <GridColumn field="therapeuticArea" title="Therapeutic Area" width="300px" filterable={false} cell={GridColumnCell}></GridColumn>
                <GridColumn field="regulatoryTopic" title="Regulatory Topic" width="350px" filterable={false} cell={GridColumnCell}></GridColumn>
                {this.state.isUserAdmin ?
                  <GridColumn field="subscriber" title="Subscriber" width="250px" filterable={true} columnMenu={this.MSColumnMenuCheckboxFilter} cell={GridColumnCell}></GridColumn>
                  : null}
                {this.state.isUserAdmin ?
                  <GridColumn field="onBehalf" title="Subscribed By" width="250px" filterable={true} columnMenu={this.MSColumnMenuCheckboxFilter} cell={GridColumnCell}></GridColumn>
                  : null}
              </Grid>

            </Tooltip>
          </Stack.Item>
          <Stack.Item>
            <Panel
              isBlocking={false}
              isOpen={this.state.isShowPanel}
              onDismiss={this.closePanel.bind(this)}
              closeButtonAriaLabel="Close"
              type={PanelType.medium} >
              <Stack>
                <Stack.Item>
                  <Pivot selectedKey="gripalert">
                    <PivotItem headerText={this.state.isViewMode ? 'View - Sign up for Alert' : this._subscriptionIdToEdit ? 'Edit- Sign up for Alert' : 'Sign up for Alert'} itemKey='gripalert'>

                      {this.state.showingLoadingBar ?
                        <Stack.Item styles={stackItemStyles} className="gripalert_progress">
                          <ProgressIndicator />
                        </Stack.Item> : null}
                      {this.state.showSuccessMessage ? <Stack.Item className="gripalert_mgs">
                        <MessageBar messageBarType={MessageBarType.success} isMultiline={false} onDismiss={() => {
                          this.setState({ ...this.state, showSuccessMessage: false });
                        }}>
                          GRIP Subscription email has been sent successfully.
                            </MessageBar>
                      </Stack.Item> : null}
                      {this.state.showErrorMessage ? <Stack.Item>
                        <MessageBar messageBarType={MessageBarType.error} isMultiline={false} onDismiss={() => {
                          this.setState({ ...this.state, showErrorMessage: false });
                        }}>
                          Something went wrong. Please contact system administrator.
                            </MessageBar>
                      </Stack.Item> : null}
                      {this.state.isViewMode ? <Stack.Item className="view_signup" styles={stackItemStyles}>
                        <Label>Subscription Title</Label>
                        <div> {this.state.subscriptionTitle} </div>
                      </Stack.Item>
                        :
                        <Stack.Item className="edit_signup" styles={stackItemStyles}>
                          <TextField
                            label="Subscription Title"
                            value={this.state.subscriptionTitle}
                            onChange={this.onTitleTextChanged.bind(this)}
                            required={true}
                          />
                        </Stack.Item>
                      }
                      {this.state.isViewMode ? <Stack.Item className="view_signup" styles={stackItemStyles}>
                        <Label>Subscriber(s)</Label>
                        <div> {this.state.editSubmission ? this.state.editSubmission.subscriber : ''} </div>
                      </Stack.Item>
                        :
                        <Stack.Item className="edit_signup" styles={stackItemStyles}>
                          <PeoplePicker
                            context={this.props.context}
                            tooltipMessage="Select Subscriber(s)"
                            titleText="Subscriber(s)"
                            personSelectionLimit={this.state.subscriptionsSelectionLimit}
                            groupName={""}
                            showtooltip={true}
                            selectedItems={this._getPeoplePickerItems.bind(this)}
                            defaultSelectedUsers={this.state.alertSubscribersWithEmail}
                            showHiddenInUI={false}
                            principalTypes={[PrincipalType.User]}
                            ensureUser={true}
                            resolveDelay={1000}
                          />
                        </Stack.Item>
                      }
                      {this.state.isViewMode && this.state.isUserAdmin ?
                        <Stack.Item className="view_signup" styles={stackItemStyles}>
                          <Label>Subscribed By</Label>
                          <div> {this.state.editSubmission ? this.state.editSubmission.onBehalf : ''} </div>
                        </Stack.Item>
                        : null
                      }
                      {!this.state.isViewMode && this.state.isUserAdmin && !this.state.isOnBehalfHide ?
                        <Stack.Item className="edit_signup" styles={stackItemStyles}>
                          <PeoplePicker
                            context={this.props.context}
                            tooltipMessage="Edit Subscribed By"
                            titleText="Subscribed By"
                            personSelectionLimit={1}
                            groupName={""}
                            showtooltip={true}
                            selectedItems={this._getOnBehalfPeoplePickerItems.bind(this)}
                            defaultSelectedUsers={this.state.alertOnBehalfWithEmail}
                            showHiddenInUI={false}
                            principalTypes={[PrincipalType.User]}
                            ensureUser={true}
                            resolveDelay={1000} />
                        </Stack.Item>
                        : null
                      }
                      {this.state.isViewMode ? <Stack.Item className="view_signup" styles={stackItemStyles}>
                        <Label>Region</Label>
                        <div> {this.state.editSubmission ? this.state.editSubmission.region : ''} </div>
                      </Stack.Item>
                        :
                        <Stack.Item className="edit_signup" styles={stackItemStyles}>
                          <div className="msFiltersDropdown">
                            <Dropdown
                              placeholder="Select an option"
                              label="Region"
                              options={this.state.alertRegionOptions}
                              multiSelect
                              required={true}
                              onChange={this._onPanelDDLRegionChange.bind(this)}
                              selectedKeys={this.state.selRegionAddEdit}
                            />
                          </div>
                        </Stack.Item>
                      }
                      {this.state.isViewMode ? <Stack.Item className="view_signup" styles={stackItemStyles}>
                        <Label>Therapeutic Area</Label>
                        <div> {this.state.editSubmission ? this.state.editSubmission.therapeuticArea : ''} </div>
                      </Stack.Item>
                        :
                        <Stack.Item className="edit_signup" styles={stackItemStyles}>
                          <div className="msFiltersDropdown">
                            <Dropdown
                              placeholder="Select an option"
                              label="Therapeutic Area"
                              multiSelect
                              required={true}
                              options={this.state.alertTAOptions}
                              onChange={this._onPanelDDLTAChange.bind(this)}
                              selectedKeys={this.state.selTAAddEdit}
                            />
                          </div>
                        </Stack.Item>
                      }
                      {this.state.isViewMode ? <Stack.Item className="view_signup" styles={stackItemStyles}>
                        <Label>Regulatory Topic</Label>
                        <div> {this.state.editSubmission ? this.state.editSubmission.regulatoryTopic : ''} </div>
                      </Stack.Item>
                        :
                        <Stack.Item className="edit_signup" styles={stackItemStyles}>
                          <div className="msFiltersDropdown">
                            <Dropdown
                              placeholder="Select an option"
                              label="Regulatory Topic"
                              multiSelect
                              required={true}
                              options={this.state.alertRegTopicOptions}
                              onChange={this._onPanelDDLRegTopicChange.bind(this)}
                              selectedKeys={this.state.selRegTopicAddEdit}
                            />
                          </div>
                        </Stack.Item>
                      }
                      {this.state.isViewMode ? <Stack.Item className="view_signup" styles={stackItemStyles}>
                        <Label>Frequency</Label>
                        <div> {this.state.editSubmission ? this.state.editSubmission.frequency : ''} </div>
                      </Stack.Item>
                        :
                        <Stack.Item className="edit_signup" styles={stackItemStyles}>
                          <div className="msFiltersDropdown">
                            <Dropdown
                              placeholder="Select Frequency"
                              label="Frequency"
                              required={true}
                              options={this.state.alertFrequencyOptions}
                              onChange={this._onPanelDDLAlertFrequencyChange.bind(this)}
                              selectedKey={this.state.selAlertFrequencyAddEdit}
                            />
                          </div>
                        </Stack.Item>
                      }
                      {
                        this.state.showmessage ?
                          this._selAlertFrequencyAddEditObj && this._selAlertFrequencyAddEditObj.length > 0 && this._selAlertFrequencyAddEditObj[0].text != "Immediate" ?
                            this._selAlertFrequencyAddEditObj && this._selAlertFrequencyAddEditObj.length > 0 && this._selAlertFrequencyAddEditObj[0].text == "Daily" ?
                              <Stack.Item className="" styles={stackItemStyles}>
                                <Label>{this.state.dailymessage}</Label>
                              </Stack.Item>
                              :
                              <Stack.Item className="" styles={stackItemStyles}>
                                <Label>{this.state.weeklymessage}</Label>
                              </Stack.Item>
                            :
                            null
                          :
                          null
                      }
                    </PivotItem>
                  </Pivot>
                </Stack.Item>
                <Stack.Item styles={stackItemStyles} className="btn_fixed_bottom">
                  <Stack horizontal styles={stackStyles}>
                    <DefaultButton className="gry_btn" text="Cancel" onClick={this.closePanel.bind(this)} disabled={this.state.showingLoadingBar} />
                    {this.state.isViewMode ? <div></div> :
                      <PrimaryButton className="blu_btn" text="Submit"
                        onClick={() => this.setState({ hideLoadingDialog: false }, this.submitPanelSignUp.bind(this))}
                        disabled={this.state.disableSubmitButton} />
                    }
                  </Stack>
                </Stack.Item>
              </Stack>
            </Panel>

            <Dialog
              hidden={this.state.hideDeleteDialog}
              onDismiss={this.closeDeleteDialog.bind(this)}
              dialogContentProps={{
                type: DialogType.normal,
                title: 'Delete Subscription',
                subText: "Do you want to delete this subscription?"
              }}
              modalProps={{
                isBlocking: true,
                containerClassName: 'ms-dialogMainOverride'
              }}
            >
              <DialogFooter>
                <PrimaryButton onClick={this.recycleSubscription.bind(this)} text="Confirm" />
                <DefaultButton onClick={this.closeDeleteDialog.bind(this)} text="Cancel" />
              </DialogFooter>
            </Dialog>
            <Dialog
              hidden={!this.state.isDuplicateSubscription}
              onDismiss={this.closeDuplicateDialog.bind(this)}
              dialogContentProps={{
                type: DialogType.normal,
                title: 'Duplicate Subscription',
                subText: "We have found a subscription with the same details. Please confirm to create the duplicate subscription?"
              }}
              modalProps={{
                isBlocking: true,
                containerClassName: 'ms-dialogMainOverride'
              }}
            >
              <DialogFooter>
                <PrimaryButton onClick={this.createDuplicateSubscription.bind(this)} text="Confirm" />
                <DefaultButton onClick={this.closeDuplicateDialog.bind(this)} text="Cancel" />
              </DialogFooter>
            </Dialog>
          </Stack.Item>
        </Stack>
        <BlockUIComp hideLoadingDialog={this.state.hideLoadingDialog} loadingText={this.state.loadingText}></BlockUIComp>
      </div >
    );
  }

  private _pageChange = (event) => {
    this.setState({
      skip: event.page.skip,
      take: event.page.take
    });
    LoggerService.auditLog("Grid page changed - ", 'ManageSubscriptions > _pageChange');
  }

  private showIcons = (props) => {
    try {
      return (
        <td>
          <div>
            <Link className='ms-Icon ms-Icon--Preview maIcons' onClick={() => this.onIconClick(AlertIconType.View, props.dataItem)} title="View Subscription"></Link>
            <Link className='ms-Icon ms-Icon--Edit maIcons' onClick={() => this.onIconClick(AlertIconType.Edit, props.dataItem)} title="Edit Subscription"></Link>
            <Link className='ms-Icon ms-Icon--Delete maIcons' onClick={() => this.onIconClick(AlertIconType.Delete, props.dataItem)} title="Delete Subscription"></Link>
          </div>
        </td>
      );
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubscriptions > showIcons');
    }
  }

  private _getPeoplePickerItems(items: any[]) {
    let arrUsers: IUser[] = [];
    items.forEach(element => {
      arrUsers.push({ email: element.secondaryText, id: element.id, title: element.text });
    });
    this.setState({ alertSubscribers: arrUsers }, () => this._validate());
  }

  private setPeoplePicker() {
    if (this.state.alertSubscribers && this.state.alertSubscribers.length > 0) {
      this.setState({ showingLoadingBar: false }, () => {
        this.state.alertSubscribers.forEach(async element => {
          if (element.email) {
            this.setState({ alertSubscribersWithEmail: [...this.state.alertSubscribersWithEmail, element.email] });
          }
          else {
            await sp.web.getUserById(element.id).select("Email").get().then(rslt => {
              this.setState({ alertSubscribersWithEmail: [...this.state.alertSubscribersWithEmail, rslt.Email] });
            });
          }
        });
      });
    }
  }

  private _getOnBehalfPeoplePickerItems(items: any[]) {
    let arrUsers: IUser[] = [];
    items.forEach(element => {
      arrUsers.push({ email: element.secondaryText, id: element.id, title: element.text });
    });
    this.setState({ alertOnBehalf: arrUsers }, () => this._validate());
  }

  private setOnBehalfPeoplePicker() {
    if (this.state.alertOnBehalf && this.state.alertOnBehalf.length > 0) {
      this.setState({ showingLoadingBar: false }, () => {
        this.state.alertOnBehalf.forEach(async element => {
          if (element.email) {
            this.setState({ alertOnBehalfWithEmail: [...this.state.alertOnBehalfWithEmail, element.email] });
          }
          else {
            await sp.web.getUserById(element.id).select("Email").get().then(rslt => {
              this.setState({ alertOnBehalfWithEmail: [...this.state.alertOnBehalfWithEmail, rslt.Email] });
            });
          }
        });
      });
    }
  }

  private _panelCallBack = (): void => {
    this.setState({ showNewEditPanel: false });
  }

  private closePanel() {
    LoggerService.auditLog("Panel cancel button clicked", 'ManageSubscriptions > closePanel');
    this.setState({ isShowPanel: false, isViewMode: false });
    this._isQueryStringRead = true;
  }

  private closeDeleteDialog() {
    this.setState({ hideDeleteDialog: true });
  }

  private submitPanelSignUp() {
    try {
      if (this._validate()) {
        if (this.state.editSubmission.length == 0) { // New Subscription
          if (!this.matchingSubmissionFound()) {
            this.setState({
              disableSubmitButton: false,
              isDuplicateSubscription: false
            }, () => {
              this.initiateSaveSubscriptions();
            });
          }
          else {
            this.setState({
              disableSubmitButton: true,
              isDuplicateSubscription: true
            });
          }
        }
        else {
          this.initiateSaveSubscriptions();
        }
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubcriptions > submitPanelSignUp');
    }
  }

  private initiateSaveSubscriptions() {
    let subscriptionListName = this._configData.filter((item) => {
      return item.title == ConfigType.Lists && item.key == ConfigKey.Subscriptions;
    })[0].value;

    let tmpRegions: string = '';
    let tmpRegionsItem: string = '';
    if (this.state.selRegionAddEdit) {
      this.state.selRegionAddEdit.forEach(region => {
        let regionf = this.state.alertRegionOptions.filter(robj => {
          return robj.key === region;
        });
        if (regionf.length > 0)
          regionf = regionf[0];

        if (tmpRegions == '') {
          tmpRegions = `-1;#${regionf["text"]}|${regionf["key"]}`;
          tmpRegionsItem = regionf["text"];
        }
        else {
          tmpRegions += `;#-1;#${regionf["text"]}|${regionf["key"]}`;
          tmpRegionsItem += ", " + regionf["text"];
        }
      });
    }

    let tmpRegTopic: string = '';
    let tmpRegTopicItem: string = '';
    if (this.state.selRegTopicAddEdit) {
      this.state.selRegTopicAddEdit.forEach(topic => {

        let topicf = this.state.alertRegTopicOptions.filter(robj => {
          return robj.key === topic;
        });
        if (topicf.length > 0) {
          topicf = topicf[0];
        }
        if (tmpRegTopic == '') {
          tmpRegTopic = `-1;#${topicf["text"]}|${topicf["key"]}`;
          tmpRegTopicItem = topicf["text"];
        }
        else {
          tmpRegTopic += `;#-1;#${topicf["text"]}|${topicf["key"]}`;
          tmpRegTopicItem += ", " + topicf["text"];
        }
      });
    }

    let tmpTA: string = '';
    let tmpTAItem: string = '';
    if (this.state.selTAAddEdit) {
      this.state.selTAAddEdit.forEach(TA => {
        let taf = this.state.alertTAOptions.filter(robj => {
          return robj.key === TA;
        });
        if (taf.length > 0) {
          taf = taf[0];
        }

        if (tmpTA == '') {
          tmpTA = `-1;#${taf["text"]}|${taf["key"]}`;
          tmpTAItem = taf["text"];
        }
        else {
          tmpTA += `;#-1;#${taf["text"]}|${taf["key"]}`;
          tmpTAItem += ", " + taf["text"];
        }
      });
    }

    let tmpFrequency: string = "";
    if (this.state.selAlertFrequencyAddEdit.length > 0) {

      let tmpFrequencyArr = this.state.alertFrequencyOptions.filter((item) => {
        if (item.key == this.state.selAlertFrequencyAddEdit[0])
          return item;
      });

      if (tmpFrequencyArr.length > 0) {
        tmpFrequency = tmpFrequencyArr[0].text;
      }
      else {
        if (!this.state.selAlertFrequencyAddEdit) {
        }
        else
          tmpFrequency = null;
      }
    }

    if (tmpRegions == '' && tmpRegTopic == '' && tmpTA == '') {
      //show error
      return false;
    }

    if (this.state.alertSubscribers.length == 0) {
      return false;
    }
    if (tmpFrequency == '') {
      return false;
    }

    let onBehalf: IUser = {} as IUser;
    let currUserID = this._currUser["Id"];
    if (this._subscriptionIdToEdit && this.state.alertOnBehalf.length > 0) {
      onBehalf = this.state.alertOnBehalf[0];
    }

    this.state.alertSubscribers.forEach(tmpSubscriber => {
      let listObj: any = {
        Id: this._subscriptionIdToEdit,
        Title: this.state.subscriptionTitle,
        G2RegionTaxHTField: tmpRegions,
        G2TherapeuticAreaTaxHTField: tmpTA,
        G2RegulatoryTopicTaxHTField: tmpRegTopic,
        ASSubscriberId: tmpSubscriber.id,
        ASFrequency: tmpFrequency
      };

      let onBehalfTemp: IUser = {} as IUser;
      if (tmpSubscriber.id != currUserID && !onBehalf.id) {
        onBehalfTemp.id = parseInt(this._currUser["Id"]);
        onBehalfTemp.title = this._currUser["Title"];
        onBehalfTemp.email = this._currUser["Email"];
      }
      else if (this._subscriptionIdToEdit && onBehalf.id) {
        onBehalfTemp = onBehalf;
      }

      let tmpObj: any = {
        Title: this.state.subscriptionTitle,
        region: tmpRegionsItem,
        regulatoryTopic: tmpRegTopicItem,
        therapeuticArea: tmpTAItem,
        subscriber: tmpSubscriber.title,
        subscriberId: tmpSubscriber.id,
        subscriberEmail: tmpSubscriber.email,
        onBehalf: onBehalfTemp.id ? onBehalfTemp.title : null,
        onBehalfId: onBehalfTemp.id ? onBehalfTemp.id : null,
        onBehalfEmail: onBehalfTemp.id ? onBehalfTemp.email : null,
        frequency: tmpFrequency
      };

      if (!this._subscriptionIdToEdit && tmpSubscriber.id != currUserID) {
        listObj["ASOnBehalfId"] = currUserID;
      }
      else if (this._subscriptionIdToEdit && onBehalfTemp) {
        listObj["ASOnBehalfId"] = onBehalfTemp.id ? onBehalfTemp.id : null;
      }

      this.AddtoSubscriptionsList(listObj, subscriptionListName, tmpObj);
    });
  }

  private AddtoSubscriptionsList(listObj, subscriptionListName, tmpObj) {
    if (!this._subscriptionIdToEdit) { //this.state.isNewRecord) {
      return new Promise<boolean>((resolve, reject) => {
        ListService.PostListData(listObj, subscriptionListName)
          .then(async result => {
            this._itemId = result.data.Id;
            this._isQueryStringRead = true;

            //await this.getSubscriptionsDataTemp();
            let subscriptionItem: ISubscription = {} as ISubscription;
            subscriptionItem.id = result.data.Id.toString();
            subscriptionItem.title = tmpObj.Title;
            subscriptionItem.region = tmpObj.region;
            subscriptionItem.regulatoryTopic = tmpObj.regulatoryTopic;
            subscriptionItem.therapeuticArea = tmpObj.therapeuticArea;
            subscriptionItem.subscriber = tmpObj.subscriber;
            subscriptionItem.subscriberId = tmpObj.subscriberId;
            subscriptionItem.subscriberEmail = tmpObj.subscriberEmail;
            subscriptionItem.onBehalfEmail = tmpObj.onBehalfEmail;
            subscriptionItem.onBehalf = tmpObj.onBehalf;
            subscriptionItem.onBehalfId = tmpObj.onBehalfId;
            subscriptionItem.frequency = tmpObj.frequency;
            this._allSubscriptions.unshift(subscriptionItem);

            this.setState({
              subscriptionTitle: '', editSubmission: [], alertSubscribers: [], alertSubscribersWithEmail: [],
              selRegionAddEdit: [], selTAAddEdit: [], selRegTopicAddEdit: [], selAlertFrequencyAddEdit: [],
              selAlertDayoftheWeekAddEdit: [], isOnBehalfHide: false, isShowPanel: false, allSubscriptions: this._allSubscriptions,
              hideLoadingDialog: true
            }, () => {
              this.createDataState({ take: this.state.take, skip: this.state.skip, sort: this.state.sort });
              this._getDistinctSubscriber();
              this.onDDLFilter();

              //add audit log
              LoggerService.auditLog("Subscription with ID: " + result.data.Id + " has been created", 'ManageSubscription > AddtoSubscriptionsList');

              // Send Email
              let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);
              if (this._itemId == 0) {
                this._itemId = result.data.Id;
              }
              let subNew = this.state.allSubscriptions.filter(s => s.id == this._itemId)[0];

              Common.getEmailTemplate(emailTmplList, 'UserNewAlertSubscription').then(async tmplResp => {
                if (tmplResp) {
                  await this._prepUserSubscriptionEmail(tmplResp, subNew, "New");
                }
              });
              resolve(true);
            });
          })
          .catch(exception => {
            console.log("_onSave Save Subscription - ", exception);
            LoggerService.errorLog(exception, 'ManageSubcriptions > AddtoSubscriptionsList > New Subscription');
            this._isQueryStringRead = true;
            reject(exception);
          });
      });
    } else {
      return new Promise((resolve, reject) => {
        ListService.UpdateListDataByID(subscriptionListName, this._itemId, listObj)
          .then(async result => {
            //add audit log
            LoggerService.auditLog("Subscription with ID: " + this._itemId + " has been updated", 'ManageSubscription > AddtoSubscriptionsList');

            let subscriptionItem = this._allSubscriptions.find(item => item.id == this._itemId);
            subscriptionItem.title = tmpObj.Title;
            subscriptionItem.region = tmpObj.region;
            subscriptionItem.regulatoryTopic = tmpObj.regulatoryTopic;
            subscriptionItem.therapeuticArea = tmpObj.therapeuticArea;
            subscriptionItem.subscriber = tmpObj.subscriber;
            subscriptionItem.subscriberId = tmpObj.subscriberId;
            subscriptionItem.subscriberEmail = tmpObj.subscriberEmail;
            subscriptionItem.onBehalfEmail = tmpObj.onBehalfEmail;
            subscriptionItem.onBehalf = tmpObj.onBehalf;
            subscriptionItem.onBehalfId = tmpObj.onBehalfId;
            subscriptionItem.frequency = tmpObj.frequency;

            this.setState({
              subscriptionTitle: '', editSubmission: [], alertSubscribers: [], alertSubscribersWithEmail: [],
              selRegionAddEdit: [], selTAAddEdit: [], selRegTopicAddEdit: [], selAlertFrequencyAddEdit: [],
              selAlertDayoftheWeekAddEdit: [], isOnBehalfHide: false, isShowPanel: false, allSubscriptions: this._allSubscriptions,
              hideLoadingDialog: true
            }, () => {
              this.createDataState({ take: this.state.take, skip: this.state.skip, sort: this.state.sort });
              this._getDistinctSubscriber();
              this.onDDLFilter();
              let subNew = this.state.allSubscriptions.filter(s => s.id == this._itemId)[0];

              // Send Email
              let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);
              Common.getEmailTemplate(emailTmplList, 'UserEditAlertSubscription').then(async tmplResp => {
                if (tmplResp) {
                  await this._prepUserSubscriptionEmail(tmplResp, subNew, AlertIconType.Edit);
                }
              });
              this._isQueryStringRead = true;
              resolve(true);
            });
          })
          .catch(exception => {
            console.log("_onSave Edit Subscription - ", exception);
            LoggerService.errorLog(exception, 'ManageSubcriptions > AddtoSubscriptionsList > Edit Subscription');
            this._isQueryStringRead = true;
            reject(exception);
          });
      });
    }
  }

  private clearAddEditFields() {
    this._itemId = 0;
    this._subscriptionIdToEdit = 0;

    this._selRegionsAddEditObj = [];
    this._selRegTopicAddEditObj = [];
    this._selTAAddEditObj = [];
    this._selTAAddEditObj = [];

    this.state.alertFrequencyOptions.forEach((item) => {
      if (item.selected)
        item.selected = false;
    });
  }

  private onExportToExcelClick = (type): void => {
    try {
      let component = this._mngSubscriptionsGridExcelExport;
      const options = component.workbookOptions();
      const rows = options.sheets[0].rows;

      let altIdx = 0;
      rows.forEach((row) => {
        if (row.type === 'data') {
          //convert from html to plain text          
          let re = /\&nbsp;/gi;
          for (let index = 0; index < row.cells.length; index++) {
            if (row.cells[index].value && typeof row.cells[index].value == "string") {
              row.cells[index].value = row.cells[index].value.toString().replace(/<\/?[^>]+>/ig, "").replace(re, " ");
            }
          }

          //for alternate row coloring
          if (altIdx % 2 !== 0) {
            row.cells.forEach((cell) => {
              cell.background = '#aabbcc';
            });
          }

          altIdx++;
        }
        else if (row.type === 'header' && row.cells.length > 1) {
          row.cells.forEach((cell) => {
            cell.bold = true;
          });

        }
        else if (row.type === 'header' && row.cells.length <= 1) {

        }
      });

      component.save(options);
    }
    catch (exception) {
      LoggerService.errorLog(exception, "ManageSubscriptions > onExportToExcelClick");
    }
  }




  private onSignUpClick() {
    this._selAlertFrequencyAddEditObj = [];
    this.clearAddEditFields();
    this.setState({
      subscriptionTitle: '', editSubmission: [], alertSubscribers: [], alertSubscribersWithEmail: [],
      selRegionAddEdit: [], selTAAddEdit: [], selRegTopicAddEdit: [], selAlertFrequencyAddEdit: [],
      selAlertDayoftheWeekAddEdit: [], isViewMode: false, isOnBehalfHide: true, showingLoadingBar: true, isShowPanel: true, disableSubmitButton: true
    }, () => this.populateAddEditSubscription(0));
  }

  private populateAddEditSubscription = (id) => {
    let filteredSubscription: any[];
    if (id != 0) {
      this.setState({ subscriptionsSelectionLimit: 1 }, () => {
        this._itemId = id;
        filteredSubscription = this._allSubscriptions.filter(item => {
          return item.id == id;
        });

        if (filteredSubscription.length > 0) {
          let selIDs = [];
          let tmparr = [];

          // Subscriber        
          if (filteredSubscription[0].subscriberId) {
            tmparr.push({ email: filteredSubscription[0].subscriberEmail, id: filteredSubscription[0].subscriberId, title: filteredSubscription[0].subscriber });
          }

          this.setState({ editSubmission: filteredSubscription[0], subscriptionTitle: filteredSubscription[0].title, alertSubscribers: tmparr }, this.setPeoplePicker);

          // OnBehalf
          if (filteredSubscription[0].onBehalfId) {
            tmparr = [];
            if (filteredSubscription[0].onBehalfId) {
              tmparr.push({ email: filteredSubscription[0].onBehalfEmail, id: filteredSubscription[0].onBehalfId, title: filteredSubscription[0].onBehalf });
            }

            if (tmparr.length > 0) {
              this.setState({ isOnBehalfHide: false, alertOnBehalf: tmparr, alertOnBehalfWithEmail: [] }, this.setOnBehalfPeoplePicker);
            }
            else {
              this.setState({ isOnBehalfHide: true, alertOnBehalf: tmparr, alertOnBehalfWithEmail: [] }, this.setOnBehalfPeoplePicker);
            }
          }
          else {
            tmparr = [];
            this.setState({ isOnBehalfHide: true, alertOnBehalf: tmparr, alertOnBehalfWithEmail: tmparr });
          }

          // Region
          tmparr = this.state.alertRegionOptions.filter(item => {
            return filteredSubscription[0].region.indexOf(item.text) > -1;
          });

          selIDs = [];
          if (tmparr.length > 0) {
            tmparr.forEach(item => {
              selIDs.push(item["key"]);
            });
          }
          this._selRegionsAddEditObj = selIDs;
          this.setState({ selRegionAddEdit: this._selRegionsAddEditObj });

          // Therapeutic Area
          tmparr = this.state.alertTAOptions.filter(item => {
            return filteredSubscription[0].therapeuticArea.indexOf(item.text) > -1;
          });

          selIDs = [];
          if (tmparr.length > 0) {
            tmparr.forEach(item => {
              selIDs.push(item["key"]);
            });
          }
          this._selTAAddEditObj = selIDs;
          this.setState({ selTAAddEdit: this._selTAAddEditObj });

          // Regulatory Topic
          tmparr = this.state.alertRegTopicOptions.filter(item => {
            return filteredSubscription[0].regulatoryTopic.indexOf(item.text) > -1;
          });

          selIDs = [];
          if (tmparr.length > 0) {
            tmparr.forEach(item => {
              selIDs.push(item["key"]);
            });
          }
          this._selRegTopicAddEditObj = selIDs;
          this.setState({ selRegTopicAddEdit: this._selRegTopicAddEditObj });

          // Frequency
          tmparr = this.state.alertFrequencyOptions.filter(item => {
            return item.text == filteredSubscription[0].frequency;
          });

          selIDs = [];
          if (tmparr.length > 0) {
            tmparr.forEach(item => {
              selIDs.push(item["key"]);
            });
          }

          this._selAlertFrequencyAddEditObj = tmparr;
          this.setState({ selAlertFrequencyAddEdit: selIDs });
        }
      });
    }
    else {
      let tmparr = [{ email: this._currUser["Email"], id: this._currUser["Id"], title: this._currUser["Title"] }];
      this.setState({
        selRegionAddEdit: [...this.state.selRegion], selTAAddEdit: [... this.state.selTA], selRegTopicAddEdit: [...this.state.selRegTopic],
        subscriptionsSelectionLimit: 1000, alertSubscribers: tmparr
      }, this.setPeoplePicker);
    }
  }

  private onTitleTextChanged = (ev: React.FormEvent<HTMLInputElement>, newTitle?: string) => {
    try {
      this.setState({ subscriptionTitle: newTitle }, () => this._validate());
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubcriptions > onTitleTextChanged');
    }
  }

  private _onDDLRegionChange = (event, value): void => {
    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
    this.setMultiselectState(ConfigKey.Region, "selRegion", value);
  }

  private _onDDLTAChange = (event, value): void => {
    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
    this.setMultiselectState(ConfigKey.TherapeuticArea, "selTA", value);
  }

  private _onDDLRegTopicChange = (event, value): void => {
    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
    this.setMultiselectState(ConfigKey.RegulatoryTopic, "selRegTopic", value);
  }

  private _onDDLAlertSubscriberChange = (event, value): void => {
    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
    this.setMultiselectState(ConfigKey.Subscriber, "selSubscriber", value);
  }

  private setMultiselectState = (stateName: string, selStateName: string, ddlVal: any[]) => {
    let selIDs = this.state[selStateName];
    let _tmpSelObj: any[] = [];

    if (ddlVal["selected"]) {
      selIDs.push(ddlVal["key"]);
    } else {
      var keyIdx2 = selIDs.findIndex(x => x == ddlVal["key"]);
      if (keyIdx2 !== -1) {
        selIDs.splice(keyIdx2, 1);
      }
    }

    switch (stateName) {
      case ConfigKey.Region: {
        if (selStateName.endsWith("AddEdit")) {
          _tmpSelObj = this._selRegionsAddEditObj;
        }
        else
          _tmpSelObj = this._selRegionsObj;

        if (ddlVal["selected"]) {
          _tmpSelObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
        } else {
          var keyIdx = this._selRegionsObj.findIndex(x => x.key == ddlVal["key"]);
          if (keyIdx !== -1) {
            _tmpSelObj.splice(keyIdx2, 1);
          }
        }
        if (!selStateName.endsWith("AddEdit")) {
          this._selRegionsObj = _tmpSelObj;
          this.setState({ selRegion: [...selIDs] }, () => this.onDDLFilter());
        }
        else {
          this._selRegionsAddEditObj = _tmpSelObj;
          this.setState({ selRegionAddEdit: [...selIDs] }, () => this._validate());
        }
      }
        return; //break;

      case ConfigKey.TherapeuticArea: {

        if (selStateName.endsWith("AddEdit")) {
          _tmpSelObj = this._selTAAddEditObj;
        }
        else
          _tmpSelObj = this._selTAObj;

        if (ddlVal["selected"]) {
          _tmpSelObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
        } else {
          var keyIdx3 = _tmpSelObj.findIndex(x => x.key == ddlVal["key"]);
          if (keyIdx3 !== -1) {
            _tmpSelObj.splice(keyIdx2, 1);
          }
        }

        if (!selStateName.endsWith("AddEdit")) {
          this._selTAObj = _tmpSelObj;
          this.setState({ selTA: [...selIDs] }, () => this.onDDLFilter());
        }
        else {
          this._selTAAddEditObj = _tmpSelObj;
          this.setState({ selTAAddEdit: [...selIDs] }, () => this._validate());
        }
      }
        return; //break;
      case ConfigKey.RegulatoryTopic: {
        if (selStateName.endsWith("AddEdit")) {
          _tmpSelObj = this._selRegTopicAddEditObj;
        }
        else
          _tmpSelObj = this._selRegTopicObj;

        if (ddlVal["selected"]) {
          _tmpSelObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
        } else {
          var keyIdx4 = _tmpSelObj.findIndex(x => x.key == ddlVal["key"]);
          if (keyIdx4 !== -1) {
            _tmpSelObj.splice(keyIdx2, 1);
          }
        }
        if (!selStateName.endsWith("AddEdit")) {
          this._selRegTopicObj = _tmpSelObj;
          this.setState({ selRegTopic: [...selIDs] }, () => this.onDDLFilter());
        }
        else {
          this._selRegTopicAddEditObj = _tmpSelObj;
          this.setState({ selRegTopicAddEdit: [...selIDs] }, () => this._validate());
        }
      }
        return; //break;

      // Add/Edit Panel
      case ConfigKey.Subscriber: {
        if (ddlVal["selected"]) {
          let textTemp = ddlVal["text"].split('(');
          textTemp.length > 0 ? textTemp = textTemp[0] : textTemp = ddlVal["text"];
          this._selSubscriberObj.push({ key: ddlVal["key"], text: textTemp });
        } else {
          var keyIdx5 = this._selSubscriberObj.findIndex(x => x.key == ddlVal["key"]);
          if (keyIdx5 !== -1) {
            this._selSubscriberObj.splice(keyIdx2, 1);
          }
        }
        this.setState({ selSubscriber: [...selIDs] }, () => { this.onDDLFilter(); this._validate(); });
      }
        return; //break;

      case ConfigKey.AlertFrequency: {
        if (ddlVal["selected"]) {
          selIDs = [];
          selIDs.push(ddlVal["key"]);

          this._selAlertFrequencyAddEditObj = [];
          this._selAlertFrequencyAddEditObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
        } else {
          this._selAlertFrequencyAddEditObj = [];
          var keyIdx6 = this._selAlertFrequencyAddEditObj.findIndex(x => x.key == ddlVal["key"]);
          if (keyIdx6 !== -1) {
            this._selAlertFrequencyAddEditObj.splice(keyIdx2, 1);
          }
        }
        this.setState({ selAlertFrequencyAddEdit: selIDs }, () => this._validate());
      }
        return; //break;
      default:
        return; //break;
    }
  }

  private onSearch(newVal) {
    try {
      if (newVal.trim().length > 0) {
        newVal = newVal.toLowerCase();
        let filteredSubscriptions = this.state.allSubscriptions.filter(item => {
          return item.title.toLowerCase().indexOf(newVal) >= 0 || item.region.toLowerCase().indexOf(newVal) >= 0
            || item.regulatoryTopic.toLowerCase().indexOf(newVal) >= 0 || item.therapeuticArea.toLowerCase().indexOf(newVal) >= 0
            || item.subscriber.toLowerCase().indexOf(newVal) >= 0 || item.frequency.toLowerCase().indexOf(newVal) >= 0;
        });
        this.setState({ allSubscriptions: filteredSubscriptions, result: process(filteredSubscriptions.slice(0), this.state.dataState) });
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubscriptions > onSearch');
    }
  }

  private onDDLFilter() {
    try {
      let arrFilteredSubscriptions: any[] = [];
      if (this._selRegionsObj.length == 0 && this._selTAObj.length == 0 && this._selRegTopicObj.length == 0 && this._selSubscriberObj.length == 0) {
        this.setState({ allSubscriptions: this._allSubscriptions, result: process(this._allSubscriptions.slice(0), this.state.dataState) }, () => {
          if (this._searchText) {
            this.onSearch(this._searchText);
          }
        });
      }
      else {
        arrFilteredSubscriptions = this._allSubscriptions.filter(item => {
          let regionFlag = true, therapeuticFlag = true, regulatoryTopicFlag = true, subFlag = true;
          if (this._selRegionsObj.length > 0) {
            let regSelVals = item.region.split(',').map(reg => reg.toLowerCase().trim());
            if (this._selRegionsObj.filter(ele => regSelVals.indexOf(ele.text.toLowerCase()) !== -1).length == 0)
              regionFlag = false;
          }
          if (this._selTAObj.length > 0) {
            let taSelVals = item.therapeuticArea.split(',').map(ta => ta.toLowerCase().trim());
            if (this._selTAObj.filter(ele => taSelVals.indexOf(ele.text.toLowerCase()) !== -1).length == 0)
              therapeuticFlag = false;
          }
          if (this._selRegTopicObj.length > 0) {
            let regTopicSelVals = item.regulatoryTopic.split(',').map(regT => regT.toLowerCase().trim());
            if (this._selRegTopicObj.filter(ele => regTopicSelVals.indexOf(ele.text.toLowerCase()) !== -1).length == 0)
              regulatoryTopicFlag = false;
          }
          if (this._selSubscriberObj.length > 0) {
            if (this._selSubscriberObj.filter(ele => ele.key === item.subscriber.toString()).length == 0)
              subFlag = false;
          }
          if (regionFlag && therapeuticFlag && regulatoryTopicFlag && subFlag) {
            return true;
          }
        });

        this.setState({
          allSubscriptions: arrFilteredSubscriptions, result: process(arrFilteredSubscriptions.slice(0), this.state.dataState)
        }, () => {
          if (this._searchText) {
            this.onSearch(this._searchText);
          }
        });
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > onDDLFilter');
    }
  }

  private _onPanelDDLRegionChange = (event, value): void => {
    this.setMultiselectState(ConfigKey.Region, "selRegionAddEdit", value);
  }

  private _onPanelDDLTAChange = (event, value): void => {
    this.setMultiselectState(ConfigKey.TherapeuticArea, "selTAAddEdit", value);
  }

  private _onPanelDDLRegTopicChange = (event, value): void => {
    this.setMultiselectState(ConfigKey.RegulatoryTopic, "selRegTopicAddEdit", value);
  }

  private _onPanelDDLAlertFrequencyChange = (event, value): void => {
    if (event.type == "click") {
      value.selected = true;
    }
    this.setMultiselectState(ConfigKey.AlertFrequency, "selAlertFrequencyAddEdit", value);
  }

  // Delete Subscription
  private recycleSubscription = (): void => {
    try {
      let subscriptionsDBListName = this._configData.filter((item) => {
        return item.title == ConfigType.Lists && item.key == ConfigKey.Subscriptions;
      })[0].value;

      if (this._subscriptionIdToDelete !== 0) {
        ListService.RecycleListDataByID(this._subscriptionIdToDelete, subscriptionsDBListName).then(resp => {
          if (resp) {
            //add audit log
            LoggerService.auditLog("Subscription with ID: " + this._subscriptionIdToDelete + " has been deleted", 'ManageSubscription > recycleSubscription');

            // Send Email
            let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);
            let subDeleted = this.state.allSubscriptions.filter(s => s.id == this._subscriptionIdToDelete)[0];

            Common.getEmailTemplate(emailTmplList, 'UserDeleteAlertSubscription').then(async tmplResp => {
              if (tmplResp) {
                await this._prepUserSubscriptionEmail(tmplResp, subDeleted, AlertIconType.Delete);
              }
            });

            // Refresh GRID Data
            var itemIndex = 0;
            for (let index = 0; index < this._allSubscriptions.length; index++) {
              if (this._allSubscriptions[index].id == this._subscriptionIdToDelete) {
                itemIndex = index;
                break;
              }
            }
            this._allSubscriptions.splice(itemIndex, 1);

            this._subscriptionIdToDelete = 0;
            this.setState({ allSubscriptions: this._allSubscriptions, hideDeleteDialog: true }, () => {
              this._getDistinctSubscriber();
              this.onDDLFilter();
            });
          }
        }).catch(error => {
          console.log(error);
          LoggerService.errorLog(error, 'ManageSubcriptions > recycleSubscription');
        });
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubcriptions > recycleSubscription');
    }
  }

  private async _prepUserSubscriptionEmail(emailTemplate: any[], subscriptionOld: any, mode: string) {
    try {
      let emailFrom = '';
      let emailTo: any[] = [];
      let emailCc: any[] = [];
      let emailSub = emailTemplate[0]['ETSubject'];
      let emailBody = emailTemplate[0]['ETBody'];

      await sp.web.getUserById(subscriptionOld["subscriberId"]).select("Email").get().then(rslt => {
        emailTo.push(rslt.Email);
      });

      if (subscriptionOld["onBehalfId"]) {
        await sp.web.getUserById(subscriptionOld["onBehalfId"]).select("Email").get().then(rslt => {
          emailCc.push(rslt.Email);
        });
      }

      let manageSubscriptionsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageSubscriptions);

      if (emailTemplate[0]["ETFrom"])
        emailFrom = emailTemplate[0]['ETFrom'].EMail;

      if (emailTemplate[0]["ETTo"])
        emailTo = emailTo.concat(emailTo, emailTemplate[0]["ETTo"].map(em => em.EMail));

      //Cc Emails
      if (emailTemplate[0]["ETCc"])
        emailCc = emailCc.concat(emailCc, emailTemplate[0]["ETCc"].map(em => em.EMail));

      emailSub = emailSub.replace("#Title#", subscriptionOld["title"]);

      emailBody = emailBody.replace("#Subscriber#", subscriptionOld["subscriber"]);
      emailBody = emailBody.replace("#LinkToItem#", "<a href='" + this.props.webURL + manageSubscriptionsPage + "'>Manage Subscriptions</a>");
      emailBody = emailBody.replace("#Region#", subscriptionOld["region"]);
      emailBody = emailBody.replace("#TherapeuticArea#", subscriptionOld["therapeuticArea"]);
      emailBody = emailBody.replace("#RegulatoryTopic#", subscriptionOld["regulatoryTopic"]);
      emailBody = emailBody.replace("#AlertFrequency#", subscriptionOld["frequency"]);
      emailBody = emailBody.replace("#Title#", subscriptionOld["title"]);

      this._sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody, mode);

    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubscriptions > _prepUserSubscriptionEmail');
    }
  }

  private _sendEmail(emailFrom: string, emailTo: any[], emailCc: any[], emailSub: string, emailBody: string, type: string) {
    try {
      EmailService.sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody).then(result => {
        LoggerService.auditLog("Email sent for - " + type, 'ManageSubscriptions > _sendEmail');
      }).catch(error => {
        LoggerService.errorLog(error, 'ManageSubscriptions > _sendEmail > sendEmail');
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubscriptions > _sendEmail');
    }
  }

  private _validate() {
    try {
      let isTitleValid = false; let isSubscriberValid = false; let isRegionValid = false;
      let isTAValid = false; let isTopicValid = false; let isFrequencyValid = false;

      //Title
      if (this.state.subscriptionTitle.length == 0) {
        this.setState({ titleErrorMessage: `Required field!` });
      }
      else if (this.state.subscriptionTitle.length > 255) {
        this.setState({ titleErrorMessage: `Title should not exceed more than 255 characters!` });
      }
      else {
        this.setState({ titleErrorMessage: '' });
        isTitleValid = true;
      }
      // Subscriber(s)
      if (this.state.alertSubscribers.length == 0) {
        this.setState({ subscriberErrorMessage: `Required field!` });
      }
      else {
        this.setState({ subscriberErrorMessage: '' });
        isSubscriberValid = true;
      }
      // Region && TA && Topic
      if (this.state.selRegionAddEdit.length == 0 && this.state.selTAAddEdit.length == 0 && this.state.selRegTopicAddEdit.length == 0) {
        this.setState({
          regionErrorMessage: `Must select a Region OR`,
          taErrorMessage: `Must select a Therapeutic Area OR`,
          topicErrorMessage: `Must select a Topic`
        });
      }
      else {
        this.setState({
          regionErrorMessage: '',
          taErrorMessage: '',
          topicErrorMessage: ''
        });
        isRegionValid = true;
        isTAValid = true;
        isTopicValid = true;
      }
      // Frequency
      if (this.state.selAlertFrequencyAddEdit.length == 0) {
        this.setState({ frequencyErrorMessage: `Required field!` });
      }
      else {
        this.setState({ frequencyErrorMessage: '' });
        isFrequencyValid = true;
      }

      if (isTitleValid && isSubscriberValid && (isRegionValid || isTAValid || isTopicValid) && isFrequencyValid) {
        if (this.state.editSubmission.length == 0) { // New Subscription
          this.setState({ disableSubmitButton: false });
          return true;
        }
        else { // Edit Subscription
          let isTitleChanged = false; let isSubscriberChanged = false; let isonBehalfChanged = false;
          let isRegionChanged = false; let isTAChanged = false; let isTopicChanged = false; let isFrequesncyChanged = false;

          isTitleChanged = (this.state.subscriptionTitle !== "" && this.state.subscriptionTitle.trim() != this.state.editSubmission.title) ? true : false;
          isSubscriberChanged = (this.state.alertSubscribers.length > 0 && this.state.alertSubscribers.map(ele => ele.id == this.state.editSubmission.subscriberId).length > 0) ? true : false;
          if (this.state.editSubmission.onBehalfId) {
            isonBehalfChanged = (this.state.alertOnBehalf.length > 0 && this.state.alertOnBehalf.map(ele => ele.id == this.state.editSubmission.onBehalfId).length > 0) ? true : false;
          }
          isFrequesncyChanged = (this.state.selAlertFrequencyAddEdit.length > 0 && this.state.selAlertFrequencyAddEdit[0] != this.state.editSubmission.frequency) ? true : false;

          isRegionChanged = this.state.selRegionAddEdit.filter(region => {
            return this.state.editSubmission.region.indexOf(region) == -1;
          }).length > 0 ? true : false;

          isTAChanged = this.state.selTAAddEdit.filter(TA => {
            return this.state.editSubmission.therapeuticArea.indexOf(TA) == -1;
          }).length > 0 ? true : false;

          isTopicChanged = this.state.selRegTopicAddEdit.filter(topic => {
            return this.state.editSubmission.regulatoryTopic.indexOf(topic) == -1;
          }).length > 0 ? true : false;

          if (isTitleChanged || isSubscriberChanged || isFrequesncyChanged || isRegionChanged || isTAChanged || isTopicChanged || isonBehalfChanged) {
            this.setState({ disableSubmitButton: false });
            return true;
          }
          else {
            this.setState({ disableSubmitButton: true });
          }
        }
      }
      else {
        this.setState({ disableSubmitButton: true });
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubcriptions > _validate');
    }
    return false;
  }

  private matchingSubmissionFound() {
    try {
      let filteredSubs = this.state.allSubscriptions.filter(sub => {
        let isduplicate = false; let isSubscriberFound = false; let isRegionFound = false; let isTAFound = false; let isTopicFound = false; let isFrequesncyFound = false;

        // Rgion
        if (this.state.selRegionAddEdit.length == 0 && sub.region.length == 0) {
          isRegionFound = true;
        }
        else {
          this.state.selRegionAddEdit.forEach(sReg => {
            let regionf = this.state.alertRegionOptions.filter(robj => {
              return robj.key === sReg;
            });
            if (regionf.length > 0)
              sReg = regionf[0].text;

            if (sub.region.indexOf(sReg) >= 0)
              if (!isRegionFound)
                isRegionFound = true;
          });
        }

        // TA
        if (this.state.selTAAddEdit.length == 0 && sub.therapeuticArea.length == 0) {
          isTAFound = true;
        }
        else {
          this.state.selTAAddEdit.forEach(sTA => {
            let taf = this.state.alertTAOptions.filter(robj => {
              return robj.key === sTA;
            });
            if (taf.length > 0) {
              sTA = taf[0].text;
            }

            if (sub.therapeuticArea.indexOf(sTA) >= 0)
              if (!isTAFound)
                isTAFound = true;
          });
        }

        //Topic
        if (this.state.selRegTopicAddEdit.length == 0 && sub.regulatoryTopic.length == 0) {
          isTopicFound = true;
        }
        else {
          this.state.selRegTopicAddEdit.forEach(sTopic => {
            let topicf = this.state.alertRegTopicOptions.filter(robj => {
              return robj.key === sTopic;
            });
            if (topicf.length > 0) {
              sTopic = topicf[0].text;
            }

            if (sub.regulatoryTopic.indexOf(sTopic) >= 0)
              if (!isTopicFound)
                isTopicFound = true;
          });
        }

        // Frequency
        let tmpFrequencyArr = this.state.alertFrequencyOptions.filter((item) => {
          if (item.key == this.state.selAlertFrequencyAddEdit[0])
            return item;
        });

        if (tmpFrequencyArr.length > 0 && tmpFrequencyArr[0].text == sub.frequency) {
          isFrequesncyFound = true;
        }

        // Subscriber
        if (this.state.isUserAdmin) {
          if (this.state.alertSubscribers.length > 0 && this.state.alertSubscribers.map(ele => ele.id == sub.subscriberId).length > 0)
            isSubscriberFound = true;
          else
            isSubscriberFound = false;
        }
        else
          isSubscriberFound = true;

        if (isSubscriberFound && isRegionFound && isTAFound && isTopicFound && isFrequesncyFound)
          isduplicate = true;
        else
          isduplicate = false;
        return isduplicate;
      });

      if (filteredSubs.length > 0) {
        return true;
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubcriptions > matchingSubmissionFound');
    }
    return false;
  }

  private closeDuplicateDialog() {
    this.setState({
      isDuplicateSubscription: false,
      createDuplicateSubscription: false,
      disableSubmitButton: true,
      hideLoadingDialog: true
    });
  }

  private createDuplicateSubscription() {
    this.setState({
      isDuplicateSubscription: false,
      createDuplicateSubscription: true
    }, () => this.initiateSaveSubscriptions());
  }

  private _sortChange = (event) => {
    try {
      this.setState({
        sort: event.sort
      }, () => {
        this.createDataState({
          take: this.state.take,
          skip: this.state.skip,
          sort: this.state.sort
        });
      });
      LoggerService.auditLog("Grid sort changed - " + event.sort, 'ManageSubcriptions> _sortChange');
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubcriptions > _sortChange');
    }
  }

  private dataStateChange = (event) => {
    this.createDataState(event.data);
  }

  private createDataState(dataState: any) {
    try {
      if (this.state) {
        this.setState({ result: process(this.state.allSubscriptions.slice(0), dataState), dataState: dataState }, () => {
          //this.MSColumnMenuCheckboxFilter = (props) => <ColumnMenuCheckboxFilter {...props} data={this.state.result.data} />;
        });
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubcriptions > createDataState');
    }
  }

  private _getQueryParam = (): void => {
    try {
      let arrRegs: any = []; let arrTAs: any = []; let arrRegTs: any = [];
      let regs = Common.getQueryStringValue('regions');
      let TAs = Common.getQueryStringValue('tas');
      let regTs = Common.getQueryStringValue('regtopics');

      if (regs == "" && TAs == "" && regTs == "") {
        if (window.location.href.indexOf('regtopics') >= 0) {
          if (!this._isQueryStringRead) {
            let tmparr = [{ email: this._currUser["Email"], id: this._currUser["Id"], title: this._currUser["Title"] }];
            this.setState({ isShowPanel: true, disableSubmitButton: true, alertSubscribers: tmparr }, () => this.setPeoplePicker());
          }
        } else
          this._isQueryStringRead = true;
      } else {
        if (!this._isQueryStringRead) {
          arrRegs = regs == "" ? [] : regs.indexOf(',') >= 0 ? regs.split(',') : [regs];
          arrTAs = TAs == "" ? [] : TAs.indexOf(',') >= 0 ? TAs.split(',') : [TAs];
          arrRegTs = regTs == "" ? [] : regTs.indexOf(',') >= 0 ? regTs.split(',') : [regTs];

          this._selRegionsAddEditObj = arrRegs;
          this._selTAAddEditObj = arrTAs;
          this._selRegTopicAddEditObj = arrRegTs;
          let tmparr = [{ email: this._currUser["Email"], id: this._currUser["Id"], title: this._currUser["Title"] }];

          this.setState({
            selRegionAddEdit: this._selRegionsAddEditObj, selTAAddEdit: this._selTAAddEditObj,
            selRegTopicAddEdit: this._selRegTopicAddEditObj, isShowPanel: true, disableSubmitButton: true, alertSubscribers: tmparr
          }, () => this.setPeoplePicker());
        }
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > _getQueryParam');
    }
  }
}
