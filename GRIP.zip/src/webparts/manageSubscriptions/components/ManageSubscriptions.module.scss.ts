/* tslint:disable */
require("./ManageSubscriptions.module.css");
const styles = {
  manageSubscriptions: 'manageSubscriptions_5d8c7f77',
  container: 'container_5d8c7f77',
  row: 'row_5d8c7f77',
  column: 'column_5d8c7f77',
  'ms-Grid': 'ms-Grid_5d8c7f77',
  title: 'title_5d8c7f77',
  subTitle: 'subTitle_5d8c7f77',
  description: 'description_5d8c7f77',
  button: 'button_5d8c7f77',
  label: 'label_5d8c7f77',
  hideelement: 'hideelement_5d8c7f77'
};

export default styles;
/* tslint:enable */