import { WebPartContext } from '@microsoft/sp-webpart-base';
import { INotification } from "../../../models/INotification";

export interface IManageSubscriptionsProps {
  description: string;
  context: WebPartContext;
  webURL: string;  
  onSetNotification: (notification: INotification) => void;
}
