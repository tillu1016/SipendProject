/* tslint:disable */
require("./AboutUsVisionMission.module.css");
const styles = {
  aboutUsVisionMission: 'aboutUsVisionMission_2a6c0f1a',
  container: 'container_2a6c0f1a',
  row: 'row_2a6c0f1a',
  column: 'column_2a6c0f1a',
  'ms-Grid': 'ms-Grid_2a6c0f1a',
  title: 'title_2a6c0f1a',
  subTitle: 'subTitle_2a6c0f1a',
  description: 'description_2a6c0f1a',
  button: 'button_2a6c0f1a',
  label: 'label_2a6c0f1a'
};

export default styles;
/* tslint:enable */