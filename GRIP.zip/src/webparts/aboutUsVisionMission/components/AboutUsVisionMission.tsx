import * as React from 'react';
import styles from './AboutUsVisionMission.module.scss';
import { IAboutUsVisionMissionProps } from './IAboutUsVisionMissionProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { LoggerService } from '../../../services/LoggerService';
import { Common } from '../../../common/common';
import { ConfigType, ConfigKey } from '../../../models/IConfiguration';
import ReactHtmlParser from 'react-html-parser';
import { CurrentUser } from '@pnp/sp/src/siteusers';
import { PageName } from '../../../models/IAlertAnalytics';

interface AboutUsVisionMissionState {
  displayText: string;
}

export default class AboutUsVisionMission extends React.Component<IAboutUsVisionMissionProps, AboutUsVisionMissionState> {

  constructor(props) {
    super(props);
    this.state = {
      displayText: ""
    };
  }

  public componentDidMount() {
    try {
      Common.getConfigData().then(resp => {
        if (resp) {
          Common.errorLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ErrorLog);
          Common.auditLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AuditLog);

          let dispText = Common.getConfigRichTextValue(resp, ConfigType.AboutUs, this.props.display);
          this.setState({ displayText: dispText });
        }
      })
        .catch(error => {
          LoggerService.errorLog(error, 'AboutUsVisionMission > componentDidMount > getConfigData');
        });
    } catch (error) {
      LoggerService.errorLog(error, 'AboutUsVisionMission > componentDidMount');
    }
  }

  public render(): React.ReactElement<IAboutUsVisionMissionProps> {
    return (
      <div className={styles.aboutUsVisionMission}>
        {this.state.displayText !== "" ?
          <div className={this.props.display == "Vision" ? "vision_box" : "mission_box"}>
            <div className="v_img">
              <h1>{this.props.display}</h1>
              <p>{this.props.display == "Vision" ?
                <img src={this.props.webURL + "/SiteAssets/Images/AboutUs/vision.png"} /> :
                <img src={this.props.webURL + "/SiteAssets/Images/AboutUs/mission.png"} />
              }
              </p>
            </div>
            <div className="v_cont">
              <p>
                {ReactHtmlParser(this.state.displayText)}</p>
            </div>
          </div>
          : null}
      </div>
    );
  }



}
