declare interface IAboutUsVisionMissionWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  DisplayFieldLabel: string;
}

declare module 'AboutUsVisionMissionWebPartStrings' {
  const strings: IAboutUsVisionMissionWebPartStrings;
  export = strings;
}
