import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
  PropertyPaneDropdown
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'AboutUsVisionMissionWebPartStrings';
import AboutUsVisionMission from './components/AboutUsVisionMission';
import { IAboutUsVisionMissionProps } from './components/IAboutUsVisionMissionProps';
import { sp } from '@pnp/sp';

export interface IAboutUsVisionMissionWebPartProps {
  display: string;
}

export default class AboutUsVisionMissionWebPart extends BaseClientSideWebPart<IAboutUsVisionMissionWebPartProps> {

  protected onInit(): Promise<void> {
    return super.onInit().then(_ => {
      sp.setup({
        spfxContext: this.context
      });
    });
  }

  public render(): void {
    const element: React.ReactElement<IAboutUsVisionMissionProps> = React.createElement(
      AboutUsVisionMission,
      {
        context: this.context,
        webURL: this.context.pageContext.web.absoluteUrl,
        display: this.properties.display
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneDropdown('display', {
                  label: strings.DisplayFieldLabel,
                  disabled: false,
                  selectedKey: "Vision",
                  options: [
                    { key: 'Vision', text: 'Vision' },
                    { key: 'Mission', text: 'Mission' }
                  ]
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
