declare interface IViewAlertWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  ListFieldLabel: string;
}

declare module 'ViewAlertWebPartStrings' {
  const strings: IViewAlertWebPartStrings;
  export = strings;
}
