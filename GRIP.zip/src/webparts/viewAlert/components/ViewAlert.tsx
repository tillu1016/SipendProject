import * as React from 'react';
import styles from './ViewAlert.module.scss';
import { IViewAlertProps } from './IViewAlertProps';
import { escape } from '@microsoft/sp-lodash-subset';
import {
  IStackItemStyles, Stack, Label, PrimaryButton, DefaultButton, Dialog, DialogType, IconButton,
  DialogFooter, IIconProps, TextField
} from '@fluentui/react';
import { ListService } from '../../../services/ListService';
import { ConfigKey, ConfigType } from '../../../models/IConfiguration';
import { Common } from '../../../common/common';
import ReactHtmlParser from 'react-html-parser';
import { PDFExport, savePDF } from "@progress/kendo-react-pdf";
import * as ReactDOM from 'react-dom';
import { CurrentUser } from '@pnp/sp/src/siteusers';
import { EmailService } from '../../../services/EmailService';
import { AlertStatus } from '../../../models/IAlert';
import { LoggerService } from '../../../services/LoggerService';
import * as moment from 'moment-timezone';
import { PageName } from '../../../models/IAlertAnalytics';
import { NotificationType } from '../../../models/INotification';
import { PermissionsService } from '../../../services/PermissionsService';
import BlockUIComp from '../../../common/BlockUIComp';

const stackItemStyles: IStackItemStyles = {
  root: {
    padding: 5
  }
};

interface IViewAlertState {
  alertTitle: string;
  alertImpact: string;
  alertBody: string;
  alertMeetStDt: string;
  alertMeetEnDt: string;
  alertPubDate: string;
  alertStatus: string;
  alertRegion: string;
  alertTA: string;
  alertRegTopic: string;
  alertDocType: string;
  hideShareDialog: boolean;
  hideDeleteButton: boolean;
  hideDeleteDialog: boolean;
  isUserAdmin: boolean;
  isForApproval: boolean;
  hideRejectComments: boolean;
  ADBComments: string;
  disableSubmitCommBtn: boolean;
  alertAuthor: string;
  alertAuthorEmail: string;
  alertCreatedByTitle: string;
  alertCreatedByEMail: string;
  alertModifiedByTitle: string;
  alertModifiedByEmail: string;
  admMems: string[];
  isSubmittoRI: boolean; hideLoadingDialog: boolean; loadingText: string;
}

export default class ViewAlert extends React.Component<IViewAlertProps, IViewAlertState> {

  private _configData: any[];
  private _refTextToCopy;
  private _itemId: number;
  private _copyIcon: IIconProps = { iconName: 'Copy' };
  public _pdfContainer;
  private _currUser: CurrentUser;

  constructor(props) {
    super(props);
    let _isSubmittoRI: boolean = false;
    if (this.props.listName == "SubmittoRITeam") {
      _isSubmittoRI = true;
    }
    this.state = {
      alertTitle: '',
      alertImpact: '',
      alertBody: '',
      alertMeetStDt: '',
      alertMeetEnDt: '',
      alertPubDate: '',
      alertStatus: '',
      alertRegion: '',
      alertTA: '',
      alertRegTopic: '',
      alertDocType: '',
      hideShareDialog: true,
      hideDeleteButton: true,
      hideDeleteDialog: true,
      isUserAdmin: false,
      isForApproval: false,
      hideRejectComments: true,
      ADBComments: "",
      disableSubmitCommBtn: true,
      alertAuthor: '',
      alertAuthorEmail: '',
      alertCreatedByTitle: '',
      alertCreatedByEMail: '',
      alertModifiedByEmail: '',
      alertModifiedByTitle: '',
      admMems: [],

      isSubmittoRI: _isSubmittoRI, hideLoadingDialog: false, loadingText: 'Please Wait...'
    };
    this._refTextToCopy = React.createRef();
  }

  public componentDidMount() {
    try {
      Common.timeZone = moment.tz.guess();
      moment.tz.setDefault(Common.timeZone);

      Common.getConfigData().then(resp => {
        if (resp) {
          this._configData = resp;
          Common.errorLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ErrorLog);
          Common.auditLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AuditLog);
          let adminGrpName: string = Common.getConfigValue(this._configData, ConfigType.Roles, ConfigKey.Administrator);

          Common.getCurrentUserId().then((curUser: CurrentUser) => {
            this._currUser = curUser;
            Common.checkIfUserAdmin(adminGrpName).then(isUsrAdm => {
              this.setState({ hideDeleteButton: !isUsrAdm, isUserAdmin: isUsrAdm }, () => this._getQueryParam());
            });
          });

          this.getAdminMembers().then(result => {
            this.setState({ admMems: result });
          });
        }
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ViewAlert > componentDidMount');
    }
  }

  public render(): React.ReactElement<IViewAlertProps> {
    return (
      <div className={styles.viewAlert} >
        <Stack>
          <Stack.Item styles={stackItemStyles}>
            {this.state.isSubmittoRI ? <h1>View Submit RI to Team</h1> :
              <h1>View Alert</h1>}
          </Stack.Item>
          <Stack.Item styles={stackItemStyles}>
            <div className='vaAdminButtons'>
              {this.state.isUserAdmin && this.state.isForApproval ?
                <span>
                  <PrimaryButton text="Approve" className="priymary_btn_red" onClick={this.onApproveClick.bind(this)} />
                  <PrimaryButton text="Reject" className="priymary_btn_red" onClick={this.onRejectClick.bind(this)} />
                </span>
                : null}
              {this.state.hideDeleteButton ? null :
                <span>
                  <PrimaryButton text="Edit" className="priymary_btn_red" onClick={this.onEditButtonClick.bind(this)} />
                  <PrimaryButton text="Delete" className="priymary_btn_red" onClick={this.onDeleteButtonClick.bind(this)} />
                </span>
              }
            </div>
            <div className='vaUserButtons'>
              {this.state.isSubmittoRI ? null : <PrimaryButton text="Export to PDF" className="priymary_btn_red" onClick={this.onPDFClick.bind(this)} />}
              {this.state.isSubmittoRI ? null : <PrimaryButton text="Share" className="priymary_btn_red" onClick={this.onShareClick.bind(this)} />}
              <DefaultButton text="Close" className="grey_btn" onClick={this.closeForm.bind(this)} />
            </div>
          </Stack.Item>
          <Stack.Item styles={stackItemStyles}>
            <div className='vaFormControls'>
              <Label className="vaLabel">Region</Label>
              {this.state.alertRegion}
            </div>
            <div className='vaFormControls'>
              <Label className="vaLabel">Document Type</Label>
              {this.state.alertDocType}
            </div>
          </Stack.Item>
          <Stack.Item styles={stackItemStyles}>
            <div className='vaFormControls'>
              <Label className="vaLabel">Therapeutic Area</Label>
              {this.state.alertTA}
            </div>
            <div className='vaFormControls'>
              <Label className="vaLabel">Regulatory Topic</Label>
              {this.state.alertRegTopic}
            </div>
          </Stack.Item>
          {this.state.isSubmittoRI ? "" :
            this.state.isUserAdmin ?
              <Stack.Item styles={stackItemStyles}>
                <div className='vaFormControls'>
                  <Label className="vaLabel">Meeting Agenda Start Time</Label>
                  {this.state.alertMeetStDt}
                </div>
                <div className='vaFormControls'>
                  <Label className="vaLabel">Meeting Agenda End Time</Label>
                  {this.state.alertMeetEnDt}
                </div>
              </Stack.Item> : ""
          }
          {
            this.state.isSubmittoRI ?
              ""
              :
              <Stack.Item styles={stackItemStyles}>
                <div className='vaFormControls'>
                  <Label className="vaLabel">Publication Date</Label>
                  {this.state.alertPubDate}
                </div>
                <div className='vaFormControls'>
                  <Label className="vaLabel">Author</Label>
                  {this.state.alertAuthor}
                </div>
              </Stack.Item>
          }
          <Stack.Item styles={stackItemStyles}>
            <div className='vaFormControls'>
              <Label className="vaLabel">Status</Label>
              {
                this.state.isSubmittoRI && !this.state.isUserAdmin ?
                  this.state.alertStatus != AlertStatus.Submitted && this.state.alertStatus != AlertStatus.Publish && this.state.alertStatus != AlertStatus.Rejected ?
                    "Review In Progress"
                    :
                    this.state.alertStatus
                  :
                  this.state.alertStatus
              }
            </div>
          </Stack.Item>
          <Stack.Item styles={stackItemStyles}>
            <Label className="vaLabel">Title</Label>
            <div className="vaContent">{this.state.alertTitle}</div>
          </Stack.Item>
          <Stack.Item styles={stackItemStyles}>
            <Label className="vaLabel">Impact</Label>
            <div className="vaContent">{this.state.alertImpact}</div>
          </Stack.Item>
          <Stack.Item styles={stackItemStyles}>
            <Label className="vaLabel">Body</Label>
            <div className="vaContent">
              {this.state.alertBody ?
                ReactHtmlParser(this.state.alertBody) :
                ReactHtmlParser("")}</div>
          </Stack.Item>
          <div className="pdfDiv">
            <PDFExport
              scale={0.6}
              paperSize="auto"
              margin="1cm"
              fileName={`GRIP_Alert_${this._itemId}.pdf`}
              author="GRIP Team"
              ref={(container) => (this._pdfContainer = container)}
            >
              <div className="pdfDiv_main">
                <div className="grip_pdf_logo"><img src={this.props.webURL + "/SiteAssets/Images/AboutUs/Gilead_GRIP_Logo.png"} /></div>
                <div className="pdfDiv_cont">
                  <Stack.Item styles={stackItemStyles}>
                    <div className='vaFormControls'>
                      <Label className="vaLabel">Region</Label>
                      {this.state.alertRegion}
                    </div>
                    <div className='vaFormControls'>
                      <Label className="vaLabel">Document Type</Label>
                      {this.state.alertDocType}
                    </div>
                  </Stack.Item>
                  <Stack.Item styles={stackItemStyles}>
                    <div className='vaFormControls'>
                      <Label className="vaLabel">Therapeutic Area</Label>
                      {this.state.alertTA}
                    </div>
                    <div className='vaFormControls'>
                      <Label className="vaLabel">Regulatory Topic</Label>
                      {this.state.alertRegTopic}
                    </div>
                  </Stack.Item>
                  {this.state.isSubmittoRI ? "" :
                    this.state.isUserAdmin ?
                      <Stack.Item styles={stackItemStyles}>
                        <div className='vaFormControls'>
                          <Label className="vaLabel">Meeting Agenda Start Time</Label>
                          {this.state.alertMeetStDt}
                        </div>
                        <div className='vaFormControls'>
                          <Label className="vaLabel">Meeting Agenda End Time</Label>
                          {this.state.alertMeetEnDt}
                        </div>
                      </Stack.Item> : ""
                  }
                  {
                    this.state.isSubmittoRI ?
                      ""
                      :
                      <Stack.Item styles={stackItemStyles}>
                        <div className='vaFormControls'>
                          <Label className="vaLabel">Publication Date</Label>
                          {this.state.alertPubDate}
                        </div>
                        <div className='vaFormControls'>
                          <Label className="vaLabel">Author</Label>
                          {this.state.alertAuthor}
                        </div>
                      </Stack.Item>
                  }
                  <Stack.Item styles={stackItemStyles}>
                    <div className='vaFormControls'>
                      <Label className="vaLabel">Status</Label>
                      {
                        this.state.isSubmittoRI && !this.state.isUserAdmin ?
                          this.state.alertStatus != AlertStatus.Submitted && this.state.alertStatus != AlertStatus.Publish && this.state.alertStatus != AlertStatus.Rejected ?
                            "Review In Progress"
                            :
                            this.state.alertStatus
                          :
                          this.state.alertStatus
                      }
                    </div>
                  </Stack.Item>
                  <Stack.Item styles={stackItemStyles}>
                    <Label className="vaLabel">Title</Label>
                    <div className="vaContent">{this.state.alertTitle}</div>
                  </Stack.Item>
                  <Stack.Item styles={stackItemStyles}>
                    <Label className="vaLabel">Impact</Label>
                    <div className="vaContent">{this.state.alertImpact}</div>
                  </Stack.Item>
                  <Stack.Item styles={stackItemStyles}>
                    <Label className="vaLabel">Body</Label>
                    <div className="vaContent">
                      {this.state.alertBody ?
                        ReactHtmlParser(this.state.alertBody) :
                        ReactHtmlParser("")}</div>
                  </Stack.Item>
                </div>
              </div>
            </PDFExport>
          </div>
          <Stack.Item>
            <div className='vaAdminButtons'>
              {this.state.isUserAdmin && this.state.isForApproval ?
                <span>
                  <PrimaryButton text="Approve" className="priymary_btn_red" onClick={this.onApproveClick.bind(this)} />
                  <PrimaryButton text="Reject" className="priymary_btn_red" onClick={this.onRejectClick.bind(this)} />
                </span>
                : null}
              {this.state.hideDeleteButton ? null :
                <span>
                  <PrimaryButton text="Edit" className="priymary_btn_red" onClick={this.onEditButtonClick.bind(this)} />
                  <PrimaryButton text="Delete" className="priymary_btn_red" onClick={this.onDeleteButtonClick.bind(this)} />
                </span>
              }
            </div>
            <div className='vaUserButtons'>
              {this.state.isSubmittoRI ? null : <PrimaryButton text="Export to PDF" className="priymary_btn_red" onClick={this.onPDFClick.bind(this)} />}
              {this.state.isSubmittoRI ? null : <PrimaryButton text="Share" className="priymary_btn_red" onClick={this.onShareClick.bind(this)} />}
              <DefaultButton text="Close" className="grey_btn" onClick={this.closeForm.bind(this)} />
            </div>

            <Dialog
              hidden={this.state.hideShareDialog}
              onDismiss={this.closeShareDialog.bind(this)}
              dialogContentProps={{
                type: DialogType.normal,
                title: 'Share Alert',
              }}
              modalProps={{
                isBlocking: true,
                containerClassName: 'ms-dialogMainOverrideShare'
              }}
            >
              <div className="maShareDialog maShareDialogleft">
                <input className="maShareDialogTextField" value={window.location.href} readOnly
                  ref={this._refTextToCopy}
                />
                <IconButton iconProps={this._copyIcon} title="Copy to Clipboard" ariaLabel="Copy to Clipboard"
                  className="maCopyIcon" onClick={this.copyToClipboard.bind(this)} />
              </div>
              <DialogFooter>
                <DefaultButton onClick={this.closeShareDialog.bind(this)} text="Cancel" />
              </DialogFooter>
            </Dialog>
            <Dialog
              hidden={this.state.hideDeleteDialog}
              onDismiss={this.closeDeleteDialog.bind(this)}
              dialogContentProps={{
                type: DialogType.normal,
                title: 'Delete Alert',
                subText: "Do you want to delete this alert?"
              }}
              modalProps={{
                isBlocking: true,
                containerClassName: 'ms-dialogMainOverride'
              }}
            >
              <DialogFooter>
                <PrimaryButton onClick={this.deleteAlert.bind(this)} text="Confirm" />
                <DefaultButton onClick={this.closeDeleteDialog.bind(this)} text="Cancel" />
              </DialogFooter>
            </Dialog>
            <Dialog
              hidden={this.state.hideRejectComments}
              onDismiss={this.closeRejectCommDialog.bind(this)}
              dialogContentProps={{
                type: DialogType.normal,
                title: 'Review Comments',
              }}
              modalProps={{
                isBlocking: true,
                containerClassName: 'ms-dialogMainOverrideReject'
              }}
            >
              <TextField label="Comments" multiline rows={6} value={this.state.ADBComments} onChange={this.onCommentsChange.bind(this)} />
              <DialogFooter>
                <PrimaryButton onClick={this.submitReviewComments.bind(this, this.state.ADBComments, AlertStatus.Reviewed)} text="Submit" disabled={this.state.disableSubmitCommBtn} />
                <DefaultButton onClick={this.closeRejectCommDialog.bind(this)} text="Cancel" />
              </DialogFooter>
            </Dialog>
          </Stack.Item>
        </Stack>
        <BlockUIComp hideLoadingDialog={this.state.hideLoadingDialog} loadingText={this.state.loadingText}></BlockUIComp>
      </div>
    );
  }

  private _getQueryParam = (): void => {
    try {
      let paramVal = Common.getQueryStringValue('id');
      if (paramVal.length > 0) {
        this._itemId = Number.parseInt(paramVal);

        //log user visits
        let AlertAnalyticsList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertAnalytics);
        Common.logSiteVisit(AlertAnalyticsList, PageName.Alerts, this.state.isUserAdmin, this._currUser["Id"], this._itemId);

        this._loadAlertData(paramVal);
      }
      else
        this.setState({ hideLoadingDialog: true });
    } catch (error) {
      LoggerService.errorLog(error, 'ViewAlert > _getQueryParam');
    }
  }

  private _loadAlertData = (itemId: string): void => {
    try {
      let alertDBListName: string = "";
      let selectStr: string = '', expandStr: string = '';
      if (!this.state.isSubmittoRI) {
        alertDBListName = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsDatabase);
        selectStr = '*, Author/Title, Author/EMail, ADBAuthor/Title, ADBAuthor/EMail';
        expandStr = "Author, ADBAuthor";
      }
      else {
        alertDBListName = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsSubmitRItoTeam);
        selectStr = "*, Author/Title, Author/EMail, Editor/Title, Editor/EMail";
        expandStr = "Author, Editor";
      }

      ListService.GetDataByFilterWithExpand(alertDBListName, `ID eq ${itemId}`, selectStr, expandStr).then(response => {
        if (response) {
          if (!this.state.isSubmittoRI) {
            this.setState({
              alertTitle: response[0].Title,
              alertImpact: response[0].ADBImpact,
              alertBody: Common.modifyRelativeURL(response[0].ADBAlertBody, this.props.context.pageContext.site.serverRelativeUrl, this.props.context.pageContext.site.absoluteUrl),
              alertMeetStDt: (response[0].ADBMeetingAgendaStartTime == null ? "N/A" : moment(response[0].ADBMeetingAgendaStartTime).format('ddd MMM DD, YYYY')) +
                (response[0].ADBMeetAgStTime ? (" - " + response[0].ADBMeetAgStTime) : ""),
              alertMeetEnDt: (response[0].ADBMeetingAgendaEndTime == null ? "N/A" : moment(response[0].ADBMeetingAgendaEndTime).format('ddd MMM DD, YYYY')) +
                (response[0].ADBMeetAgEndTime ? (" - " + response[0].ADBMeetAgEndTime) : ""),
              alertPubDate: moment(response[0].ADBPublicationDate).format('ddd MMM DD, YYYY'),
              alertStatus: response[0].ADBStatus,
              alertRegion: Common.getManagedMetadataString(response[0].G2Region),
              alertDocType: Common.getManagedMetadataString(response[0].G2DocumentType),
              alertRegTopic: Common.getManagedMetadataString(response[0].G2RegulatoryTopic),
              alertTA: Common.getManagedMetadataString(response[0].G2TherapeuticArea),
              alertAuthor: response[0].ADBAuthor.Title,
              alertAuthorEmail: response[0].ADBAuthor.EMail,
              alertCreatedByTitle: response[0].Author.Title,
              alertCreatedByEMail: response[0].Author.EMail,
              hideLoadingDialog: true
            });
          }
          else {
            this.setState({
              alertTitle: response[0].Title,
              alertImpact: response[0].ADBImpact,
              alertBody: Common.modifyRelativeURL(response[0].ADBAlertBody, this.props.context.pageContext.site.serverRelativeUrl, this.props.context.pageContext.site.absoluteUrl),
              alertStatus: response[0].ADBStatus,
              alertRegion: Common.getManagedMetadataString(response[0].G2Region),
              alertDocType: Common.getManagedMetadataString(response[0].G2DocumentType),
              alertRegTopic: Common.getManagedMetadataString(response[0].G2RegulatoryTopic),
              alertTA: Common.getManagedMetadataString(response[0].G2TherapeuticArea),
              alertAuthor: response[0].Author.Title,
              alertAuthorEmail: response[0].Author.EMail,
              hideShareDialog: true,
              hideLoadingDialog: true,
              alertModifiedByEmail: response[0].Editor.EMail,
              alertModifiedByTitle: response[0].Editor.Title
            });
          }
          if (response[0].ADBStatus == AlertStatus.SubmitForReview)
            this.setState({ isForApproval: true });
        }
        else {
          this.props.onSetNotification({ 'type': NotificationType.error, 'message': `Record not found!` });
        }
      }).catch(error => {
        this.props.onSetNotification({ 'type': NotificationType.error, 'message': `Record not found!` });
        LoggerService.errorLog(error, 'ViewAlert > _loadAlertData > GetDataByFilterWithExpand');
        this.setState({ hideLoadingDialog: true });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ViewAlert > _loadAlertData');
      this.setState({ hideLoadingDialog: true });
    }
  }

  private closeShareDialog() {
    this.setState({ hideShareDialog: true });
  }

  private copyToClipboard = (): void => {
    try {
      this._refTextToCopy.current.select();
      document.execCommand('copy');
      LoggerService.auditLog("Share dialog copy button clicked", 'ViewAlert > copyToClipboard');
      this.props.onSetNotification({ 'type': NotificationType.success, 'message': `Alert link copied successfully!` });
    } catch (error) {
      LoggerService.errorLog(error, 'ViewAlert > copyToClipboard');
    }
  }

  private closeForm() {
    LoggerService.auditLog("View form cancel clicked", 'ViewAlert > closeForm');
    let manageAlertsPage: string = "";
    if (!this.state.isSubmittoRI) {
      manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageAlerts);
    }
    else {
      manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageSubmitRItoTeam);
    }
    window.location.href = this.props.webURL + manageAlertsPage;
  }

  private onPDFClick() {
    try {
      this.setState({ hideLoadingDialog: false }, () => {
        LoggerService.auditLog("Export as PDF clicked", 'ViewAlert > onPDFClick');
        this._pdfContainer.save();
        this.props.onSetNotification({ 'type': NotificationType.success, 'message': `PDF exported successfully` });
        this.setState({ hideLoadingDialog: true });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ViewAlert > onPDFClick');
      this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
    }
  }

  private onShareClick() {
    LoggerService.auditLog("Share button clicked", 'ViewAlert > onShareClick');
    this.setState({ hideShareDialog: false });
  }

  private onEditButtonClick() {
    try {
      LoggerService.auditLog("Edit button clicked. Id - " + this._itemId, 'ViewAlert > onEditButtonClick');
      let addEditPage: string = "";
      if (!this.state.isSubmittoRI) {
        addEditPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.AddEditAlerts);
      }
      else {
        addEditPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.AddEditSubmitRItoTeam);
      }

      window.location.href = this.props.webURL + addEditPage + '#' + encodeURIComponent('Id=' + this._itemId);
    } catch (error) {
      LoggerService.errorLog(error, 'ViewAlert > onEditButtonClick');
    }
  }

  private onDeleteButtonClick = (): void => {
    this.setState({ hideDeleteDialog: false });
  }

  private closeDeleteDialog() {
    this.setState({ hideDeleteDialog: true });
  }

  private onRejectClick = (): void => {
    this.setState({ hideRejectComments: false });
  }

  private onApproveClick = (): void => {
    this.submitReviewComments('Approved', AlertStatus.Approved);
  }

  private closeRejectCommDialog = (): void => {
    this.setState({ hideRejectComments: true });
  }

  private submitReviewComments = (comments: string, alertStatus: string): void => {
    try {
      this.setState({ hideLoadingDialog: false }, () => {
        let ADBCommList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsDatabaseComments);
        let tmpObj: any = {
          ADBId: this._itemId,
          ADBComments: comments
        };

        if (this.state.isSubmittoRI) {
          tmpObj = {
            SubmitRItoTeamId: this._itemId,
            ADBComments: comments
          };
        }

        ListService.PostListData(tmpObj, ADBCommList)
          .then(result => {
            LoggerService.auditLog("Review comments submitted for alert - " + this._itemId, 'ViewAlert > submitReviewComments');
            this.changeAlertStatus(alertStatus);
          })
          .catch(exception => {
            LoggerService.errorLog(exception, 'ViewAlert > submitReviewComments > PostListData');
          });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ViewAlert > submitReviewComments');
    }
  }

  private changeAlertStatus(alStatus: string) {
    try {
      let alertsList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsDatabase);
      if (this.state.isSubmittoRI) {
        alertsList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsSubmitRItoTeam);
      }

      let tmpObj: any = {
        Id: this._itemId,
        ADBStatus: alStatus
      };

      ListService.UpdateListDataByID(alertsList, this._itemId, tmpObj)
        .then(result => {
          if (!this.state.isSubmittoRI) {
            LoggerService.auditLog("Alert status changed for alert - " + this._itemId + "; Status - " + alStatus, 'ViewAlert > changeAlertStatus');
          }
          else {
            LoggerService.auditLog("Submit RI to Team Alert status changed for - " + this._itemId + "; Status - " + alStatus, 'ViewSubmitRItoTeam > changeAlertStatus');
          }
          this.getEmailTemplate(alStatus);
        })
        .catch(exception => {
          if (!this.state.isSubmittoRI)
            LoggerService.errorLog(exception, 'ViewAlert > changeAlertStatus > UpdateListDataByID');
          else
            LoggerService.errorLog(exception, 'ViewSubmitRItoTeam > changeAlertStatus > UpdateListDataByID');
        });
    } catch (error) {
      if (!this.state.isSubmittoRI)
        LoggerService.errorLog(error, 'ViewAlert > changeAlertStatus');
      else
        LoggerService.errorLog(error, 'ViewSubmitRItoTeam > changeAlertStatus');
    }
  }

  private getEmailTemplate = (notificationType: string): void => {
    try {
      let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);
      switch (notificationType) {
        case AlertStatus.Reviewed:
          ListService.GetDataByFilterWithExpand(emailTmplList, `Title eq '${this.state.isSubmittoRI ? 'RI-AdminRejectAlert' : 'AdminRejectAlert'}'`,
            '*, ETFrom/EMail, ETTo/EMail, ETCc/EMail', 'ETFrom, ETTo, ETCc').then(response => {
              if (response) {
                this._prepRejectEmail(response);
              }
            });
          break;
        case AlertStatus.Approved:
          ListService.GetDataByFilterWithExpand(emailTmplList, `Title eq '${this.state.isSubmittoRI ? 'RI-AdminApproveAlert' : 'AdminApproveAlert'}'`,
            '*, ETFrom/EMail, ETTo/EMail, ETCc/EMail', 'ETFrom, ETTo, ETCc').then(response => {
              if (response) {
                this._prepApproveEmail(response);
              }
            });
          break;
        default:
          break;
      }
    } catch (error) {
      if (!this.state.isSubmittoRI)
        LoggerService.errorLog(error, 'ViewAlert > getEmailTemplate');
      else
        LoggerService.errorLog(error, 'ViewSubmitRItoTeam > getEmailTemplate');
    }
  }

  private async _prepRejectEmail(emailTemplate: any[]) {
    try {
      let emailFrom = '';
      let emailTo: any[] = [];
      let emailCc: any[] = [];
      let emailSub = emailTemplate[0]['ETSubject'];
      let emailBody = emailTemplate[0]['ETBody'];

      let addEditAlertPage = "";
      if (this.state.isSubmittoRI) {
        addEditAlertPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.AddEditSubmitRItoTeam);
      }
      else {
        addEditAlertPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.AddEditAlerts);
      }

      if (emailTemplate[0]["ETFrom"])
        emailFrom = emailTemplate[0]['ETFrom'].EMail;     

      //To Emails
      if (emailTemplate[0]["ETTo"]) {
        emailTo = emailTemplate[0]["ETTo"].map(em => em.EMail);
      }
      if (this.state.isSubmittoRI) {
        emailTo.push(this.state.alertModifiedByEmail);
      }
      else {
        emailTo.push(this.state.alertCreatedByEMail);
      }

      //Cc Emails
      if (emailTemplate[0]["ETCc"])
        emailCc = emailTemplate[0]["ETCc"].map(em => em.EMail);
      if (this.state.isSubmittoRI) {
        emailCc = emailCc.concat(this.state.admMems);
      }
      else {
        emailCc.push(this.state.alertAuthorEmail);
        emailCc = emailCc.concat(this.state.admMems);
      }

      emailSub = emailSub.replace("#Title#", this.state.alertTitle);
      emailBody = emailBody.replace("#Requestor#", this.state.isSubmittoRI ? this.state.alertModifiedByTitle : this.state.alertCreatedByTitle);
      emailBody = emailBody.replace("#LinkToItem#", "<a href='" + this.props.webURL + addEditAlertPage + "#" + encodeURIComponent("id=" + this._itemId) + "'>here</a>");
      emailBody = emailBody.replace("#Reviewer#", this._currUser["Title"]);
      emailBody = emailBody.replace("#ReviewComments#", this.state.ADBComments);

      this._sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody);
      if (this.state.isSubmittoRI) {
        this.props.onSetNotification({ 'type': NotificationType.success, 'message': `RI rejected successfully` });
      }
      else {
        this.props.onSetNotification({ 'type': NotificationType.success, 'message': `Alert rejected successfully` });
      }

    } catch (error) {
      if (!this.state.isSubmittoRI)
        LoggerService.errorLog(error, 'ViewAlert > _prepRejectEmail');
      else
        LoggerService.errorLog(error, 'ViewSubmitRItoTeam > _prepRejectEmail');
    }
  }

  private async _prepApproveEmail(emailTemplate: any[]) {
    try {
      let emailFrom = '';
      let emailTo: any[] = [];
      let emailCc: any[] = [];
      let emailSub = emailTemplate[0]['ETSubject'];
      let emailBody = emailTemplate[0]['ETBody'];
      let viewAlertPage = "";
      if (this.state.isSubmittoRI) {
        viewAlertPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ViewSubmitRItoTeam);
      }
      else {
        viewAlertPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ViewAlert);
      }

      if (emailTemplate[0]["ETFrom"])
        emailFrom = emailTemplate[0]['ETFrom'].EMail;     

      //To Emails
      if (emailTemplate[0]["ETTo"])
        emailTo = emailTemplate[0]["ETTo"].map(em => em.EMail);
      if (this.state.isSubmittoRI) {
        emailTo.push(this.state.alertModifiedByEmail);
      }
      else {
        emailTo.push(this.state.alertCreatedByEMail);
      }

      //Cc Emails
      if (emailTemplate[0]["ETCc"])
        emailCc = emailTemplate[0]["ETCc"].map(em => em.EMail);
      if (this.state.isSubmittoRI) {
        emailCc = emailCc.concat(this.state.admMems);
      }
      else {
        emailCc.push(this.state.alertAuthorEmail);
        emailCc = emailCc.concat(this.state.admMems);
      }

      emailSub = emailSub.replace("#Title#", this.state.alertTitle);
      emailBody = emailBody.replace("#Requestor#", this.state.isSubmittoRI ? this.state.alertModifiedByTitle : this.state.alertCreatedByTitle);
      emailBody = emailBody.replace("#LinkToItem#", "<a href='" + this.props.webURL + viewAlertPage + "#" + encodeURIComponent("id=" + this._itemId) + "'>here</a>");
      emailBody = emailBody.replace("#ApprovedBy#", this._currUser["Title"]);

      this._sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody);
      if (this.state.isSubmittoRI) {
        this.props.onSetNotification({ 'type': NotificationType.success, 'message': `RI approved successfully` });
      }
      else {
        this.props.onSetNotification({ 'type': NotificationType.success, 'message': `Alert approved successfully` });
      }

    } catch (error) {
      if (!this.state.isSubmittoRI)
        LoggerService.errorLog(error, 'ViewAlert > _prepApproveEmail');
      else
        LoggerService.errorLog(error, 'ViewSubmitRItoTeam > _prepApproveEmail');
    }
  }

  private async getAdminMembers(): Promise<string[]> {
    try {
      let grpName = Common.getConfigValue(this._configData, ConfigType.Roles, ConfigKey.Administrator);
      return await PermissionsService.getGroupMembers(grpName).then(members => {
        return members.map(mem => mem.Email);
      });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > getAdminMembers');
    }
  }

  private _sendEmail(emailFrom: string, emailTo: any[], emailCc: any[], emailSub: string, emailBody: string) {
    try {
      emailTo = emailTo.filter((x) => { return x !== undefined && x !== null; });
      emailCc = emailCc.filter((x) => { return x !== undefined && x !== null; });

      let navTo = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageAlerts);
      if (this.state.isSubmittoRI)
        navTo = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageSubmitRItoTeam);

      EmailService.sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody).then(result => {
        if (this.state.isSubmittoRI) {
          LoggerService.auditLog("Email sent", 'ViewAlert > _sendEmail');
        }
        else {
          LoggerService.auditLog("Email sent", 'ViewAlert > _sendEmail');
        }
        this.setState({ hideRejectComments: true, hideLoadingDialog: true }, () => window.location.href = this.props.webURL + navTo);
      }).catch(error => {
        if (this.state.isSubmittoRI)
          LoggerService.errorLog(error, 'ViewAlert > _sendEmail > sendEmail');
        else
          LoggerService.errorLog(error, 'ViewSubmitRItoTeam > _sendEmail > sendEmail');
      });
    } catch (error) {
      if (this.state.isSubmittoRI)
        LoggerService.errorLog(error, 'ViewAlert > _sendEmail');
      else
        LoggerService.errorLog(error, 'ViewSubmitRItoTeam > _sendEmail');
    }
  }

  private onCommentsChange = (ev: React.FormEvent<HTMLInputElement>, newComment?: string): void => {
    this.setState({ ADBComments: newComment }, () => this.validateComment());
  }

  private validateComment = (): void => {
    try {
      if (this.state.ADBComments.length > 0)
        this.setState({ disableSubmitCommBtn: false });
    } catch (error) {
      if (this.state.isSubmittoRI)
        LoggerService.errorLog(error, 'ViewAlert > validateComment');
      else
        LoggerService.errorLog(error, 'ViewSubmitRItoTeam > validateComment');
    }
  }

  private deleteAlert = (): void => {
    try {
      if (!this.state.isSubmittoRI) {
        this.setState({ hideLoadingDialog: false }, () => {
          Common.recycleAlert(this._configData, ConfigType.Lists, ConfigKey.AlertsDatabase, this._itemId).then(resp => {
            LoggerService.auditLog("Alert deleted - " + this._itemId, 'ViewAlert > deleteAlert');
            this.props.onSetNotification({ 'type': NotificationType.success, 'message': `Alert deleted successfully.` });
            this._itemId = 0;
            let manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageAlerts);
            this.setState({ hideDeleteDialog: true }, () => window.location.href = this.props.webURL + manageAlertsPage);
          }).catch(error => {
            LoggerService.errorLog(error, 'ViewAlert > deleteAlert > deleteAlert');
          });

        });
      }
      else {
        this.setState({ hideLoadingDialog: false }, () => {
          Common.recycleAlert(this._configData, ConfigType.Lists, ConfigKey.AlertsSubmitRItoTeam, this._itemId).then(resp => {
            LoggerService.auditLog("Submit RI to Team Alert deleted - " + this._itemId, 'ViewAlert > deleteAlert');
            this.props.onSetNotification({ 'type': NotificationType.success, 'message': `Submit RI to Team Alert deleted successfully.` });
            this._itemId = 0;
            let manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageSubmitRItoTeam);
            this.setState({ hideDeleteDialog: true }, () => window.location.href = this.props.webURL + manageAlertsPage);
          }).catch(error => {
            LoggerService.errorLog(error, 'ViewSubmitRItoTeam > deleteAlert > deleteAlert (Submit to RI)');
          });
        });
      }
    } catch (error) {
      if (!this.state.isSubmittoRI)
        LoggerService.errorLog(error, 'ViewAlert > deleteAlert');
      else
        LoggerService.errorLog(error, 'ViewSubmitRItoTeam > deleteAlert');
    }
  }
}
