/* tslint:disable */
require("./ViewAlert.module.css");
const styles = {
  viewAlert: 'viewAlert_320363e3',
  container: 'container_320363e3',
  row: 'row_320363e3',
  column: 'column_320363e3',
  'ms-Grid': 'ms-Grid_320363e3',
  title: 'title_320363e3',
  subTitle: 'subTitle_320363e3',
  description: 'description_320363e3',
  button: 'button_320363e3',
  label: 'label_320363e3'
};

export default styles;
/* tslint:enable */