import { WebPartContext } from "@microsoft/sp-webpart-base";
import { INotification } from "../../../models/INotification";

export interface IViewAlertProps {
  context: WebPartContext;
  webURL: string;
  listName: string;
  onSetNotification: (notification: INotification) => void;
}
