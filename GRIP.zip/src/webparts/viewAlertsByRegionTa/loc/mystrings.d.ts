declare interface IViewAlertsByRegionTaWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ViewAlertsByRegionTaWebPartStrings' {
  const strings: IViewAlertsByRegionTaWebPartStrings;
  export = strings;
}
