/* tslint:disable */
require("./ViewAlertsByRegionTa.module.css");
const styles = {
  viewAlertsByRegionTa: 'viewAlertsByRegionTa_66ef44c2',
  container: 'container_66ef44c2',
  row: 'row_66ef44c2',
  column: 'column_66ef44c2',
  'ms-Grid': 'ms-Grid_66ef44c2',
  title: 'title_66ef44c2',
  subTitle: 'subTitle_66ef44c2',
  description: 'description_66ef44c2',
  button: 'button_66ef44c2',
  label: 'label_66ef44c2'
};

export default styles;
/* tslint:enable */