import * as React from 'react';
import styles from './ViewAlertsByRegionTa.module.scss';
import { IViewAlertsByRegionTaProps } from './IViewAlertsByRegionTaProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { IStackItemStyles } from '@fluentui/react';
import { IConfiguration, ConfigType, ConfigKey } from '../../../models/IConfiguration';
import { Common } from '../../../common/common';
import { LoggerService } from '../../../services/LoggerService';

const stackItemStyles: IStackItemStyles = {
  root: {
    padding: 5
  }
};

export interface IViewAlertsByRegionTaState {
  alertRegions: any[];
  alertTAs: any[]; distCategories: any;
}

export default class ViewAlertsByRegionTa extends React.Component<IViewAlertsByRegionTaProps, IViewAlertsByRegionTaState> {
  private _configData: IConfiguration[] = [];
  private _manageAlertsPage = '';
  private _regionImagePath = '';
  private _taImagePath = '';
  private _taOrder = '';

  constructor(props) {
    super(props);
    this.state = {
      alertRegions: [],
      alertTAs: [], distCategories: []
    };
  }

  public componentDidMount() {
    try {
      Common.getConfigData().then(resp => {
        if (resp) {
          this._configData = resp;
          Common.errorLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ErrorLog);
          Common.auditLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AuditLog);
          this._manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageAlerts);
          this._regionImagePath = Common.getConfigValue(this._configData, ConfigType.ImagePath, ConfigKey.Region);
          this._taImagePath = Common.getConfigValue(this._configData, ConfigType.ImagePath, ConfigKey.TherapeuticArea);
          this._taOrder = Common.getConfigValue(this._configData, ConfigType.HomePage, ConfigKey.TAOrder);

          Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.Region).then(regions => {
            regions = regions.sort(this.compare);
            this.setState({ alertRegions: regions });
          });
          Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.TherapeuticArea).then(tas => {
            if (this._taOrder) {
              this.setState({ alertTAs: tas, distCategories: this._taOrder.split(",") });
            }
            else {
              let arrCats: any = [];
              tas.map(ta => {
                if (arrCats.indexOf(ta.category) == -1) {
                  arrCats.push(ta.category);
                }
              });
              arrCats = arrCats.sort();
              this.setState({ alertTAs: tas, distCategories: arrCats });
            }
          });
        }
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ViewAlertsByRegionTa > componentDidMount');
    }
  }

  public render(): React.ReactElement<IViewAlertsByRegionTaProps> {
    return (
      <div className={styles.viewAlertsByRegionTa}>
        <div className="ta_region_container">
          <div className="region_main">
            <h1>View Alerts By Region</h1>
            {this.state.alertRegions.length > 0 ? this.state.alertRegions.map(term =>
              //let qParam = 'viewtype=Region&viewid=3a1e35bc-556b-419f-ae8d-3d3910b8df0a&viewname=Canada';
              <a href='#' onClick={this.onLinkClicked.bind(this, ConfigKey.Region, term.key, term.text)}>
                <img src={this.props.webURL + this._regionImagePath + term.imagePath} />{term.text}</a>
            ) : null}
          </div>

          <div className="ta_main">
            <h1>View Alerts By Therapeutic Area</h1>
            {this.state.distCategories.length > 0 ? this.state.distCategories.map(cat => {
              let catData = this.state.alertTAs.filter((itm) => {
                return itm.category == cat;
              });
              catData = catData.sort(this.compare);
              return (<div>
                <div><h3>{cat}</h3></div>
                <div className="ta_main_cont">
                  {catData.map((term) => {
                    if (term.text.toLowerCase() !== "n/a") {
                      return (<div>
                        <a href='#' onClick={this.onLinkClicked.bind(this, ConfigKey.TherapeuticArea, term.key, term.text)}>
                          <p><img src={this.props.webURL + this._taImagePath + term.imagePath} /></p>
                          <p className="ta_link">{term.text} </p></a>
                      </div>);
                    }
                  })}
                </div>
              </div>);
            }
            ) : null}
          </div>
        </div>
      </div>
    );
  }

  private onLinkClicked = (viewType: string, viewId: string, viewName: string): void => {
    try {
      LoggerService.auditLog('Home Page > ' + viewType + ' > ' + viewName + ' clicked', 'ViewAlertsByRegionTa > onLinkClicked').then(data => {
        window.location.href = this.props.webURL + this._manageAlertsPage + '?' + encodeURIComponent('viewtype=' + viewType +
          '&viewid=' + viewId + "&viewname=" + viewName);
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ViewAlertsByRegionTa > onLinkClicked');
    }
  }

  private compare(a, b) {
    const bandA = a.displayOrder;
    const bandB = b.displayOrder;

    let comparison = 0;
    if (bandA > bandB) {
      comparison = 1;
    } else if (bandA < bandB) {
      comparison = -1;
    }
    return comparison;
  }
}
