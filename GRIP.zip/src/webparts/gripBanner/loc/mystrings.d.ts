declare interface IGripBannerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GripBannerWebPartStrings' {
  const strings: IGripBannerWebPartStrings;
  export = strings;
}
