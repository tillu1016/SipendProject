import * as React from 'react';
import styles from './GripBanner.module.scss';
import { IGripBannerProps } from './IGripBannerProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { LoggerService } from '../../../services/LoggerService';
import { Common } from '../../../common/common';
import { ConfigType, ConfigKey } from '../../../models/IConfiguration';
import ReactHtmlParser from 'react-html-parser';

interface IGripBannerState {
  bannerHTML: string;
}

export default class GripBanner extends React.Component<IGripBannerProps, IGripBannerState> {

  constructor(props) {
    super(props);

    this.state = {
      bannerHTML: ''
    };
  }

  public componentDidMount() {
    try {
      Common.getConfigData().then(resp => {
        if (resp) {
          Common.errorLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ErrorLog);
          Common.auditLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AuditLog);
          let bannerHTML = Common.getConfigValue(resp, ConfigType.HomePage, ConfigKey.BannerHTML);
          this.setState({ bannerHTML: bannerHTML });
        }
      }).catch(e => {
        LoggerService.errorLog(e.stack, 'GripBanner > componentDidMount > getConfigData');
      });
    } catch (error) {
      LoggerService.errorLog(error, 'GripBanner > componentDidMount');
    }
  }

  public render(): React.ReactElement<IGripBannerProps> {
    return (
      <div className={styles.gripBanner}>
      <div className="homebanner">
        {ReactHtmlParser(this.state.bannerHTML)}
      </div>
      </div>
    );
  }
}
