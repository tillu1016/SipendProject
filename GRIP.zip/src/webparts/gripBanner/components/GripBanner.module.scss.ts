/* tslint:disable */
require("./GripBanner.module.css");
const styles = {
  gripBanner: 'gripBanner_96ea01b6',
  container: 'container_96ea01b6',
  row: 'row_96ea01b6',
  column: 'column_96ea01b6',
  'ms-Grid': 'ms-Grid_96ea01b6',
  title: 'title_96ea01b6',
  subTitle: 'subTitle_96ea01b6',
  description: 'description_96ea01b6',
  button: 'button_96ea01b6',
  label: 'label_96ea01b6'
};

export default styles;
/* tslint:enable */