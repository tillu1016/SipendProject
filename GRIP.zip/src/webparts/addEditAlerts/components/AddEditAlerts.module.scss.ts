/* tslint:disable */
require("./AddEditAlerts.module.css");
const styles = {
  addEditAlerts: 'addEditAlerts_b26e22be',
  container: 'container_b26e22be',
  row: 'row_b26e22be',
  column: 'column_b26e22be',
  'ms-Grid': 'ms-Grid_b26e22be',
  title: 'title_b26e22be',
  subTitle: 'subTitle_b26e22be',
  description: 'description_b26e22be',
  button: 'button_b26e22be',
  label: 'label_b26e22be'
};

export default styles;
/* tslint:enable */