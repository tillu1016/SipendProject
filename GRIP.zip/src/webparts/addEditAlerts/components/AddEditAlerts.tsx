import "@pnp/polyfill-ie11";
import * as React from 'react';
import styles from './AddEditAlerts.module.scss';
import { IAddEditAlertsProps } from './IAddEditAlertsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { Stack, TextField, IStackItemStyles, Dropdown, DatePicker, PrimaryButton, DefaultButton, Label, MessageBar, MessageBarType, Dialog, DialogType, DialogFooter } from '@fluentui/react';
import { Common } from '../../../common/common';
import * as tinymce from 'tinymce';
import 'tinymce/plugins/advlist';
import 'tinymce/plugins/autoresize';
import 'tinymce/plugins/code';
import 'tinymce/plugins/fullscreen';
import 'tinymce/plugins/hr';
import 'tinymce/plugins/imagetools';
import 'tinymce/plugins/paste';
import 'tinymce/plugins/searchreplace';
import 'tinymce/plugins/template';
import 'tinymce/plugins/textcolor';
import 'tinymce/plugins/print';
import 'tinymce/plugins/preview';
import 'tinymce/plugins/table';
import 'tinymce/plugins/pagebreak';
import 'tinymce/plugins/hr';
import 'tinymce/plugins/insertdatetime';
require('tinymceImage');
require('tinymceLink');
require('tinymceLists');

import { Editor } from "@tinymce/tinymce-react";
import { ListService } from '../../../services/ListService';
import { IConfiguration, ConfigType, ConfigKey } from '../../../models/IConfiguration';
import { EmailService } from '../../../services/EmailService';
import { CurrentUser } from '@pnp/sp/src/siteusers';
import { PermissionsService } from '../../../services/PermissionsService';
import { AlertStatus } from '../../../models/IAlert';
import ReactHtmlParser from 'react-html-parser';
import { UserAlertsLogFrequency } from "../../../models/IUserAlertsLog";
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { LoggerService } from "../../../services/LoggerService";
import * as moment from 'moment-timezone';
import { NotificationType } from "../../../models/INotification";
import BlockUIComp from '../../../common/BlockUIComp';
import { sp } from "@pnp/sp";

interface IAddEditAlertsState {
  title: string; alertTitle: string; alertImpact: string; alertRegionOptions: any[]; alertTAOptions: any[]; alertRegTopicOptions: any[];
  alertDocTypeOptions: any[]; alertStatus: string; selRegion: any[]; selDocType: any[]; selTA: any[]; selRegTopic: any[];
  alertBody: string; meetAgStTime: Date; meetAgEndTime: Date; alertPubDate: Date; isNewRecord: boolean; disableSaveButton: boolean;
  hideDistributeButton: boolean; reviewComments: any[]; showErrorMessage: boolean; errorMessage: string; showSuccessMessage: boolean;
  successMessage: string; alertAuthor: string[]; alertAuthorId: number; alertAuthorTitle: string; hideDistributeDiag: boolean;
  hideUnpubDialog: boolean; isSubmittoRI: boolean; hideSubmitForAppBtn: boolean; timeOptions: any[]; selMeetAgStTime: string;
  selMeetAgEndTime: string; hideLoadingDialog: boolean; loadingText: string; admMems: string[]; viewPage: string;
  RIAuthorEmail: string; RIAuthorTitle: string; hideRejectAlertPopUp: boolean; RejectComments: string;
  disableRejectAlertSubmitBtn: boolean; hideUploadDialog: boolean; showUploadMsg: string; disableUploadButton: boolean;
}

const stackItemStyles: IStackItemStyles = {
  root: {
    padding: 5
  }
};

export default class AddEditAlerts extends React.Component<IAddEditAlertsProps, IAddEditAlertsState> {
  private _configData: IConfiguration[] = [];
  private _selRegionsObj: any[] = [];
  private _selTAObj: any[] = [];
  private _selRegTopicObj: any[] = [];
  private _selDocTypeObj: any[] = [];
  private _itemId: number = 0;
  private _currUser: CurrentUser;
  private _userAlImmeItemId: number = 0;
  private _selMeetAgStTimeIdx: number = -1;
  private _selMeetAgEndTimeIdx: number = -1;
  private _imgUploadPath: string = "";
  private _docUploadPath: string = "";
  private _uploadedFile: any;

  constructor(props) {
    super(props);
    tinymce.init({

    });

    let _isSubmittoRI: boolean = false;
    if (this.props.listName == "SubmittoRITeam") {
      _isSubmittoRI = true;
    }
    this.state = {
      title: '', alertTitle: '', alertImpact: '', alertRegionOptions: [], alertTAOptions: [], alertRegTopicOptions: [],
      alertDocTypeOptions: [], alertStatus: AlertStatus.Draft, selRegion: [], selDocType: [], selTA: [], selRegTopic: [], alertBody: '',
      meetAgStTime: null, meetAgEndTime: null, alertPubDate: moment().toDate(), alertAuthor: [], isNewRecord: true,
      disableSaveButton: true, hideDistributeButton: false, reviewComments: [], showErrorMessage: false, errorMessage: "",
      showSuccessMessage: false, successMessage: "", alertAuthorId: 0, alertAuthorTitle: '', hideDistributeDiag: true,
      hideUnpubDialog: true, isSubmittoRI: _isSubmittoRI, hideSubmitForAppBtn: false, timeOptions: [], selMeetAgStTime: '',
      selMeetAgEndTime: '', hideLoadingDialog: true, loadingText: "Please Wait...", admMems: [], viewPage: "",
      RIAuthorEmail: "", RIAuthorTitle: "", hideRejectAlertPopUp: true, RejectComments: "", disableRejectAlertSubmitBtn: true,
      hideUploadDialog: true, showUploadMsg: "", disableUploadButton: true
    };
  }

  public componentDidMount() {
    try {
      this.setState({ hideLoadingDialog: false }, () => {
        Common.timeZone = moment.tz.guess();
        moment.tz.setDefault(Common.timeZone);

        Common.getCurrentUserId().then((curUser: CurrentUser) => {
          this._currUser = curUser;
        });

        Common.getConfigData().then(resp => {
          if (resp) {
            Common.errorLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ErrorLog);
            Common.auditLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AuditLog);
            this._imgUploadPath = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ImageUploadPath);
            this._docUploadPath = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.DocUploadPath);
            ListService.addFolder(this._imgUploadPath, new Date().getFullYear().toString());
            ListService.addFolder(this._docUploadPath, new Date().getFullYear().toString());

            let adminGrpName: string = Common.getConfigValue(resp, ConfigType.Roles, ConfigKey.Administrator);
            Common.checkIfUserAdmin(adminGrpName).then(isUsrAdm => {
              if (!this.state.isSubmittoRI && !isUsrAdm) {
                alert('You are not authorized to view this page. Please contact GRIP Administrator');
                window.location.href = this.props.webURL;
              }
              else if (this.state.isSubmittoRI && !isUsrAdm && !this.state.isNewRecord) {
                window.location.href = this.props.webURL;
              }
            });

            this._configData = resp;
            Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.Region).then(regions => {
              this.setState({ alertRegionOptions: regions });
            });
            Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.RegulatoryTopic).then(regTopics => {
              this.setState({ alertRegTopicOptions: regTopics });
            });
            Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.TherapeuticArea).then(tas => {
              this.setState({ alertTAOptions: tas });
            });
            Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.DocumentType).then(docType => {
              this.setState({ alertDocTypeOptions: docType });
            });

            let viewPageTemp = Common.getConfigValue(this._configData, ConfigType.Page, this.state.isSubmittoRI ? ConfigKey.ViewSubmitRItoTeam : ConfigKey.ViewAlert);
            this.setState({ viewPage: viewPageTemp });

            this._getTimeValues();
            this._getQueryParam();
            this._getReviewComments();
            this._getAdminMembers().then(result => {
              this.setState({ admMems: result, hideLoadingDialog: true });
            });
          }
        }).catch(e => {
          LoggerService.errorLog(e.stack, 'AddEditAlerts > componentDidMount > getConfigData');
          this.setState({ showErrorMessage: true, errorMessage: "Unble to get Configuration Data. Please Contact Application Administrator!" });
        });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > componentDidMount');
    }
  }

  private _getTimeValues = (): void => {
    try {
      let timeValue = "12:00AM";
      let lastValue;
      let endLimit = "11:59PM";
      let step = 30;
      let options = [];

      options.push({ key: -1, text: "Select an Option" });
      options.push({ key: timeValue, text: timeValue });

      while (this.isEarlierThanEndLimit(timeValue, endLimit, lastValue)) {
        lastValue = timeValue;
        timeValue = moment(timeValue, 'h:mmA').add(step, 'minutes').format('h:mmA');
        options.push({ key: timeValue, text: timeValue });
      }
      this.setState({ timeOptions: options });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _getTimeValues');
    }
  }

  private _getQueryParam = (): void => {
    try {
      let paramVal = Common.getQueryStringValue('id');
      if (paramVal.length > 0) {
        this._itemId = Number.parseInt(paramVal);
        this.setState({ isNewRecord: false }, () => {
          this._loadAlertData(paramVal);
        });
      } else {
        this.setState({
          alertAuthorId: this._currUser["Id"], alertAuthor: [this._currUser["Email"]],
          alertAuthorTitle: this._currUser["Title"]
        });
      }

    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _getQueryParam');
    }
  }

  private _getReviewComments = (): void => {
    try {
      let ADBCommList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsDatabaseComments);
      let filter: string = `ADBId eq ${this._itemId}`;
      if (this.state.isSubmittoRI) {
        filter = `SubmitRItoTeamId eq ${this._itemId}`;
      }

      ListService.GetDataByFilterWithExpand(ADBCommList, filter,
        '*, Editor/Title', 'Editor').then(response => {
          if (response) {
            let arrRevComms: any[] = [];
            response.map(com => {
              let comDt = moment(com["Modified"]).format('ddd, MMM DD, YYYY, h:mma');
              //let comDtFrmt = (comDt.getMonth() + 1) + "/" + comDt.getDate() + "/" + comDt.getFullYear();
              arrRevComms.push({ reviewBy: com["Editor"]["Title"], reviewComment: com['ADBComments'], reviewDate: comDt });
            });
            this.setState({ reviewComments: arrRevComms });
          }
        }).catch(err => {
          LoggerService.errorLog(err, 'AddEditAlerts > _getReviewComments > GetDataByFilterWithExpand');
        });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _getReviewComments');
    }
  }

  private async _getAdminMembers(): Promise<string[]> {
    try {
      let grpName = Common.getConfigValue(this._configData, ConfigType.Roles, ConfigKey.Administrator);
      return await PermissionsService.getGroupMembers(grpName).then(members => {
        return members.map(mem => mem.Email);
      });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _getAdminMembers');
    }
  }

  private _loadAlertData = (itemId: string): void => {
    try {
      let alertDBListName: string = "";

      if (!this.state.isSubmittoRI) {
        alertDBListName = this._configData.filter((item) => {
          return item.title == ConfigType.Lists && item.key == ConfigKey.AlertsDatabase;
        })[0].value;
      }
      else {
        alertDBListName = this._configData.filter((item) => {
          return item.title == ConfigType.Lists && item.key == ConfigKey.AlertsSubmitRItoTeam;
        })[0].value;
      }

      if (!this.state.isNewRecord) {
        ListService.GetDataByFilterWithExpand(alertDBListName, `ID eq ${itemId}`, '*, ADBAuthor/ID, ADBAuthor/EMail, ADBAuthor/Title, Author/ID, Author/EMail, Author/Title', 'ADBAuthor, Author').then(response => {
          if (response && response.length > 0) {
            if (!this.state.isSubmittoRI) {
              this.setState({
                alertTitle: response[0].Title, alertImpact: response[0].ADBImpact, alertBody: Common.modifyRelativeURL(response[0].ADBAlertBody,
                  this.props.context.pageContext.site.serverRelativeUrl, this.props.context.pageContext.site.absoluteUrl),
                meetAgStTime: response[0].ADBMeetingAgendaStartTime == null ? null : moment(response[0].ADBMeetingAgendaStartTime).toDate(),
                meetAgEndTime: response[0].ADBMeetingAgendaEndTime == null ? null : moment(response[0].ADBMeetingAgendaEndTime).toDate(),
                alertPubDate: moment(response[0].ADBPublicationDate).toDate(), alertStatus: response[0].ADBStatus,
                alertAuthor: [response[0].ADBAuthor['EMail']],
                alertAuthorId: response[0].ADBAuthor['ID'], alertAuthorTitle: response[0].ADBAuthor['Title'],
                selMeetAgStTime: response[0].ADBMeetAgStTime, selMeetAgEndTime: response[0].ADBMeetAgEndTime
              });
              this.setTimeValue('StartTime', response[0].ADBMeetAgStTime);
              this.setTimeValue('EndTime', response[0].ADBMeetAgEndTime);
            }
            else {
              this.setState({
                alertTitle: response[0].Title, alertImpact: response[0].ADBImpact, alertBody: Common.modifyRelativeURL(response[0].ADBAlertBody, this.props.context.pageContext.site.serverRelativeUrl, this.props.context.pageContext.site.absoluteUrl),
                alertStatus: response[0].ADBStatus, RIAuthorEmail: response[0].Author['EMail'], RIAuthorTitle: response[0].Author['Title'], alertAuthor: [response[0].ADBAuthor['EMail']],
                alertAuthorId: response[0].ADBAuthor['ID'], alertAuthorTitle: response[0].ADBAuthor['Title']
              });
            }

            this.extractManagedMetadata(ConfigKey.Region, response[0].G2Region);
            this.extractManagedMetadata(ConfigKey.DocumentType, response[0].G2DocumentType);
            this.extractManagedMetadata(ConfigKey.RegulatoryTopic, response[0].G2RegulatoryTopic);
            this.extractManagedMetadata(ConfigKey.TherapeuticArea, response[0].G2TherapeuticArea);

            if (response[0].ADBStatus == AlertStatus.SubmitForReview || response[0].ADBStatus == AlertStatus.Reviewed || response[0].ADBStatus == AlertStatus.Publish || response[0].ADBStatus == AlertStatus.Rejected)
              this.setState({ hideDistributeButton: true });
            if (response[0].ADBStatus == AlertStatus.Publish || response[0].ADBStatus == AlertStatus.Rejected)
              this.setState({ hideSubmitForAppBtn: true });

            this.setState({ hideLoadingDialog: true });
          }
          else {
            this.props.onSetNotification({ 'type': NotificationType.error, 'message': 'No item exists with the provided ID' });
            this.setState({ hideLoadingDialog: true });
          }
        }).catch(error => {
          LoggerService.errorLog(error, 'AddEditAlerts > _loadAlertData > GetDataByFilterWithExpand');
          this.setState({ hideLoadingDialog: true });
        });
      }
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _loadAlertData');
    }
  }

  private setTimeValue(type: string, fieldData: string) {
    try {
      let stIndex = this.state.timeOptions.findIndex(x => x.text == fieldData);
      switch (type) {
        case 'StartTime':
          this._selMeetAgStTimeIdx = stIndex;
          break;
        case 'EndTime':
          this._selMeetAgEndTimeIdx = stIndex;
          break;
        default:
          break;
      }
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > extractManagedMetadata');
    }
  }

  private extractManagedMetadata(type: string, fieldData: any[]) {
    try {
      if (fieldData.length <= 0)
        return "";

      let arrSelValue: any[] = [];
      fieldData.map((meta) => {
        switch (type) {
          case ConfigKey.Region:
            this._selRegionsObj.push({ key: meta.TermGuid, text: meta.Label });
            arrSelValue.push(meta.TermGuid);
            break;
          case ConfigKey.TherapeuticArea:
            this._selTAObj.push({ key: meta.TermGuid, text: meta.Label });
            arrSelValue.push(meta.TermGuid);
            break;
          case ConfigKey.RegulatoryTopic:
            this._selRegTopicObj.push({ key: meta.TermGuid, text: meta.Label });
            arrSelValue.push(meta.TermGuid);
            break;
          case ConfigKey.DocumentType:
            this._selDocTypeObj.push({ key: meta.TermGuid, text: meta.Label });
            arrSelValue.push(meta.TermGuid);
            break;
          default:
            break;
        }
      });

      switch (type) {
        case ConfigKey.Region:
          this.setState({ selRegion: [...arrSelValue] }, () => this._validate());
          break;
        case ConfigKey.TherapeuticArea:
          this.setState({ selTA: [...arrSelValue] }, () => this._validate());
          break;
        case ConfigKey.RegulatoryTopic:
          this.setState({ selRegTopic: [...arrSelValue] }, () => this._validate());
          break;
        case ConfigKey.DocumentType:
          this.setState({ selDocType: [...arrSelValue] }, () => this._validate());
          break;

        default:
          break;
      }
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > extractManagedMetadata');
    }
  }

  public render(): React.ReactElement<IAddEditAlertsProps> {
    return (
      <div className={styles.addEditAlerts} >
        <Stack>
          {this.state.showSuccessMessage ?
            <Stack.Item className="report_mgs">
              <MessageBar messageBarType={MessageBarType.success} isMultiline={false} onDismiss={() => {
                this.setState({ ...this.state, showSuccessMessage: false });
              }}>
                {this.state.successMessage}
              </MessageBar>
            </Stack.Item> : null}
          {this.state.showErrorMessage ?
            <Stack.Item className="report_mgs">
              <MessageBar messageBarType={MessageBarType.error} isMultiline={false} onDismiss={() => {
                this.setState({ ...this.state, showErrorMessage: false });
              }}>
                {this.state.errorMessage}
              </MessageBar>
            </Stack.Item> : null}
          <Stack.Item styles={stackItemStyles}>
            {this.state.isSubmittoRI ? this.state.isNewRecord ? <h1>Submit RI to Team</h1> : <h1>Edit Submit RI to Team</h1> :
              <h1>Add/Edit Alert</h1>}
          </Stack.Item>
          <Stack.Item styles={stackItemStyles}>
            <div className='aeLeftButtons'>
              {this.state.isSubmittoRI ? null : <PrimaryButton text="Send to Myself" className="priymary_btn_red"
                onClick={this._onSendToMyselfClick.bind(this)} />}
            </div>
            <div className='aeRightButtons'>
              {this.state.alertStatus == AlertStatus.Rejected ?
                null
                :
                <PrimaryButton text={this.state.isSubmittoRI ? this.state.isNewRecord ? "Submit" : "Save" : "Save"} className="priymary_btn_red"
                  onClick={this._onSaveClick.bind(this)} disabled={this.state.disableSaveButton} />
              }
              {this.state.isSubmittoRI && this.state.isNewRecord ? null :
                this.state.hideSubmitForAppBtn ? null : <PrimaryButton text="Submit For Approval" className="priymary_btn_red"
                  onClick={this._onSubmitForApprovalClick.bind(this)} disabled={this.state.disableSaveButton} />
              }
              {this.state.isSubmittoRI && this.state.isNewRecord ? null :
                this.state.hideDistributeButton ? null : <PrimaryButton text={this.state.isSubmittoRI ? "Approve" : "Publish"}
                  className="priymary_btn_red" onClick={this._onDistributebuttonClick.bind(this)} disabled={this.state.disableSaveButton} />
              }
              {this.state.isSubmittoRI && !this.state.isNewRecord ?
                this.state.hideDistributeButton ?
                  null
                  :
                  <PrimaryButton text={"Reject"} className="priymary_btn_red" onClick={this._onRejectButtonClick.bind(this)} disabled={this.state.disableSaveButton} />
                :
                null
              }
              {this.state.alertStatus == AlertStatus.Publish && !this.state.isSubmittoRI ? <PrimaryButton text="Unpublish"
                className="priymary_btn_red" onClick={this._onUnpublishClick.bind(this)} /> : null}
              <DefaultButton text="Cancel" className="grey_btn" onClick={this.onCancelClick.bind(this)} />
            </div>
          </Stack.Item>
          {this.state.reviewComments.length > 0 ? <Stack.Item styles={stackItemStyles}>
            <Label className="aeLabel">Review Comments</Label>
            {this.state.reviewComments.map(comm =>
              <div className='aeContent'>{ReactHtmlParser("<b>" + comm.reviewBy + "</b> " + comm.reviewDate + "<br />" + comm.reviewComment)}</div>
            )}
          </Stack.Item> : null}
          <Stack.Item styles={stackItemStyles}>
            <div className='aeTitleSummary'>
              <TextField required label="Title" onChange={this._onAlertTitleChange.bind(this)}
                value={this.state.alertTitle} />
            </div>
          </Stack.Item>
          <Stack.Item styles={stackItemStyles}>
            <div className='aeTitleSummary'>
              <TextField label="Impact" multiline rows={3} value={this.state.alertImpact} required={true}
                onChange={this._onAlertImpactChange.bind(this)} />
            </div>
          </Stack.Item>
          <Stack.Item styles={stackItemStyles}>
            <Label className="aeLabel">Body</Label>
            <Editor
              value={this.state.alertBody}
              init={{
                height: 500,
                menubar: true,
                plugins: [
                  'advlist lists link image print preview',
                  'searchreplace code fullscreen',
                  'insertdatetime table paste code, contextmenu'
                  //'table'
                ],
                toolbar: ['undo redo | bold italic underline strikethrough | formatselect | alignleft aligncenter alignright alignjustify | \
                  outdent indent |  numlist bullist | forecolor backcolor removeformat | hr | table insertfile image uploadDoc link | \
                  preview print | cut copy paste pastetext selectall'],
                contextmenu: "copy paste | link | table",
                image_advtab: false,
                image_caption: false,
                image_title: true,
                automatic_uploads: true,
                convert_urls: false,
                branding: false,
                images_upload_handler: (blobInfo, success, failure) => {
                  let file: any = blobInfo.blob();
                  let uniqueFile = file.name.substr(0, file.name.lastIndexOf('.')) + "-" + new Date().getTime() +
                    file.name.substr(file.name.lastIndexOf('.'));
                  let yrFolder: string = new Date().getFullYear().toString();
                  ListService.AddFile(`${this.props.context.pageContext.web.serverRelativeUrl}/${this._imgUploadPath}/${yrFolder}`,
                    uniqueFile, file, true)
                    .then(result => {
                      success(this.props.webURL + "/" + this._imgUploadPath + "/" + yrFolder + "/" + result.data["Name"]);
                    })
                    .catch((e) => {
                      failure(e);
                    });
                },
                setup: (editor) => {
                  editor.ui.registry.addButton('uploadDoc', {
                    icon: 'upload',
                    tooltip: 'Upload Document',
                    onAction: () => {
                      this.uploadDoc(editor);
                    }
                  });
                }
              }}
              onEditorChange={this.handleEditorChange.bind(this)}
            />
          </Stack.Item>
          <Stack.Item className="macontrol_box" styles={stackItemStyles}>
            <div className='maFormControls'>
              <Dropdown
                placeholder="Select an option"
                label="Alert Region"
                options={this.state.alertRegionOptions}
                multiSelect
                required={true}
                onChange={this._onRegionChange.bind(this)}
                selectedKeys={this.state.selRegion}
              />
            </div>
            <div className='maFormControls'>
              <Dropdown
                placeholder="Select an option"
                label="Alert Document Type"
                multiSelect
                options={this.state.alertDocTypeOptions}
                required={true}
                onChange={this._onDocTypeChange.bind(this)}
                selectedKeys={this.state.selDocType}
              />
            </div>
          </Stack.Item>
          <Stack.Item className="macontrol_box" styles={stackItemStyles}>
            <div className='maFormControls'>
              <Dropdown
                placeholder="Select an option"
                label="Alert Therapeutic Area"
                multiSelect
                options={this.state.alertTAOptions}
                required={true}
                onChange={this._onTAChange.bind(this)}
                selectedKeys={this.state.selTA}
              />
            </div>
            <div className='maFormControls'>
              <Dropdown
                placeholder="Select an option"
                label="Alert Regulatory Topic"
                multiSelect
                options={this.state.alertRegTopicOptions}
                required={true}
                onChange={this._onRegTopicChange.bind(this)}
                selectedKeys={this.state.selRegTopic}
              />
            </div>
          </Stack.Item>
          {this.state.isSubmittoRI ? null : <Stack.Item className="macontrol_box" styles={stackItemStyles}>
            <div className='maFormControls'>
              <div className='aeDate'>
                <DatePicker
                  label='Meeting Agenda Start Date'
                  showWeekNumbers={true}
                  firstWeekOfYear={1}
                  showMonthPickerAsOverlay={true}
                  placeholder="Select a date..."
                  ariaLabel="Select a date"
                  value={this.state.meetAgStTime}
                  onSelectDate={this.onMeetAgStTimeSelectDate.bind(this)}
                /></div>
              <div className='aeTime'>
                <Dropdown
                  label="Time"
                  placeholder="Select an option"
                  options={this.state.timeOptions}
                  defaultSelectedKey="-1"
                  onChange={this._onMeetAgStTimeChange.bind(this)}
                  selectedKey={this.state.selMeetAgStTime}
                />
              </div>
            </div>
            <div className='maFormControls'>
              <div className='aeDate'>
                <DatePicker
                  label='Meeting Agenda End Date'
                  showWeekNumbers={true}
                  firstWeekOfYear={1}
                  showMonthPickerAsOverlay={true}
                  placeholder="Select a date..."
                  ariaLabel="Select a date"
                  value={this.state.meetAgEndTime}
                  onSelectDate={this.onMeetAgEndTimeSelectDate.bind(this)}
                />
              </div>
              <div className='aeTime'>
                <Dropdown
                  label="Time"
                  placeholder="Select an option"
                  options={this.state.timeOptions}
                  defaultSelectedKey="-1"
                  onChange={this._onMeetAgEndTimeChange.bind(this)}
                  selectedKey={this.state.selMeetAgEndTime}
                />
              </div>
            </div>
          </Stack.Item>
          }
          {this.state.isSubmittoRI ? null : <Stack.Item className="macontrol_box" styles={stackItemStyles}>
            <div className='maFormControls'>
              <DatePicker
                label='Publication Date'
                showWeekNumbers={true}
                firstWeekOfYear={1}
                showMonthPickerAsOverlay={true}
                placeholder="Select a date..."
                ariaLabel="Select a date"
                value={this.state.alertPubDate}
                onSelectDate={this.onAlertPubDateSelectDate.bind(this)}
                isRequired={true}
              />
            </div>
            <div className='maFormControls maFormControlRight'>
              <PeoplePicker
                context={this.props.context}
                tooltipMessage="Select Author"
                titleText="Author"
                personSelectionLimit={1}
                groupName={""}
                showtooltip={true}
                selectedItems={this._getPeoplePickerItems.bind(this)}
                defaultSelectedUsers={this.state.alertAuthor}
                showHiddenInUI={false}
                principalTypes={[PrincipalType.User]}
                ensureUser={true}
                resolveDelay={1000} />
            </div>
          </Stack.Item>
          }
          <Stack.Item styles={stackItemStyles}>
            <div className='aeLeftButtons'>
              {this.state.isSubmittoRI ? null : <PrimaryButton text="Send to Myself" className="priymary_btn_red"
                onClick={this._onSendToMyselfClick.bind(this)} />}
            </div>
            <div className='aeRightButtons'>
              {this.state.alertStatus == AlertStatus.Rejected ?
                null
                :
                <PrimaryButton text={this.state.isSubmittoRI ? this.state.isNewRecord ? "Submit" : "Save" : "Save"} className="priymary_btn_red"
                  onClick={this._onSaveClick.bind(this)} disabled={this.state.disableSaveButton} />
              }
              {this.state.isSubmittoRI && this.state.isNewRecord ? null :
                this.state.hideSubmitForAppBtn ? null : <PrimaryButton text="Submit For Approval" className="priymary_btn_red"
                  onClick={this._onSubmitForApprovalClick.bind(this)} disabled={this.state.disableSaveButton} />
              }
              {this.state.isSubmittoRI && this.state.isNewRecord ? null :
                this.state.hideDistributeButton ? null : <PrimaryButton text={this.state.isSubmittoRI ? "Approve" : "Publish"}
                  className="priymary_btn_red" onClick={this._onDistributebuttonClick.bind(this)} disabled={this.state.disableSaveButton} />
              }
              {this.state.isSubmittoRI && !this.state.isNewRecord ?
                this.state.hideDistributeButton ?
                  null
                  :
                  <PrimaryButton text={"Reject"} className="priymary_btn_red" onClick={this._onRejectButtonClick.bind(this)} disabled={this.state.disableSaveButton} />
                :
                null
              }
              {
                this.state.alertStatus == AlertStatus.Publish && !this.state.isSubmittoRI ?
                  <PrimaryButton text="Unpublish"
                    className="priymary_btn_red" onClick={this._onUnpublishClick.bind(this)} />
                  : null
              }
              <DefaultButton text="Cancel" className="grey_btn" onClick={this.onCancelClick.bind(this)} />
            </div>
          </Stack.Item>
        </Stack>

        <Dialog
          hidden={this.state.hideDistributeDiag}
          onDismiss={this.closeDistributeDialog.bind(this)}
          dialogContentProps={{
            type: DialogType.normal,
            title: 'Publish Alert',
            subText: "Do you want to publish the alert & send immediate emails?"
          }}
          modalProps={{
            isBlocking: true,
            containerClassName: 'ms-dialogMainOverride'
          }}
        >
          <DialogFooter>
            <PrimaryButton onClick={this._onDistributeClick.bind(this)} text="Yes" />
            <DefaultButton onClick={this.closeDistributeDialog.bind(this)} text="No" />
          </DialogFooter>
        </Dialog>

        <Dialog
          hidden={this.state.hideUnpubDialog}
          onDismiss={this.closeUnpubDialog.bind(this)}
          dialogContentProps={{
            type: DialogType.normal,
            title: 'Unpublish Alert',
            subText: "Do you want to unpublish this alert?"
          }}
          modalProps={{
            isBlocking: true,
            containerClassName: 'ms-dialogMainOverride'
          }}
        >
          <DialogFooter>
            <PrimaryButton onClick={this.unPublishAlert.bind(this)} text="Confirm" />
            <DefaultButton onClick={this.closeUnpubDialog.bind(this)} text="Cancel" />
          </DialogFooter>
        </Dialog>

        <Dialog
          hidden={this.state.hideRejectAlertPopUp}
          onDismiss={this.closeRejectCommDialog.bind(this)}
          dialogContentProps={{
            type: DialogType.normal,
            title: 'Reject Comments',
          }}
          modalProps={{
            isBlocking: true,
            containerClassName: 'ms-dialogMainOverrideReject'
          }}
        >
          <TextField label="Comments" multiline rows={6} value={this.state.RejectComments} onChange={this._onRejectAlertCommentsChange.bind(this)} />
          <DialogFooter>
            <PrimaryButton onClick={this._submitReviewComments.bind(this, this.state.RejectComments, AlertStatus.Rejected)} text="Submit" disabled={this.state.disableRejectAlertSubmitBtn} />
            <DefaultButton onClick={this.closeRejectCommDialog.bind(this)} text="Cancel" />
          </DialogFooter>
        </Dialog>
        <Dialog
          hidden={this.state.hideUploadDialog}
          onDismiss={this.closeUploadDialog.bind(this)}
          dialogContentProps={{
            type: DialogType.normal,
            title: 'Upload Document',
          }}
          modalProps={{
            isBlocking: true,
            containerClassName: 'ms-dialogMainOverrideUpload'
          }}
        >
          {this.state.showUploadMsg !== "" ?
            <Stack.Item className="error_mgs">
              <MessageBar messageBarType={MessageBarType.error} isMultiline={false} onDismiss={() => {
                this.setState({ ...this.state, showErrorMessage: false });
              }}>
                {this.state.showUploadMsg}
              </MessageBar>
            </Stack.Item> : null}
          <Stack.Item>
            <input type="file" id="file" name="file" onChange={(e) => this.validateFileName(e.target.files)}></input>
          </Stack.Item>
          <DialogFooter>
            <PrimaryButton onClick={this._onUploadClick.bind(this)} text="Upload" disabled={this.state.disableUploadButton} />
            <DefaultButton onClick={this.closeUploadDialog.bind(this)} text="Cancel" />
          </DialogFooter>
        </Dialog>
        <BlockUIComp hideLoadingDialog={this.state.hideLoadingDialog} loadingText={this.state.loadingText}></BlockUIComp>
      </div >
    );
  }

  private _onRejectButtonClick() {
    this.setState({ hideRejectAlertPopUp: false });
  }

  private _submitReviewComments = (comments: string, alertStatus: AlertStatus): void => {
    try {
      this.setState({ hideRejectAlertPopUp: true, hideLoadingDialog: false }, () => {
        let ADBCommList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsDatabaseComments);
        let tmpObj: any = {
          ADBId: this._itemId,
          ADBComments: comments
        };

        if (this.state.isSubmittoRI) {
          tmpObj = {
            SubmitRItoTeamId: this._itemId,
            ADBComments: comments
          };
        }

        ListService.PostListData(tmpObj, ADBCommList)
          .then(result => {
            LoggerService.auditLog("Review comments submitted for RI - " + this._itemId, 'AddEditAlert > _submitReviewComments');
            this._changeAlertStatus(alertStatus);
          })
          .catch(exception => {
            LoggerService.errorLog(exception, 'ViewAlert > AddEditAlert > PostListData');
          });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ViewAlert > submitReviewComments');
    }
  }

  private _changeAlertStatus(alStatus: AlertStatus) {
    try {
      let alertsList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsSubmitRItoTeam);

      let tmpObj: any = {
        Id: this._itemId,
        ADBStatus: alStatus.toString()
      };

      ListService.UpdateListDataByID(alertsList, this._itemId, tmpObj)
        .then(result => {
          LoggerService.auditLog("Submit RI to Team Alert status changed for - " + this._itemId + "; Status - " + alStatus.toString(), 'AddEditAlert > _changeAlertStatus');
          this._getEmailTemplate(alStatus);
        })
        .catch(exception => {
          LoggerService.errorLog(exception, 'AddEditAlert > _changeAlertStatus > UpdateListDataByID');
        });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlert > _changeAlertStatus');
    }
  }

  private _getEmailTemplate = (notificationType: AlertStatus): void => {
    try {
      let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);
      Common.getEmailTemplate(emailTmplList, 'RI-Rejected').then(tmplResp => {
        if (tmplResp)
          this._prepUserEmail(tmplResp, notificationType);
      })
        .catch(err => {
          LoggerService.errorLog(err, 'AddEditAlerts > getEmailTemplate > _getEmailTemplate');
        });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlert > _getEmailTemplate');
    }
  }

  private _onRejectAlertCommentsChange = (ev: React.FormEvent<HTMLInputElement>, newComment?: string): void => {
    this.setState({ RejectComments: newComment }, () => this.validateComment());
  }

  private validateComment = (): void => {
    try {
      if (this.state.RejectComments.length > 0)
        this.setState({ disableRejectAlertSubmitBtn: false });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlert > validateComment');
    }
  }

  private closeRejectCommDialog = (): void => {
    this.setState({ hideRejectAlertPopUp: true });
  }

  private closeUploadDialog = (): void => {
    this._uploadedFile = '';
    this.setState({ hideUploadDialog: true, disableUploadButton: true });
  }

  private _onAlertTitleChange = (ev: React.FormEvent<HTMLInputElement>, newAlertTitle?: string) => {
    if (newAlertTitle.length > 255)
      this.props.onSetNotification({ 'type': NotificationType.error, 'message': `Title length can not exceed 255 characters!` });
    else
      this.setState({ alertTitle: newAlertTitle }, () => this._validate());
  }

  private _onAlertImpactChange = (ev: React.FormEvent<HTMLInputElement>, newAlertImpact?: string) => {
    this.setState({ alertImpact: newAlertImpact }, () => this._validate());
  }

  private _onRegionChange = (event, value): void => {
    this.setMultiselectState(ConfigKey.Region, "selRegion", value);
  }

  private _onTAChange = (event, value): void => {
    this.setMultiselectState(ConfigKey.TherapeuticArea, "selTA", value);
  }

  private _onDocTypeChange = (event, value): void => {
    this.setMultiselectState(ConfigKey.DocumentType, "selDocType", value);
  }

  private _onRegTopicChange = (event, value): void => {
    this.setMultiselectState(ConfigKey.RegulatoryTopic, "selRegTopic", value);
  }

  private _onMeetAgStTimeChange = (event, value): void => {
    this._selMeetAgStTimeIdx = -1;
    if (value.key !== -1) {
      let stIndex = this.state.timeOptions.findIndex(x => x.text == value.text);
      this._selMeetAgStTimeIdx = stIndex;
      this.setState({ selMeetAgStTime: value.text }, () => this._validate());
    } else
      this.setState({ selMeetAgStTime: "" }, () => this._validate());
  }

  private _onMeetAgEndTimeChange = (event, value): void => {
    this._selMeetAgEndTimeIdx = -1;
    if (value.key !== -1) {
      let stIndex = this.state.timeOptions.findIndex(x => x.text == value.text);
      this._selMeetAgEndTimeIdx = stIndex;
      this.setState({ selMeetAgEndTime: value.text }, () => this._validate());
    } else
      this.setState({ selMeetAgEndTime: "" }, () => this._validate());
  }

  private setMultiselectState = (stateName: string, selStateName: string, ddlVal: any[]) => {
    try {
      let selIDs = this.state[selStateName];

      if (ddlVal["selected"]) {
        selIDs.push(ddlVal["key"]);
      } else {
        var keyIdx2 = selIDs.findIndex(x => x == ddlVal["key"]);
        if (keyIdx2 !== -1) {
          selIDs.splice(keyIdx2, 1);
        }
      }
      let keyIdx: number = -1;
      switch (stateName) {
        case ConfigKey.Region:
          if (ddlVal["selected"]) {
            this._selRegionsObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
          } else {
            keyIdx = this._selRegionsObj.findIndex(x => x.key == ddlVal["key"]);
            if (keyIdx !== -1) {
              this._selRegionsObj.splice(keyIdx2, 1);
            }
          }
          this.setState({ selRegion: [...selIDs] }, () => this._validate());
          break;
        case ConfigKey.TherapeuticArea:
          if (ddlVal["selected"]) {
            this._selTAObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
          } else {
            keyIdx = this._selTAObj.findIndex(x => x.key == ddlVal["key"]);
            if (keyIdx !== -1) {
              this._selTAObj.splice(keyIdx2, 1);
            }
          }
          this.setState({ selTA: [...selIDs] }, () => this._validate());
          break;
        case ConfigKey.RegulatoryTopic:
          if (ddlVal["selected"]) {
            this._selRegTopicObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
          } else {
            keyIdx = this._selRegTopicObj.findIndex(x => x.key == ddlVal["key"]);
            if (keyIdx !== -1) {
              this._selRegTopicObj.splice(keyIdx2, 1);
            }
          }
          this.setState({ selRegTopic: [...selIDs] }, () => this._validate());
          break;
        case ConfigKey.DocumentType:
          if (ddlVal["selected"]) {
            this._selDocTypeObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
          } else {
            keyIdx = this._selDocTypeObj.findIndex(x => x.key == ddlVal["key"]);
            if (keyIdx !== -1) {
              this._selDocTypeObj.splice(keyIdx2, 1);
            }
          }
          this.setState({ selDocType: [...selIDs] }, () => this._validate());
          break;
        default:
          break;
      }
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > setMultiselectState');
    }
  }

  public handleEditorChange = (e, editor?) => {
    try {
      var newText = "";
      if (editor)
        newText = editor.getContent();
      else
        newText = e.target.getContent();

      this.setState({ alertBody: newText }, () => this._validate());
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > handleEditorChange');
    }
  }

  private onMeetAgStTimeSelectDate = (date: Date | null | undefined): void => {
    this.setState({ meetAgStTime: date }, () => this._validate());
  }

  private onMeetAgEndTimeSelectDate = (date: Date | null | undefined): void => {
    this.setState({ meetAgEndTime: date }, () => this._validate());
  }

  private onAlertPubDateSelectDate = (date: Date | null | undefined): void => {
    this.setState({ alertPubDate: date });
  }

  private saveAlert = (alertStatus: string): Promise<boolean> => {
    try {
      let alertDBListName = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsDatabase);
      let tmpRegions: string = '';

      if (this._selRegionsObj) {
        this._selRegionsObj.forEach(region => {
          if (tmpRegions == '')
            tmpRegions = `-1;#${region.text}|${region.key}`;
          else
            tmpRegions += `;#-1;#${region.text}|${region.key}`;
        });
      }
      let tmpRegTopic: string = '';
      if (this._selRegTopicObj) {
        this._selRegTopicObj.forEach(topic => {
          if (tmpRegTopic == '')
            tmpRegTopic = `-1;#${topic.text}|${topic.key}`;
          else
            tmpRegTopic += `;#-1;#${topic.text}|${topic.key}`;
        });
      }
      let tmpTA: string = '';
      if (this._selTAObj) {
        this._selTAObj.forEach(TA => {
          if (tmpTA == '')
            tmpTA = `-1;#${TA.text}|${TA.key}`;
          else
            tmpTA += `;#-1;#${TA.text}|${TA.key}`;
        });
      }
      let tmpDocType: string = '';
      if (this._selDocTypeObj) {
        this._selDocTypeObj.forEach(Doc => {
          if (tmpDocType == '')
            tmpDocType = `-1;#${Doc.text}|${Doc.key}`;
          else
            tmpDocType += `;#-1;#${Doc.text}|${Doc.key}`;
        });
      }

      let tmpObj: any = {
        Id: this._itemId,
        Title: this.state.alertTitle,
        ADBImpact: this.state.alertImpact,
        ADBAlertBody: this.state.alertBody,
        ADBStatus: alertStatus,
        ADBMeetingAgendaStartTime: this.state.meetAgStTime == null ? null : moment.tz(this.getGMTDateString(this.state.meetAgStTime), "GMT").format(),
        ADBMeetAgStTime: this.state.selMeetAgStTime,
        ADBMeetingAgendaEndTime: this.state.meetAgEndTime == null ? null : moment.tz(this.getGMTDateString(this.state.meetAgEndTime), "GMT").format(),
        ADBMeetAgEndTime: this.state.selMeetAgEndTime,
        ADBPublicationDate: moment.tz(this.getGMTDateString(this.state.alertPubDate), "GMT").format(),
        G2RegionTaxHTField: tmpRegions,
        G2TherapeuticAreaTaxHTField: tmpTA,
        G2RegulatoryTopicTaxHTField: tmpRegTopic,
        G2DocumentTypeTaxHTField: tmpDocType,
        ADBAuthorId: this.state.alertAuthorId
      };
      if (this.state.isSubmittoRI) {
        tmpObj["Id"] = 0;
        tmpObj["SubmitRItoTeamId"] = this._itemId;
      }

      if (this.state.isNewRecord || this.state.isSubmittoRI) {
        return new Promise<boolean>((resolve, reject) => {
          ListService.PostListData(tmpObj, alertDBListName)
            .then(result => {
              if (!this.state.isSubmittoRI) {
                LoggerService.auditLog(alertStatus + " - Alert saved - " + result.data.Id, 'AddEditAlerts > saveAlert');
              }
              else {
                LoggerService.auditLog(alertStatus + " - Alert saved - " + result.data.Id, 'AddEditAlerts > Publish Alert > saveAlert');
              }
              this._itemId = result.data.Id;
              resolve(true);
            })
            .catch(exception => {
              LoggerService.errorLog(exception, 'AddEditAlerts > saveAlert > PostListData');
              this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
              reject(exception);
            });
        });
      } else {
        return new Promise((resolve, reject) => {
          ListService.UpdateListDataByID(alertDBListName, this._itemId, tmpObj)
            .then(result => {
              LoggerService.auditLog(alertStatus + " - Alert updated - " + this._itemId, 'AddEditAlerts > saveAlert');
              resolve(true);
            })
            .catch(exception => {
              LoggerService.errorLog(exception, 'AddEditAlerts > saveAlert > UpdateListDataByID');
              this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
              reject(exception);
            });
        });
      }
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > saveAlert');
      this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
    }
  }

  private getGMTDateString = (dateToConert: Date): string => {
    var dateStr = dateToConert.getFullYear() + '-' + ('0' + (dateToConert.getMonth() + 1)).slice(-2) + '-' + ('0' + (dateToConert.getDate())).slice(-2);
    return (dateStr + "T10:00:00Z");
  }

  private saveSubmitRItoTeam = (alertStatus: string): Promise<boolean> => {
    try {
      let alertDBListName = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsSubmitRItoTeam);
      let tmpRegions: string = '';

      if (this._selRegionsObj) {
        this._selRegionsObj.forEach(region => {
          if (tmpRegions == '')
            tmpRegions = `-1;#${region.text}|${region.key}`;
          else
            tmpRegions += `;#-1;#${region.text}|${region.key}`;
        });
      }
      let tmpRegTopic: string = '';
      if (this._selRegTopicObj) {
        this._selRegTopicObj.forEach(topic => {
          if (tmpRegTopic == '')
            tmpRegTopic = `-1;#${topic.text}|${topic.key}`;
          else
            tmpRegTopic += `;#-1;#${topic.text}|${topic.key}`;
        });
      }
      let tmpTA: string = '';
      if (this._selTAObj) {
        this._selTAObj.forEach(TA => {
          if (tmpTA == '')
            tmpTA = `-1;#${TA.text}|${TA.key}`;
          else
            tmpTA += `;#-1;#${TA.text}|${TA.key}`;
        });
      }
      let tmpDocType: string = '';
      if (this._selDocTypeObj) {
        this._selDocTypeObj.forEach(Doc => {
          if (tmpDocType == '')
            tmpDocType = `-1;#${Doc.text}|${Doc.key}`;
          else
            tmpDocType += `;#-1;#${Doc.text}|${Doc.key}`;
        });
      }

      let publicationDate = moment.tz(this.getGMTDateString(new Date()), "GMT").format();
      if (alertStatus != "Published")
        publicationDate = null;

      let tmpObj: any = {
        Id: this._itemId,
        Title: this.state.alertTitle,
        ADBImpact: this.state.alertImpact,
        ADBAlertBody: this.state.alertBody,
        ADBStatus: alertStatus,
        G2RegionTaxHTField: tmpRegions,
        G2TherapeuticAreaTaxHTField: tmpTA,
        G2RegulatoryTopicTaxHTField: tmpRegTopic,
        G2DocumentTypeTaxHTField: tmpDocType,
        ADBPublicationDate: publicationDate,
        ADBAuthorId: this.state.alertAuthorId
      };

      if (this.state.isNewRecord) {
        return new Promise<boolean>((resolve, reject) => {
          ListService.PostListData(tmpObj, alertDBListName)
            .then(result => {
              this._itemId = result.data.Id;
              resolve(true);
            })
            .catch(exception => {
              LoggerService.errorLog(exception, 'AddEditAlerts > saveSubmitRItoTeam > PostListData');
              reject(exception);
            });
        });
      } else {
        return new Promise((resolve, reject) => {
          ListService.UpdateListDataByID(alertDBListName, this._itemId, tmpObj)
            .then(result => {
              resolve(true);
            })
            .catch(exception => {
              LoggerService.errorLog(exception, 'AddEditAlerts > saveSubmitRItoTeam > UpdateListDataByID');
              reject(exception);
            });
        });
      }
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > saveSubmitRItoTeam');
    }
  }

  private _onSaveClick = (): void => {
    try {
      this.setState({ hideLoadingDialog: false }, () => {
        if (!this.state.isSubmittoRI) {
          let manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageAlerts);
          this.saveAlert(this.state.alertStatus).then(resp => {
            if (resp) {
              this.setState({ hideLoadingDialog: true }, () => window.location.href = this.props.webURL + manageAlertsPage);
            }
          });
        }
        else {
          let manageSubmitRItoTeamPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageSubmitRItoTeam);
          this.saveSubmitRItoTeam(this.state.isNewRecord ? AlertStatus.Submitted : this.state.alertStatus).then(async resp => {
            if (resp && this.state.isNewRecord) {
              // Send Email :
              let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);
              await Common.getEmailTemplate(emailTmplList, 'UserSubmitRItoTeam').then(tmplResp => {
                if (tmplResp)
                  this._prepUserEmail(tmplResp, AlertStatus.Submitted);
              });
              this.setState({ hideLoadingDialog: true }, () => window.location.href = this.props.webURL + manageSubmitRItoTeamPage);
            }
            else {
              this.setState({ hideLoadingDialog: true }, () => window.location.href = this.props.webURL + manageSubmitRItoTeamPage);
            }
          });
        }
      });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _onSaveClick');
    }
  }

  private _onSubmitForApprovalClick() {
    try {
      this.setState({ hideLoadingDialog: false }, () => {
        if (!this.state.isSubmittoRI) {
          this.saveAlert(AlertStatus.SubmitForReview).then(async saveResp => {
            if (saveResp) {
              let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);
              await Common.getEmailTemplate(emailTmplList, 'AdminSubmitForApproval').then(tmplResp => {
                if (tmplResp)
                  this._prepApprovalEmail(tmplResp);
              });
            }
          });
        }
        else {
          this.saveSubmitRItoTeam(AlertStatus.SubmitForReview).then(async resp => {
            if (resp) {
              // Send Email :
              let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);
              await Common.getEmailTemplate(emailTmplList, 'RI-SubmitForApproval').then(tmplResp => {
                if (tmplResp) {
                  this._prepSubmitRItoTeamApprovalEmail(tmplResp);
                }
              });
            }
          });
        }
      });

    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _onSubmitForApprovalClick');
    }
  }

  private _onDistributebuttonClick = (): void => {
    try {
      this.setState({ hideDistributeDiag: false });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _onDistributebuttonClick');
    }
  }

  private _onUnpublishClick = (): void => {
    try {
      this.setState({ hideUnpubDialog: false });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _onUnpublishClick');
    }
  }

  private closeUnpubDialog() {
    this.setState({ hideUnpubDialog: true });
  }

  private _validateNavigation = (isImmde: boolean, isDaily: boolean, isWeekly: boolean, issbRI: boolean): void => {
    try {
      if (isImmde && isDaily && isWeekly) {
        if (!issbRI) {
          let manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageAlerts);
          window.location.href = this.props.webURL + manageAlertsPage;
        }
        else {
          let manageSubmitRItoTeamPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageSubmitRItoTeam);
          this.props.onSetNotification({ 'type': NotificationType.success, 'message': `The Submit RI to Team has been approved successfully!` });
          window.location.href = this.props.webURL + manageSubmitRItoTeamPage;
        }
      }
    }
    catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _validateNavigation');
    }
  }

  private _onDistributeClick = (): void => {
    try {
      if (!this.state.isSubmittoRI) {
        this.setState({ hideLoadingDialog: false, hideDistributeDiag: true }, () => {
          this.saveAlert(AlertStatus.Publish).then(resp => {
            if (resp) {
              let isImmediateComp = false;
              let isDailyComp = false;
              let isWeeklyComp = false;
              let issbRI = false;

              this.addADBLog(UserAlertsLogFrequency.Immediately).then(immResp => {
                isImmediateComp = true;
                this._validateNavigation(isImmediateComp, isDailyComp, isWeeklyComp, issbRI);
              });
              this.addADBLog(UserAlertsLogFrequency.Daily).then(dailyResp => {
                isDailyComp = true;
                this._validateNavigation(isImmediateComp, isDailyComp, isWeeklyComp, issbRI);
              });
              this.addADBLog(UserAlertsLogFrequency.Weekly).then(weeklyResp => {
                isWeeklyComp = true;
                this._validateNavigation(isImmediateComp, isDailyComp, isWeeklyComp, issbRI);
              });
            }
          });
        });
      }
      else {
        this.setState({ hideLoadingDialog: false, hideDistributeDiag: true }, () => {


          this.setState({ alertAuthorId: this._currUser["Id"], alertAuthorTitle: this._currUser["title"] }, () => {
            this.saveSubmitRItoTeam(AlertStatus.Publish).then(async resp => {
              if (resp) {
                this.props.onSetNotification({ 'type': NotificationType.success, 'message': `The Submit RI to Team has been approved successfully! Do not refresh the page until the immediate alerts have been sent.` });
                // Send Email to User:
                let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);
                await Common.getEmailTemplate(emailTmplList, 'RI-Approved').then(tmplResp => {
                  if (tmplResp) {
                    this._prepUserEmail(tmplResp, AlertStatus.Publish);
                  }
                });

                // Copy Published one to Alerts List & Send emails to users
                this.saveAlert(AlertStatus.Publish).then(saveResp => {
                  if (saveResp) {

                    let isImmediateComp = false;
                    let isDailyComp = false;
                    let isWeeklyComp = false;
                    let issbRI = true;

                    // Add to Alerts DB Logs
                    this.addADBLog(UserAlertsLogFrequency.Immediately).then(immResp => {
                      isImmediateComp = true;
                      this._validateNavigation(isImmediateComp, isDailyComp, isWeeklyComp, issbRI);
                    });
                    this.addADBLog(UserAlertsLogFrequency.Daily).then(dailyResp => {
                      isDailyComp = true;
                      this._validateNavigation(isImmediateComp, isDailyComp, isWeeklyComp, issbRI);
                    });;
                    this.addADBLog(UserAlertsLogFrequency.Weekly).then(weeklyResp => {
                      isWeeklyComp = true;
                      this._validateNavigation(isImmediateComp, isDailyComp, isWeeklyComp, issbRI);
                    });
                  }
                });
              }
            });
          });
        });
      }
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _onDistributeClick');
    }
  }

  private addADBLog = (freq: string): Promise<boolean> => {
    try {
      let adbLogList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.UserAlertsLog);

      return new Promise<boolean>((resolve, reject) => {
        ListService.GetDataByFilter(adbLogList, `ADBItemId eq ${this._itemId} and ADBLFrequency eq '${freq}' and ADBLStatus eq 'New'`, '*').then(resp => {
          if (resp.length > 0) {

            if (freq == UserAlertsLogFrequency.Immediately)
              this._userAlImmeItemId = resp[0].Id;
            resolve(true);
          } else {
            let tmpObj: any = {
              ADBItemId: this._itemId,
              Title: this.state.alertTitle,
              ADBLFrequency: freq,
              ADBPublicationDate: moment.tz(this.getGMTDateString(this.state.alertPubDate), "GMT").format()
            };
            ListService.PostListData(tmpObj, adbLogList)
              .then(result => {
                //LoggerService.auditLog("Alert log entry created for - " + freq, 'AddEditAlerts > addADBLog');
                if (freq == UserAlertsLogFrequency.Immediately)
                  this._userAlImmeItemId = result.data.Id;
                resolve(true);
              })
              .catch(error => {
                LoggerService.errorLog(error, 'AddEditAlerts > addADBLog > PostListData');
                this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
                reject(false);
              });
          }
        }).catch(error => {
          LoggerService.errorLog(error, 'AddEditAlerts > addADBLog > GetDataByFilter');
          this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
          reject(false);
        });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > addADBLog');
      this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
    }
  }

  private getSubscriptions = (): void => {
    try {
      let subsListName = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.Subscriptions);
      let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);

      let regionCAML: string = '<In><FieldRef Name = "G2Region"/><Values>';
      regionCAML += this._selRegionsObj.map(reg => { return `<Value Type="TaxonomyFieldType">${reg.text}</Value>`; });
      regionCAML += '</Values></In>';

      let taCAML: string = '<In><FieldRef Name = "G2TherapeuticArea"/><Values>';
      taCAML += this._selTAObj.map(reg => { return `<Value Type="TaxonomyFieldType">${reg.text}</Value>`; });
      taCAML += '</Values></In>';

      let regTCAML: string = '<In><FieldRef Name = "G2RegulatoryTopic"/><Values>';
      regTCAML += this._selRegTopicObj.map(reg => { return `<Value Type="TaxonomyFieldType">${reg.text}</Value>`; });
      regTCAML += '</Values></In>';

      let query: string = `<View><ViewFields><FieldRef Name='Title' /><FieldRef Name='ASSubscriber' /><FieldRef Name='Id' /></ViewFields>
          <Query><Where><And><Eq><FieldRef Name='ASFrequency' /> <Value Type='Text'>Immediate</Value></Eq>
          <Or>${taCAML}<Or>${regionCAML}${regTCAML}</Or></Or></And></Where></Query></View>`;

      ListService.GetDataByCAMLStream(subsListName, query).then(async subsResp => {
        if (subsResp) {
          await Common.getEmailTemplate(emailTmplList, 'ImmediateSubscription').then(tmplResp => {
            if (tmplResp) {
              this._prepImmediateEmail(tmplResp, subsResp['Row']);
            }
          })
            .catch(err => {
              LoggerService.errorLog(err, 'AddEditAlerts > getSubscriptions > getEmailTemplate');
              this.setState({ hideLoadingDialog: true });
              this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
            });
        }
      }).catch(err => {
        LoggerService.errorLog(err, 'AddEditAlerts > getSubscriptions > GetDataByCAMLStream');
        this.setState({ hideLoadingDialog: true });
        this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > getSubscriptions');
      this.setState({ hideLoadingDialog: true });
      this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
    }
  }

  private _validate() {
    try {
      let disableBtn: boolean = false;
      if (this.state.isSubmittoRI) {
        if (this.state.alertTitle !== "" && this.state.alertImpact !== "" &&
          this.state.alertBody !== "" && this.state.selRegion.length > 0 &&
          this.state.selTA.length > 0 && this.state.selDocType.length > 0 && this.state.selRegTopic.length > 0)
          disableBtn = false;
        else
          disableBtn = true;
      } else {
        let stDt = moment(this.state.meetAgStTime).format('YYYY-MM-DD');
        let endDt = moment(this.state.meetAgEndTime).format('YYYY-MM-DD');

        if (this.state.alertTitle !== "" && this.state.alertImpact !== "" &&
          this.state.alertBody !== "" && this.state.selRegion.length > 0 &&
          this.state.selTA.length > 0 && this.state.selDocType.length > 0 && this.state.selRegTopic.length > 0 &&
          this.state.alertAuthorId !== 0) {
          if (this.state.meetAgStTime !== null || this.state.meetAgEndTime !== null) {
            if (this.state.meetAgStTime !== null && this.state.meetAgEndTime !== null && moment(stDt).isSameOrBefore(endDt)) {
              if (this._selMeetAgStTimeIdx !== -1 || this._selMeetAgEndTimeIdx !== -1) {
                if (this._selMeetAgEndTimeIdx !== -1 && this._selMeetAgStTimeIdx !== -1 && this._selMeetAgEndTimeIdx > this._selMeetAgStTimeIdx)
                  disableBtn = false;
                else disableBtn = true;
              }
              else disableBtn = false;
            } else {
              disableBtn = true;
            }
          }
        }
        else
          disableBtn = true;
      }
      this.setState({ disableSaveButton: disableBtn });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _validate');
    }
  }

  private onCancelClick = (): void => {
    LoggerService.auditLog("Cancel button clicked", 'AddEditAlerts > onCancelClick');
    let manageAlertsPage: string = "";
    if (!this.state.isSubmittoRI) {
      manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageAlerts);
    }
    else {
      manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageSubmitRItoTeam);
    }
    window.location.href = this.props.webURL + manageAlertsPage;
  }

  private async _prepApprovalEmail(emailTemplate: any[]) {
    try {
      let emailFrom = '';
      let emailTo: any[] = [];
      let emailCc: any[] = [];
      let emailSub = emailTemplate[0]['ETSubject'];
      let emailBody = emailTemplate[0]['ETBody'];
      let authorName: string = this._currUser['Title'];

      if (emailTemplate[0]["ETFrom"])
        emailFrom = emailTemplate[0]['ETFrom'].EMail;

      //To Emails
      if (emailTemplate[0]["ETTo"])
        emailTo = emailTemplate[0]["ETTo"].map(em => em.EMail);
      emailTo = emailTo.concat(this.state.admMems);
      //Cc Emails
      if (emailTemplate[0]["ETCc"])
        emailCc = emailTemplate[0]["ETCc"].map(em => em.EMail);

      emailCc.push(this._currUser['Email']); //Requestor

      if (this._currUser['Id'] !== this.state.alertAuthorId) {
        emailCc.push(this.state.alertAuthor[0]); //Author (if different from requestor) 
        authorName = this.state.alertAuthorTitle;
      }
      emailSub = emailSub.replace("#Title#", this.state.alertTitle);

      emailBody = emailBody.replace("#Requestor#", this._currUser['Title']);
      emailBody = emailBody.replace("#LinkToItem#", "<a href='" + this.props.webURL + this.state.viewPage + "#" + encodeURIComponent("id=" + this._itemId) + "'>View Alert</a>");
      emailBody = emailBody.replace("#Region#", this._selRegionsObj.map(reg => reg.text).toString());
      emailBody = emailBody.replace("#DocumentType#", this._selDocTypeObj.map(docType => docType.text).toString());
      emailBody = emailBody.replace("#TherapeuticArea#", this._selTAObj.map(ta => ta.text).toString());
      emailBody = emailBody.replace("#RegulatoryTopic#", this._selRegTopicObj.map(regT => regT.text).toString());
      emailBody = emailBody.replace("#MeetingAgendaStartTime#", (this.state.meetAgStTime == null ? "N/A" : moment(this.state.meetAgStTime).format('ddd, MMM DD, YYYY')) +
        " " + (this.state.selMeetAgStTime == null ? "" : this.state.selMeetAgStTime));
      emailBody = emailBody.replace("#MeetingAgendaEndTime#", (this.state.meetAgEndTime == null ? "N/A" : moment(this.state.meetAgEndTime).format('ddd, MMM DD, YYYY')) +
        " " + (this.state.selMeetAgEndTime == null ? "" : this.state.selMeetAgEndTime));
      emailBody = emailBody.replace("#PublicationDate#", moment(this.state.alertPubDate).format('ddd, MMM DD, YYYY'));
      emailBody = emailBody.replace("#Author#", authorName);
      emailBody = emailBody.replace("#Title#", this.state.alertTitle);
      emailBody = emailBody.replace("#Impact#", this.state.alertImpact);
      emailBody = emailBody.replace("#AlertBody#", this.state.alertBody);

      this._sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody, AlertStatus.SubmitForReview);

    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _prepApprovalEmail');
    }
  }

  private async _prepSubmitRItoTeamApprovalEmail(emailTemplate: any[]) {
    try {
      let emailFrom = '';
      let emailTo: any[] = [];
      let emailCc: any[] = [];
      let emailSub = emailTemplate[0]['ETSubject'];
      let emailBody = emailTemplate[0]['ETBody'];
      let authorName: string = this._currUser['Title'];

      if (emailTemplate[0]["ETFrom"])
        emailFrom = emailTemplate[0]['ETFrom'].EMail;

      //To Emails
      if (emailTemplate[0]["ETTo"])
        emailTo = emailTemplate[0]["ETTo"].map(em => em.EMail);
      emailTo = emailTo.concat(this.state.admMems);

      //Cc Emails
      if (emailTemplate[0]["ETCc"])
        emailCc = emailTemplate[0]["ETCc"].map(em => em.EMail);
      emailCc.push(this._currUser['Email']); //Requestor

      if (this._currUser['Id'] !== this.state.alertAuthorId) {
        emailCc.push(this.state.alertAuthor[0]); //Author (if different from requestor) 
        authorName = this.state.alertAuthorTitle;
      }
      emailSub = emailSub.replace("#Title#", this.state.alertTitle);

      emailBody = emailBody.replace("#Requestor#", this._currUser['Title']);
      emailBody = emailBody.replace("#LinkToItem#", "<a href='" + this.props.webURL + this.state.viewPage + "#" + encodeURIComponent("id=" + this._itemId) + "'>View RI</a>");
      emailBody = emailBody.replace("#Region#", this._selRegionsObj.map(reg => reg.text).toString());
      emailBody = emailBody.replace("#DocumentType#", this._selDocTypeObj.map(docType => docType.text).toString());
      emailBody = emailBody.replace("#TherapeuticArea#", this._selTAObj.map(ta => ta.text).toString());
      emailBody = emailBody.replace("#RegulatoryTopic#", this._selRegTopicObj.map(regT => regT.text).toString());
      emailBody = emailBody.replace("#PublicationDate#", this.state.alertPubDate ? moment(this.state.alertPubDate).format('ddd, MMM DD, YYYY') : "");
      emailBody = emailBody.replace("#Author#", authorName);
      emailBody = emailBody.replace("#Title#", this.state.alertTitle);
      emailBody = emailBody.replace("#Impact#", this.state.alertImpact);
      emailBody = emailBody.replace("#AlertBody#", this.state.alertBody);

      this._sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody, AlertStatus.SubmitForReview);

    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _prepSubmitRItoTeamApprovalEmail');
    }
  }

  private async _prepUserEmail(emailTemplate: any[], aStatus: AlertStatus) {
    try {
      let emailFrom = '';
      let emailTo: any[] = [];
      let emailCc: any[] = [];
      let emailSub = emailTemplate[0]['ETSubject'];
      let emailBody = emailTemplate[0]['ETBody'];
      let gripLogo = Common.getConfigValue(this._configData, ConfigType.Email, ConfigKey.GRIPLogo);
      let emailBanner = Common.getConfigValue(this._configData, ConfigType.Email, ConfigKey.ImmediateEmailBanner);
      let footerLinks = Common.getConfigValue(this._configData, ConfigType.Email, ConfigKey.FooterLinks);
      let authorName: string = this._currUser['Title'];

      if (emailTemplate[0]["ETFrom"])
        emailFrom = emailTemplate[0]['ETFrom'].EMail;

      //To Emails
      if (emailTemplate[0]["ETTo"])
        emailTo = emailTemplate[0]["ETTo"].map(em => em.EMail);
      if (aStatus == AlertStatus.Submitted) {
        emailTo = emailTo.concat(this.state.admMems);
      }
      else {
        emailTo.push(this.state.RIAuthorEmail);
      }

      //Cc Emails
      if (emailTemplate[0]["ETCc"])
        emailCc = emailTemplate[0]["ETCc"].map(em => em.EMail);
      if (aStatus == AlertStatus.Submitted) {
        emailCc.push(this._currUser['Email']);
      }
      else {
        emailCc = emailCc.concat(this.state.admMems);
      }

      emailSub = emailSub.replace("#Title#", this.state.alertTitle);

      if (aStatus == AlertStatus.Submitted) {
        emailBody = emailBody.replace("#Requestor#", "Administrators");
      }
      else {
        emailBody = emailBody.replace("#Requestor#", this.state.RIAuthorTitle);
      }

      emailBody = emailBody.replace("#LinkToItem#", "<a href='" + this.props.webURL + this.state.viewPage + "#id=" + this._itemId + "'>View " + (this.state.isSubmittoRI ? "RI" : "Alert") + "</a>");
      emailBody = emailBody.replace("#Region#", this._selRegionsObj.map(reg => reg.text).toString());
      emailBody = emailBody.replace("#DocumentType#", this._selDocTypeObj.map(docType => docType.text).toString());
      emailBody = emailBody.replace("#TherapeuticArea#", this._selTAObj.map(ta => ta.text).toString());
      emailBody = emailBody.replace("#RegulatoryTopic#", this._selRegTopicObj.map(regT => regT.text).toString());
      emailBody = emailBody.replace("#Title#", this.state.alertTitle);
      emailBody = emailBody.replace("#Impact#", this.state.alertImpact);
      emailBody = emailBody.replace("#AlertBody#", this.state.alertBody);
      emailBody = emailBody.replace("#PublicationDate#", moment(this.state.alertPubDate).format('ddd, MMM DD, YYYY'));
      emailBody = emailBody.replace("#Author#", authorName);
      emailBody = emailBody.replace("#GRIPLogo#", '<img src="' + gripLogo + '" />');
      emailBody = emailBody.replace("#BannerImage#", '<img src="' + emailBanner + '" data-themekey="#" alt="" style="width: 100%; height: auto;"/>');
      emailBody = emailBody.replace("#FooterLinks#", footerLinks);
      emailBody = emailBody.replace("#ApprovedBy#", this._currUser["Title"]);
      emailBody = emailBody.replace("#RejectedBy#", this._currUser["Title"]);
      emailBody = emailBody.replace("#ReviewComments#", this.state.RejectComments);

      this._sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody, aStatus.toString());

    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _prepUserEmail');
    }
  }

  private async _prepImmediateEmail(emailTemplate: any[], subscriptions: any[], sendToMyself: boolean = false) {
    try {
      let arrEmailSentTo: any[] = [];
      let emailFrom = '';
      let emailTo: any[] = [];
      let emailCc: any[] = [];
      let emailSub = emailTemplate[0]['ETSubject'];
      let emailBody = emailTemplate[0]['ETBody'];
      let viewAlertPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ViewAlert);
      let gripLogo = Common.getConfigValue(this._configData, ConfigType.Email, ConfigKey.GRIPLogo);
      let emailBanner = Common.getConfigValue(this._configData, ConfigType.Email, ConfigKey.ImmediateEmailBanner);
      let footerLinks = Common.getConfigValue(this._configData, ConfigType.Email, ConfigKey.FooterLinks);
      let arrSubs: any[] = [];

      let authorName: string = this._currUser['Title'];
      if (emailTemplate[0]["ETFrom"])
        emailFrom = emailTemplate[0]['ETFrom'].EMail;
      if (emailTemplate[0]["ETCc"])
        emailCc = emailTemplate[0]["ETCc"].map(em => em.EMail);
      if (this._currUser['Id'] !== this.state.alertAuthorId) {
        authorName = this.state.alertAuthorTitle;
      }

      emailBody = emailBody.replace("#LinkToItem#", "<a href='" + this.props.webURL + viewAlertPage + "#" + encodeURIComponent("id=" + this._itemId) + "' style='color: #c50f3c;'>" + this.state.alertTitle + "</a>");
      emailBody = emailBody.replace("#Region#", this._selRegionsObj.map(reg => reg.text).toString());
      emailBody = emailBody.replace("#DocumentType#", this._selDocTypeObj.map(docType => docType.text).toString());
      emailBody = emailBody.replace("#TherapeuticArea#", this._selTAObj.map(ta => ta.text).toString());
      emailBody = emailBody.replace("#RegulatoryTopic#", this._selRegTopicObj.map(regT => regT.text).toString());
      emailBody = emailBody.replace("#PublicationDate#", moment(this.state.alertPubDate).format('ddd, MMM DD, YYYY'));
      emailBody = emailBody.replace("#Author#", authorName);
      emailBody = emailBody.replace("#Impact#", this.state.alertImpact);
      emailBody = emailBody.replace("#AlertBody#", this.state.alertBody);
      emailBody = emailBody.replace("#GRIPLogo#", '<img src="' + gripLogo + '" />');
      emailBody = emailBody.replace("#BannerImage#", '<img src="' + emailBanner + '" data-themekey="#" alt="" style="width: 100%; height: auto;"/>');
      emailBody = emailBody.replace("#FooterLinks#", footerLinks);

      //Send preview email
      if (sendToMyself) {
        emailSub = emailSub.replace("#Title#", this.state.alertTitle);
        emailTo.push(this._currUser["Email"]);
        emailBody = emailBody.replace("#Subscriber#", this._currUser["Title"]);
        this._sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody, "Email Preview");
      }
      // else {
      //   //send email with sprcific title to each user
      //   let totCnt: number = 0;
      //   for (let index = 0; index < subscriptions.length; index++) {
      //     const subs = subscriptions[index];

      //     if (!arrEmailSentTo.find(item => item == subs["ASSubscriber"][0].id)) {
      //       if (arrEmailSentTo.indexOf(subs["ASSubscriber"][0].id) < 0) {
      //         let bRegionMatch: boolean = false; let bTAMatch: boolean = false; let bRegTopicMatch: boolean = false;

      //         //Region matches
      //         if (subs.G2Region.length > 0)
      //           subs.G2Region.map(x => { if (this.state.selRegion.toString().indexOf(x.TermID) >= 0) bRegionMatch = true; });
      //         else
      //           bRegionMatch = true;
      //         //TA matches
      //         if (subs.G2TherapeuticArea.length > 0)
      //           subs.G2TherapeuticArea.map(x => { if (this.state.selTA.toString().indexOf(x.TermID) >= 0) bTAMatch = true; });
      //         else
      //           bTAMatch = true;
      //         //Reg Topic matches
      //         if (subs.G2RegulatoryTopic.length > 0)
      //           subs.G2RegulatoryTopic.map(x => { if (this.state.selRegTopic.toString().indexOf(x.TermID) >= 0) bRegTopicMatch = true; });
      //         else
      //           bRegTopicMatch = true;

      //         //If all 3 match, then send email
      //         if (bRegionMatch && bTAMatch && bRegTopicMatch) {
      //           let subEmailBody = emailBody;
      //           let subEmailSub = emailSub;
      //           emailTo = [];
      //           emailTo.push(subs["ASSubscriber"][0].email);
      //           subEmailSub = subEmailSub.replace("#Title#", this.state.alertTitle);
      //           subEmailBody = subEmailBody.replace("#Subscriber#", subs["ASSubscriber"][0].title);
      //           await this._sendImmediateEmail(emailFrom, emailTo, emailCc, subEmailSub, subEmailBody, AlertStatus.Publish)
      //             .then(result => {
      //               if (result) {
      //                 arrEmailSentTo.push(subs["ASSubscriber"][0].id);
      //                 arrSubs.push(subs["ID"]);
      //                 totCnt++;
      //                 this.setState({ loadingText: ('Alert email sent to ' + totCnt + ' user subscriptions') });
      //               }
      //             });
      //         }
      //       }
      //     }
      //   }
      //   this.updateUserAlertLog(arrEmailSentTo, arrSubs);
      // }
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _prepImmediateEmail');
      this.setState({ hideLoadingDialog: true });
    }
  }

  private updateUserAlertLog = (users: any[], subs: any[]): void => {
    try {
      let userAlertsLog = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.UserAlertsLog);

      let data: any = {
        Id: this._userAlImmeItemId,
        ADBLStatus: 'Email Sent',
        ADBLUsers: users.toString(),
        ADBSSubscriptions: subs.toString()
      };
      ListService.UpdateListDataByID(userAlertsLog, this._userAlImmeItemId, data).then(resp => {
        if (resp) {
          LoggerService.auditLog("Updated User Alerts Log for - " + this._userAlImmeItemId, 'AddEditAlerts > updateUserAlertLog');
          this.props.onSetNotification({ 'type': NotificationType.success, 'message': `Immediate email has been sent successfully!` });
          if (!this.state.isSubmittoRI) {
            let manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageAlerts);
            window.location.href = this.props.webURL + manageAlertsPage;
          }
          else {
            let manageSubmitRItoTeamPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageSubmitRItoTeam);
            window.location.href = this.props.webURL + manageSubmitRItoTeamPage;
          }
        }
      }).catch(err => {
        LoggerService.errorLog(err, 'AddEditAlerts > updateUserAlertLog > UpdateListDataByID');
        this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
        this.setState({ hideLoadingDialog: true });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > updateUserAlertLog');
      this.setState({ hideLoadingDialog: true });
    }
  }

  private _sendEmail(emailFrom: string, emailTo: any[], emailCc: any[], emailSub: string, emailBody: string, type: string) {
    try {
      emailTo = emailTo.filter((x) => { return x !== undefined && x !== null; });
      emailCc = emailCc.filter((x) => { return x !== undefined && x !== null; });

      EmailService.sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody).then(result => {
        LoggerService.auditLog("Email sent for - " + type + ", ", 'AddEditAlerts > _sendEmail');

        let manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageAlerts);
        if (this.state.isSubmittoRI) {
          manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageSubmitRItoTeam);
        }

        if (type == AlertStatus.SubmitForReview)
          this.setState({ hideUnpubDialog: true }, () => window.location.href = this.props.webURL + manageAlertsPage);
        else if (type == AlertStatus.Rejected)
          this.setState({ hideLoadingDialog: true }, () => window.location.href = this.props.webURL + manageAlertsPage);
        else if (type == "Email Preview") {
          this.props.onSetNotification({ 'type': NotificationType.success, 'message': `Preview Email sent successfully!` });
          this.setState({ hideUnpubDialog: true });
        }
      }).catch(error => {
        LoggerService.errorLog(error, 'AddEditAlerts > _sendEmail > sendEmail');
        this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
      });
    } catch (error) {
      this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
      LoggerService.errorLog(error, 'AddEditAlerts > _sendEmail');
    }
  }

  private async _sendImmediateEmail(emailFrom: string, emailTo: any[], emailCc: any[], emailSub: string, emailBody: string, type: string): Promise<any> {
    try {
      //wait for completion
      return await EmailService.sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody)
        .then(result => {
          return true;
        })
        .catch(error => {
          LoggerService.errorLog(error, 'AddEditAlerts > _sendImmediateEmail > sendEmail');
          this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
          return false;
        });
    } catch (error) {
      this.props.onSetNotification({ 'type': NotificationType.error, 'message': Common.notificationErrMsg });
      LoggerService.errorLog(error, 'AddEditAlerts > _sendImmediateEmail');
    }
  }

  private _getPeoplePickerItems(items: any[]) {
    try {
      if (items.length > 0) {
        let authorId: number = items[0]['id'];
        this.setState({ alertAuthorId: authorId ? authorId : 0, alertAuthorTitle: items[0]["text"], alertAuthor: [items[0]["secondaryText"]] }, this._validate);
      } else {
        this.setState({ alertAuthorId: 0, alertAuthorTitle: "", alertAuthor: [] }, this._validate);
      }
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _getPeoplePickerItems');
    }
  }

  private closeDistributeDialog = (): void => {
    this.setState({ hideDistributeDiag: true });
  }

  private unPublishAlert = (): void => {
    try {
      let alertsDBListName = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsDatabase);
      let data: any = {
        Id: this._itemId,
        ADBStatus: AlertStatus.Unpublish
      };
      ListService.UpdateListDataByID(alertsDBListName, this._itemId, data).then(resp => {
        if (resp) {
          LoggerService.auditLog("Alert unpublished - " + this._itemId, 'AddEditAlerts > unPublishAlert');
          this._itemId = 0;
          this.setState({ hideUnpubDialog: true }, () => {
            let manageAlertsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageAlerts);
            window.location.href = this.props.webURL + manageAlertsPage;
          });
        }
      }).catch(err => {
        LoggerService.errorLog(err, 'AddEditAlerts > unPublishAlert > UpdateListDataByID');
        this.setState({ hideUnpubDialog: true });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > unPublishAlert');
      this.setState({ hideUnpubDialog: true });
    }
  }

  private _onSendToMyselfClick = (): void => {
    try {
      let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);
      Common.getEmailTemplate(emailTmplList, 'SendToMyself').then(tmplResp => {
        if (tmplResp)
          this._prepImmediateEmail(tmplResp, [], true);
      })
        .catch(err => {
          LoggerService.errorLog(err, 'AddEditAlerts > _onSendToMyselfClick > getEmailTemplate');
        });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _onSendToMyselfClick');
    }
  }

  private isEarlierThanEndLimit(timeValue, endLimit, lastValue) {
    var timeValueIsEarlier = moment(timeValue, 'h:mmA').diff(moment(endLimit, 'h:mmA')) < 0;
    var timeValueIsLaterThanLastValue = lastValue === undefined ? true : moment(lastValue, 'h:mmA').diff(moment(timeValue, 'h:mmA')) < 0;
    return timeValueIsEarlier && timeValueIsLaterThanLastValue;
  }

  private uploadDoc(editor) {
    try {
      this.setState({ hideUploadDialog: false });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > uploadDoc');
    }
  }

  private _onUploadClick() {
    try {
      this.setState({ hideLoadingDialog: false }, () => {
        let uniqueFile = this._uploadedFile[0].name.substr(0, this._uploadedFile[0].name.lastIndexOf('.')) + "-" +
          new Date().getTime() + this._uploadedFile[0].name.substr(this._uploadedFile[0].name.lastIndexOf('.'));
        let yrFolder: string = new Date().getFullYear().toString();
        ListService.AddFile(`${this.props.context.pageContext.web.serverRelativeUrl}/${this._docUploadPath}/${yrFolder}`,
          uniqueFile, this._uploadedFile[0], true)
          .then(result => {
            //success();
            let alBody = this.state.alertBody + "<a href='" + this.props.webURL + "/" + this._docUploadPath + "/" + yrFolder + "/" +
              result.data["Name"] + "'>" + this._uploadedFile[0].name + "</a>";
            this.setState({ alertBody: alBody, hideUploadDialog: true, hideLoadingDialog: true, showUploadMsg: "", disableUploadButton: true });
          })
          .catch((e) => {
            this.setState({ hideLoadingDialog: true, showUploadMsg: 'Unable to upload file!', disableUploadButton: true });
          });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > _onUploadClick');
      this.setState({ hideLoadingDialog: true, showUploadMsg: "Something went wrong. Please contact administrator!", disableUploadButton: true });
    }
  }

  private validateFileName(file: any) {
    try {
      var pattern = /[/\\*:?#<>|"%&{}]/;
      let specialChar = pattern.test(file[0].name);
      if (specialChar)
        this.setState({
          showUploadMsg: 'A file name cannot contain any of the following caracters / \ * : ? # < > | " % & { }',
          disableUploadButton: true
        });
      else {
        this._uploadedFile = file;
        this.setState({ showUploadMsg: "", disableUploadButton: false });
      }
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > validateFileName');
    }
  }
}
