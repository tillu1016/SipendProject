declare interface IAddEditAlertsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  ListFieldLabel: string;
}

declare module 'AddEditAlertsWebPartStrings' {
  const strings: IAddEditAlertsWebPartStrings;
  export = strings;
}
