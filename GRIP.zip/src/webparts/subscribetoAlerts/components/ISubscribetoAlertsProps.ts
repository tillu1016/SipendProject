import { WebPartContext } from '@microsoft/sp-webpart-base';
import { sp } from "@pnp/sp";
import { INotification } from "../../../models/INotification";

export interface ISubscribetoAlertsProps {
  description: string;
  context: WebPartContext;
  webURL: string;
  onSetNotification: (notification: INotification) => void;
}
