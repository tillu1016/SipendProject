/* tslint:disable */
require("./SubscribetoAlerts.module.css");
const styles = {
  subscribetoAlerts: 'subscribetoAlerts_64c0d65f',
  container: 'container_64c0d65f',
  row: 'row_64c0d65f',
  column: 'column_64c0d65f',
  'ms-Grid': 'ms-Grid_64c0d65f',
  title: 'title_64c0d65f',
  subTitle: 'subTitle_64c0d65f',
  description: 'description_64c0d65f',
  button: 'button_64c0d65f',
  label: 'label_64c0d65f'
};

export default styles;
/* tslint:enable */