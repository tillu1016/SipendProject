import * as React from 'react';
import styles from './SubscribetoAlerts.module.scss';
import { ISubscribetoAlertsProps } from './ISubscribetoAlertsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { ListService } from '../../../services/ListService';
import {
  Stack, Dropdown, TextField, SearchBox, DetailsList, IColumn, DetailsListLayoutMode, DefaultButton, Dialog, DialogType,
  SpinButton, ComboBox, DialogFooter, PrimaryButton, Link, SelectionMode, TooltipHost, IconButton, IIconProps, Label, IStackItemStyles, ShimmeredDetailsList, ActionButton, MessageBar, MessageBarType
} from '@fluentui/react';
import { ConfigType, IConfiguration, ConfigKey } from '../../../models/IConfiguration';
import { Common } from '../../../common/common';
import { CurrentUser } from '@pnp/sp/src/siteusers';
import { LoggerService } from "../../../services/LoggerService";
import { ISubscription } from '../../../models/ISubscription';
import { EmailService } from '../../../services/EmailService';
import { NotificationType } from "../../../models/INotification";

const stackItemStyles: IStackItemStyles = {
  root: {
    padding: 5
  }
};

export interface ISubscribetoAlertsState {
  alertRegionOptions: any[];
  hideAll: boolean;
  disableSignUpButton: boolean;
  hideSignUpDialog: boolean;
  isUserAdmin: boolean;
  isUserSubscribed: boolean;
  toolTipMessage: string;
  toolTipManageSubMessage: string;
  showErrorMessage: boolean;
}

export default class SubscribetoAlerts extends React.Component<ISubscribetoAlertsProps, ISubscribetoAlertsState> {
  private _configData: IConfiguration[] = [];
  private _currUser: CurrentUser;
  private _manageSubscriptionsURL: string = "";
  private _metricsAndDBURL: string = "";
  private _itemId: number = 0;
  private _title: string = "GRIP 2.0 - Subscribe to All Alerts";
  private _disableSignUpButton: boolean = false;

  constructor(props) {
    super(props);
    this.state = {
      alertRegionOptions: [],
      hideAll: true,
      disableSignUpButton: false,
      hideSignUpDialog: true,
      isUserAdmin: false,
      isUserSubscribed: false,
      toolTipMessage: 'Are you sure: by selecting this option, you are subscribing to all G.R.I.P. alerts that are uploaded into the system.',
      toolTipManageSubMessage: 'Manage your G.R.I.P alert(s) subscriptions.',
      showErrorMessage: false
    };
  }

  public componentDidMount() {
    try {
      Common.getConfigData().then(async resp => {
        if (resp) {
          this._configData = resp;
          Common.errorLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ErrorLog);
          Common.auditLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AuditLog);
          let adminGrpName: string = Common.getConfigValue(this._configData, ConfigType.Roles, ConfigKey.Administrator);

          this.getSubscriptionsData();

          Common.checkIfUserAdmin(adminGrpName).then(isUsrAdm => {
            this.setState({ isUserAdmin: isUsrAdm }, () => {
              if (isUsrAdm) {
                this.setState({ isUserAdmin: true });
              }
            });
          });
        }
      });

      Common.getCurrentUserId().then((curUser: CurrentUser) => {
        this._currUser = curUser;
      });
    } catch (error) {
      LoggerService.errorLog(error, 'Subscribe to All Alerts > componentDidMount');
    }
  }

  public render(): React.ReactElement<ISubscribetoAlertsProps> {
    this._manageSubscriptionsURL = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageSubscriptions);
    this._manageSubscriptionsURL = this.props.webURL + this._manageSubscriptionsURL;
    this._metricsAndDBURL = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.MetricsAndDashboard);
    this._metricsAndDBURL = this.props.webURL + this._metricsAndDBURL;

    return (
      <div className={styles.subscribetoAlerts}>
        {
          this.state.hideAll ?
            null :
            <Stack>
              <Stack.Item>
                {!this.state.isUserSubscribed ?
                  <div className="subscription_metrics">
                    <TooltipHost
                      content={this.state.toolTipMessage}
                      id={"titleTooltip_" + this._itemId}
                      calloutProps={{ gapSpace: 0 }}
                      styles={{ root: { display: 'inline-block' } }}
                    >
                      <div className="subscribe_tile" onClick={this.onSignUpClick.bind(this)}>
                        <IconButton iconProps={{ iconName: "Ringer" }} className="tile_icon" />
                        <span>Subscribe to All Alerts</span>
                      </div>
                    </TooltipHost>
                  </div>
                  :
                  <div className="subscription_metrics">
                    <TooltipHost
                      content={this.state.toolTipManageSubMessage}
                      id={"titleTooltip_" + this._itemId}
                      calloutProps={{ gapSpace: 0 }}
                      styles={{ root: { display: 'inline-block' } }}
                    >
                      <div className="subscribe_tile" onClick={this.onManageSubscriptionClick.bind(this)}>
                        <IconButton iconProps={{ iconName: "Subscribe" }} className="tile_icon" />
                        <span>Manage Subscriptions</span>
                      </div>
                    </TooltipHost>
                  </div>
                }
                {this.state.isUserAdmin ?
                  <div className="subscription_metrics">
                    <div className="subscribe_tile" onClick={this.onMetricsAndDBClick.bind(this)}>
                      <IconButton iconProps={{ iconName: "PieDouble" }} className="tile_icon" />
                      <span>Metrics & Dashboard</span>
                    </div>
                  </div> : null}
              </Stack.Item>
              <Stack.Item>
                <Dialog
                  hidden={this.state.hideSignUpDialog}
                  onDismiss={this.closeDialog.bind(this)}
                  dialogContentProps={{
                    type: DialogType.normal,
                    title: 'Thank you!'
                  }}
                  modalProps={{
                    isBlocking: true,
                    containerClassName: 'ms-dialogMainOverride'
                  }}
                >
                  <div>You have successfully subscribed to all G.R.I.P alerts</div>

                  <DialogFooter>
                    <DefaultButton onClick={this.closeDialog.bind(this)} text="Close" />
                  </DialogFooter>
                </Dialog>
              </Stack.Item>

            </Stack>
        }
      </div>
    );
  }

  private onSignUpClick() {
    if (!this._disableSignUpButton) {
      this._disableSignUpButton = true;
      LoggerService.auditLog("Home Page > Clicked on sign up for alerts", 'SubscribetoAlerts > onSignUpClick');
      this.setState({ disableSignUpButton: this._disableSignUpButton }, () => this.submitPanelSignUp());
    }
  }

  private onManageSubscriptionClick() {
    LoggerService.auditLog("Home Page > Clicked on Manage Subscription", 'SubscribetoAlerts > onManageSubscriptionClick');
    window.location.href = this._manageSubscriptionsURL;
  }

  private onMetricsAndDBClick() {
    LoggerService.auditLog("Home Page > Clicked on Metrics And Dashboard", 'SubscribetoAlerts > onMetricsAndDBClick');
    window.location.href = this._metricsAndDBURL;
  }


  private closeDialog() {
    LoggerService.auditLog("Clicked on signup for alerts cancel", 'SubscribetoAlerts > closeDialog');
    this.setState({ hideSignUpDialog: true });
  }

  private async getSubscriptionsData() {
    try {
      let cmlQuery: string = "<View><Query>";
      if (!this.state.isUserAdmin) {
        cmlQuery += `<Where><Eq><FieldRef Name='ASSubscriber' LookupId='True'/><Value Type='User'>${this._currUser["Id"]}</Value></Eq></Where>`;
      }

      cmlQuery += "<OrderBy><FieldRef Name='ID' Ascending='False' /></OrderBy></Query>";
      cmlQuery += "<ViewFields><FieldRef Name='ID' /><FieldRef Name='Title' /></ViewFields>";
      cmlQuery += "<RowLimit>1</RowLimit>";
      cmlQuery += "<ExpandUserField>True</ExpandUserField></View>";
      let ColExpand = "FieldValuesAsText";
      await ListService.GetDataByCAMLColExpand(ConfigKey.Subscriptions, cmlQuery, ColExpand).then(response => {
        if (response && response.length > 0) {
          this.setState({ isUserSubscribed: true, hideAll: false });
        }
        else if (response && response.length == 0) {
          Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.Region).then(regions => {
            this.setState({ alertRegionOptions: regions, hideAll: false });
          });
        }
      }).catch(error => {
        console.log(error);
      });
    } catch (error) {
      console.log(error);
    }
  }

  private submitPanelSignUp() {
    try {
      let subscriptionListName = this._configData.filter((item) => {
        return item.title == ConfigType.Lists && item.key == ConfigKey.Subscriptions;
      })[0].value;

      let tmpRegions: string = '';
      if (this.state.alertRegionOptions) {
        this.state.alertRegionOptions.forEach(region => {
          if (tmpRegions == '')
            tmpRegions = `-1;#${region.text}|${region.key}`;
          else
            tmpRegions += `;#-1;#${region.text}|${region.key}`;
        });
      }

      let tmpObj: any = {
        Id: this._itemId,
        Title: this._title,
        G2RegionTaxHTField: tmpRegions,
        ASFrequency: "Immediate",
        ASSubscriberId: this._currUser["Id"]
      };

      return new Promise<boolean>((resolve, reject) => {
        ListService.PostListData(tmpObj, subscriptionListName)
          .then(result => {
            this._itemId = result.data.Id;
            this.setState({ isUserSubscribed: true });
            this.setState({ hideSignUpDialog: false });

            // Send Email
            let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);

            Common.getEmailTemplate(emailTmplList, 'UserSubscribetoAllAlerts').then(async tmplResp => {
              if (tmplResp) {
                await this._prepUserSubscriptionEmail(tmplResp);
                this.props.onSetNotification({ 'type': NotificationType.success, 'message': `Subscribed to alerts successfully!` });
              }
            });
            resolve(true);
          })
          .catch(exception => {
            LoggerService.errorLog(exception, 'SubscribetoAlerts > submitPanelSignUp > PostListData');
            reject(exception);
          });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'SubscribetoAlerts > submitPanelSignUp');
    }
  }

  private async _prepUserSubscriptionEmail(emailTemplate: any[]) {
    try {
      let emailFrom = '';
      let emailTo: any[] = [];
      let emailCc: any[] = [];
      let emailSub = emailTemplate[0]['ETSubject'];
      let emailBody = emailTemplate[0]['ETBody'];
      //let admMems: string[] = [];

      emailTo.push(this._currUser["Email"]);

      let manageSubscriptionsPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ManageSubscriptions);

      if (emailTemplate[0]["ETFrom"])
        emailFrom = emailTemplate[0]['ETFrom'].EMail;

      if (emailTemplate[0]["ETTo"])
        emailTo = emailTo.concat(emailTo, emailTemplate[0]["ETTo"].map(em => em.EMail));


      //Cc Emails
      if (emailTemplate[0]["ETCc"])
        emailCc = emailCc.concat(emailCc, emailTemplate[0]["ETCc"].map(em => em.EMail));


      emailBody = emailBody.replace("#Subscriber#", this._currUser["Title"]);
      emailBody = emailBody.replace("#LinkToItem#", "<a href='" + this.props.webURL + manageSubscriptionsPage + "'>Manage Subscriptions</a>");
      emailBody = emailBody.replace("#Title#", this._title);

      this._sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody);

    } catch (error) {
      LoggerService.errorLog(error, 'SubscribetoAlerts > _prepUserSubscriptionEmail');
    }
  }

  private _sendEmail(emailFrom: string, emailTo: any[], emailCc: any[], emailSub: string, emailBody: string) {
    try {
      EmailService.sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody).then(result => {
        LoggerService.auditLog("Email sent for - " + emailTo.join(","), 'SubscribetoAlerts > _sendEmail');
      }).catch(error => {
        LoggerService.errorLog(error, 'SubscribetoAlerts > _sendEmail > sendEmail');
      });
    } catch (error) {
      LoggerService.errorLog(error, 'SubscribetoAlerts > _sendEmail');
    }
  }

}            
