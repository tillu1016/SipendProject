declare interface ISubscribetoAlertsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SubscribetoAlertsWebPartStrings' {
  const strings: ISubscribetoAlertsWebPartStrings;
  export = strings;
}
