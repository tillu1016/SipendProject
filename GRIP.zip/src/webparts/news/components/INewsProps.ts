import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface INewsProps {
  context: WebPartContext;
  webURL: string;
}
