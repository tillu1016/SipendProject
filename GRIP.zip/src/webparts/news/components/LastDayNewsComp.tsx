import * as React from 'react';
import { ListService } from '../../../services/ListService';
import { IAlert, AlertStatus } from '../../../models/IAlert';
import { Component } from 'react';
import { Common } from '../../../common/common';
import { ConfigType, ConfigKey } from '../../../models/IConfiguration';
import { Shimmer, ShimmerElementType, PrimaryButton, Link, IIconProps, IContextualMenuProps, IconButton, TooltipHost, Dialog, DialogType, DialogFooter, DefaultButton, ShimmerElementsGroup, } from '@fluentui/react';
import { UserProfileQuery } from '@pnp/sp';
import { LoggerService } from '../../../services/LoggerService';
import { CurrentUser } from '@pnp/sp/src/siteusers';
import { PageName } from '../../../models/IAlertAnalytics';
import { WebPartContext } from "@microsoft/sp-webpart-base";

interface LastDayNewsCompState {
    isDataLoaded: boolean;
    todaysAlerts: any;
    isUserAdmin: boolean;
    hideUnpubDialog: boolean;
    alertRegion: any[];
    alertTA: any[]; isEmpty: boolean;
    currentUser: CurrentUser;
    configData: any[];
    regTADataLoaded: boolean;
}

interface LastDayNewsCompProps {
    webURL: string;
    context: WebPartContext;
    alertRegion: any[];
    alertTA: any[];
    isUserAdmin: boolean;
    currentUser: CurrentUser;
    configData: any[];
    updateData: (type: string, data: any) => void;
    todaysAlerts: any;
    regTADataLoaded: boolean;
}

const getNewsElementShimmer = (): JSX.Element => {
    return (
        <div>
            <ShimmerElementsGroup
                flexWrap
                shimmerElements={[
                    { type: ShimmerElementType.line, width: 500, height: 8 },
                    { type: ShimmerElementType.gap, width: 500, height: 10 },
                    { type: ShimmerElementType.line, width: 500, height: 8 },
                ]}
            />
            <ShimmerElementsGroup
                flexWrap
                shimmerElements={[
                    { type: ShimmerElementType.gap, width: 500, height: 21 },
                ]}
            />
            <ShimmerElementsGroup
                flexWrap
                shimmerElements={[
                    { type: ShimmerElementType.line, width: 500, height: 8 },
                    { type: ShimmerElementType.gap, width: 500, height: 5 },
                    { type: ShimmerElementType.line, width: 500, height: 8 },
                ]}
            />
            <ShimmerElementsGroup
                flexWrap
                shimmerElements={[
                    { type: ShimmerElementType.gap, width: 500, height: 5 },
                    { type: ShimmerElementType.circle, height: 25 },
                    { type: ShimmerElementType.gap, width: 10, height: 30 },
                ]}
            />
            <ShimmerElementsGroup
                flexWrap
                shimmerElements={[
                    { type: ShimmerElementType.gap, width: 500, height: 10 },
                    { type: ShimmerElementType.circle, height: 25 },
                    { type: ShimmerElementType.gap, width: 10, height: 30 },
                ]}
            />
            <ShimmerElementsGroup
                flexWrap
                shimmerElements={[
                    { type: ShimmerElementType.gap, width: 500, height: 10 },
                    { type: ShimmerElementType.circle, height: 25 },
                    { type: ShimmerElementType.gap, width: 10, height: 30 },
                ]}
            />
        </div>
    );
};

export default class LastDayNewsComp extends React.Component<LastDayNewsCompProps, LastDayNewsCompState>{
    private _itemId: number = 0;

    constructor(props) {
        super(props);
        this.state = {
            isDataLoaded: false,
            todaysAlerts: this.props.todaysAlerts,
            isUserAdmin: this.props.isUserAdmin,
            hideUnpubDialog: true,
            alertRegion: this.props.alertRegion,
            alertTA: this.props.alertTA,
            isEmpty: false,
            currentUser: this.props.currentUser,
            configData: this.props.configData,
            regTADataLoaded: this.props.regTADataLoaded
        };
    }

    public componentDidMount() {
        try {
            if (this.state.configData.length > 0) {
                if (this.state.todaysAlerts.length == 0 && this.state.regTADataLoaded) {
                    this.getLastDayAlerts(false);
                }
                else {
                    this.setState({ isDataLoaded: true });
                }
            }             
        } catch (error) {
            LoggerService.errorLog(error, 'LastDayNewsComp > componentDidMount');
        }
    }

    public componentDidUpdate(prevProps: LastDayNewsCompProps) {
        if (this.state.configData != prevProps.configData && this.state.regTADataLoaded != prevProps.regTADataLoaded) {
            this.setState({ configData: prevProps.configData, regTADataLoaded: prevProps.regTADataLoaded }, () => {
                this.getLastDayAlerts(false);
            });
        }       
        if (this.state.alertRegion != prevProps.alertRegion) {
            this.setState({ alertRegion: prevProps.alertRegion });
        }
        if (this.state.alertTA != prevProps.alertTA) {
            this.setState({ alertTA: prevProps.alertTA });
        }
        if (this.state.isUserAdmin != prevProps.isUserAdmin) {
            this.setState({ isUserAdmin: prevProps.isUserAdmin });
        }
        if (this.state.currentUser != prevProps.currentUser) {
            this.setState({ currentUser: prevProps.currentUser });
        }
    }

    public render(): JSX.Element {
        let viewAlPage = Common.getConfigValue(this.state.configData, ConfigType.Page, ConfigKey.ViewAlert);
        return (
            <div>
                {this.state.isDataLoaded ? null :
                    <div className="news_container">
                        <div className="news_box extraPad"><Shimmer customElementsGroup={getNewsElementShimmer()} /></div>
                        <div className="news_box extraPad"><Shimmer customElementsGroup={getNewsElementShimmer()} /></div>
                        <div className="news_box extraPad"><Shimmer customElementsGroup={getNewsElementShimmer()} /></div>
                        <div className="news_box extraPad"><Shimmer customElementsGroup={getNewsElementShimmer()} /></div>
                    </div>}
                {this.state.isEmpty ?
                    <div className="news_container">
                        <div className="empty_box emptyAlert">
                            <h1>No Alerts for last day</h1>
                        </div></div> : null}
                <div className="news_container">
                    {this.state.todaysAlerts.length > 0 ? this.state.todaysAlerts.map(item =>
                        <div className="news_box">
                            <TooltipHost
                                content={item.title}
                                id={"titleTooltip_" + item.id}
                                calloutProps={{ gapSpace: 0 }}
                                styles={{ root: { display: 'inline-block' } }}
                            >
                                {Common.isIE ?
                                    <p className="title_txtIE"><Link aria-describedby={"titleTooltip_" + item.id}
                                        href={this.props.webURL + viewAlPage + '#id=' + item.id}>
                                        {item.title.length > 80 ? item.title.substring(0, 80) + '...' : item.title}
                                    </Link></p> :
                                    <p className="title_txt"><Link aria-describedby={"titleTooltip_" + item.id}
                                        href={this.props.webURL + viewAlPage + '#id=' + item.id}>{item.title}</Link></p>}
                            </TooltipHost>
                            {Common.isIE ?
                                <p className="red_txtIE">​Impact: {item.impact.length > 70 ? item.impact.substring(0, 70) + '...' : item.impact}</p> :
                                <p className="red_txt">​Impact: {item.impact}</p>}
                            {item.region.indexOf(',') >= 0 ?
                                <p className="img_details">
                                    <img src={this.getIcon(ConfigKey.Region, item.region)} />
                                    <img className="globe_icon" src={this.props.webURL + "/SiteAssets/Images/Region/world_icon2.png"} />
                                    {Common.isIE ?
                                        <span>{item.region.length > 70 ? item.region.substring(0, 70) + '...' : item.region}</span> :
                                        <span>{item.region}</span>}
                                </p> :
                                <p className="img_details"><img src={this.getIcon(ConfigKey.Region, item.region)} /><span>{item.region}</span></p>
                            }
                            {item.therapeuticArea.indexOf(',') >= 0 ?
                                <p className="img_details">
                                    <img src={this.getIcon(ConfigKey.TherapeuticArea, item.therapeuticArea)} />
                                    <img className="globe_icon" src={this.props.webURL + "/SiteAssets/Images/TherapeuticArea/all_therapeutic_areas.png"} />
                                    {Common.isIE ?
                                        <span>{item.therapeuticArea.length > 70 ? item.therapeuticArea.substring(0, 70) + '...' : item.therapeuticArea}</span> :
                                        <span>{item.therapeuticArea}</span>}
                                </p> :
                                <p className="img_details"><img src={this.getIcon(ConfigKey.TherapeuticArea, item.therapeuticArea)} />
                                    <span> {item.therapeuticArea}</span></p>
                            }
                            <p className="auth_details">
                                {item.authorPic ?
                                    <span className="profile_image">
                                        {Common.isIE ? <img src={item.authorPic.substring(0, item.authorPic.indexOf('?'))} /> :
                                            <img src={item.authorPic} />}
                                    </span>
                                    :
                                    <span className="profile_image">
                                        <img src={this.props.webURL + '/SiteAssets/Images/BlankPerson.jpg'} />
                                    </span>
                                }
                                {item.author}<span>{item.publicationDate}</span>
                                {this.state.isUserAdmin ?
                                    <IconButton className="v_ellipsis"
                                        menuProps={
                                            {
                                                items: [
                                                    {
                                                        key: 'edit',
                                                        text: 'Edit',
                                                        iconProps: { iconName: 'EditNote' },
                                                        onClick: () => { this.onMenuClick('Edit', item.id); }
                                                    },
                                                    {
                                                        key: 'unpublish',
                                                        text: 'Unpublish',
                                                        iconProps: { iconName: 'UnpublishContent' },
                                                        onClick: () => { this.onMenuClick('Unpublish', item.id); }
                                                    },
                                                ]
                                            }}
                                        title="More"
                                        ariaLabel="More"
                                        menuIconProps={{ iconName: "MoreVertical" }}
                                    /> : null}
                            </p>
                        </div>
                    ) : null
                    }
                    <div className="viewMore">
                        <PrimaryButton onClick={this.onViewMoreClick.bind(this)} text="View More" />
                    </div>
                </div>
                <Dialog
                    hidden={this.state.hideUnpubDialog}
                    onDismiss={this.closeUnpubDialog.bind(this)}
                    dialogContentProps={{
                        type: DialogType.normal,
                        title: 'Unpublish Alert',
                        subText: "Do you want to unpublish this alert?"
                    }}
                    modalProps={{
                        isBlocking: true,
                        containerClassName: 'ms-dialogMainOverride'
                    }}
                >
                    <DialogFooter>
                        <PrimaryButton onClick={this.unpublishAlert.bind(this)} text="Confirm" />
                        <DefaultButton onClick={this.closeUnpubDialog.bind(this)} text="Cancel" />
                    </DialogFooter>
                </Dialog>
            </div>
        );
    }

    private getLastDayAlerts = (isEmpty: boolean): void => {
        try {
            let alertsDBListName = Common.getConfigValue(this.state.configData, ConfigType.Lists, ConfigKey.AlertsDatabase);
            let lastDay = new Date(new Date().getTime() - (1 * 24 * 60 * 60 * 1000));
            let lastDayStartStr = lastDay.getFullYear() + '-' + (lastDay.getMonth() + 1) + '-' + lastDay.getDate();
            let lastDayEndStr = new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + new Date().getDate();
            //lastDayStartStr += 'T00%3a00%3a00';
            //lastDayEndStr += 'T11%3a59%3a59';

            let camlQ: string = `<View>
            <Query>`;
            if (isEmpty) {
                camlQ += `<Where><Eq><FieldRef Name='ADBStatus'/><Value Type='Text'>${AlertStatus.Publish}</Value></Eq></Where>`;
            }
            else {
                camlQ += `<Where>
                                <And>
                                    <And>
                                        <Geq>
                                            <FieldRef Name='ADBPublicationDate' />
                                            <Value Type='Text'>${lastDayStartStr}</Value>
                                        </Geq>
                                        <Lt>
                                            <FieldRef Name='ADBPublicationDate' />
                                            <Value Type='Text'>${lastDayEndStr}</Value>
                                        </Lt>
                                    </And>
                                    <Eq><FieldRef Name='ADBStatus'/><Value Type='Text'>${AlertStatus.Publish}</Value></Eq>
                                </And>
                        </Where>`;
            }
            camlQ += `<OrderBy><FieldRef Name='ADBPublicationDate' Ascending='False' /></OrderBy>
            </Query>
            <ViewFields><FieldRef Name='ID'/><FieldRef Name='ADBImpact'/><FieldRef Name='ADBPublicationDate'/><FieldRef Name='G2Region'/>
            <FieldRef Name='G2TherapeuticArea'/>
            <FieldRef Name='ADBAuthor'/><FieldRef Name='Title'/></ViewFields>
            <RowLimit Paged="TRUE">4</RowLimit>
            <ExpandUserField>True</ExpandUserField>
            </View>`;
            ListService.getDataFromLargeList(alertsDBListName, camlQ).then(data => {
                if (data) {
                    if (data.Row.length > 0) {
                        let todaysAlerts: any = [];
                        data.Row.map(alertItem => {
                            todaysAlerts.push({
                                id: alertItem['ID'],
                                title: alertItem['Title'],
                                impact: alertItem["ADBImpact"],
                                publicationDate: new Date(alertItem["ADBPublicationDate"]).toDateString(),
                                region: Common.getManagedMetadataString(alertItem["G2Region"]),
                                therapeuticArea: Common.getManagedMetadataString(alertItem["G2TherapeuticArea"]),
                                author: alertItem["ADBAuthor"][0]["title"],
                                authorPic: alertItem["ADBAuthor"][0]["picture"] ? alertItem["ADBAuthor"][0]["picture"].replace(":443", '') : ''
                            });
                        });
                        this.setState({ todaysAlerts: [...todaysAlerts], isDataLoaded: true }, () => {
                            this.props.updateData("lastday", todaysAlerts);
                        });
                    } else
                        if (isEmpty)
                            this.setState({ isEmpty: true, isDataLoaded: true });
                        else
                            this.getLastDayAlerts(true);
                } else
                    if (isEmpty)
                        this.setState({ isEmpty: true, isDataLoaded: true });
                    else
                        this.getLastDayAlerts(true);
            })
                .catch(error => {
                    LoggerService.errorLog(error, 'LastDayNewsComp > getLastDayAlerts > getDataFromLargeList');
                });
        } catch (error) {
            LoggerService.errorLog(error, 'LastDayNewsComp > getLastDayAlerts');
        }
    }

    private onViewMoreClick = (): void => {
        try {
            LoggerService.auditLog("Clicked on View More", 'LastDayNewsComp > onViewMoreClick');
            let viewAlertsPage = Common.getConfigValue(this.state.configData, ConfigType.Page, ConfigKey.ManageAlerts);
            window.location.href = this.props.webURL + viewAlertsPage;
        } catch (error) {
            LoggerService.errorLog(error, 'LastDayNewsComp > onViewMoreClick');
        }
    }

    private onMenuClick(type: string, itemId: number) {
        try {
            switch (type) {
                case 'Edit':
                    LoggerService.auditLog("Clicked on Edit Alert - " + itemId, 'LastDayNewsComp > onMenuClick');
                    let editAlertsPage = Common.getConfigValue(this.state.configData, ConfigType.Page, ConfigKey.AddEditAlerts);
                    window.location.href = this.props.webURL + editAlertsPage + '#id=' + itemId;
                    break;
                case 'Unpublish':
                    LoggerService.auditLog("Clicked on Unpublish Alert - " + itemId, 'LastDayNewsComp > onMenuClick');
                    this._itemId = itemId;
                    this.setState({ hideUnpubDialog: false });
                    break;
                default:
                    break;
            }
        } catch (error) {
            LoggerService.errorLog(error, 'LastDayNewsComp > onMenuClick');
        }
    }

    private unpublishAlert = (): void => {
        try {
            let alertsDBListName = Common.getConfigValue(this.state.configData, ConfigType.Lists, ConfigKey.AlertsDatabase);

            let data: any = {
                Id: this._itemId,
                ADBStatus: AlertStatus.Unpublish
            };
            ListService.UpdateListDataByID(alertsDBListName, this._itemId, data).then(resp => {
                if (resp) {
                    LoggerService.auditLog("Alert Unpublished - " + this._itemId, 'LastDayNewsComp > unpublishAlert');
                    this._itemId = 0;
                    this.setState({ hideUnpubDialog: true }, () => this.getLastDayAlerts(false));
                }
            }).catch(err => {
                LoggerService.errorLog(err, 'LastDayNewsComp > unpublishAlert > UpdateListDataByID');
                this.setState({ hideUnpubDialog: true });
            });
        } catch (error) {
            LoggerService.errorLog(error, 'LastDayNewsComp > unpublishAlert');
            this.setState({ hideUnpubDialog: true });
        }
    }

    private closeUnpubDialog() {
        LoggerService.auditLog("Alert Unpublish cancelled - " + this._itemId, 'LastDayNewsComp > closeUnpubDialog');
        this._itemId = 0;
        this.setState({ hideUnpubDialog: true });
    }

    private getIcon = (category: string, catValue: string): string => {
        try {
            let retVal = '';
            switch (category) {
                case ConfigKey.Region:
                    let regionPath = Common.getConfigValue(this.state.configData, ConfigType.ImagePath, ConfigKey.Region);
                    let regTerm: any;
                    if (catValue.indexOf(',') >= 0) {
                        regTerm = this.state.alertRegion.filter(term => term.text.toLowerCase() == catValue.split(',')[0].toLowerCase());
                        retVal = this.props.webURL + regionPath + regTerm[0].imagePath;
                    } else {
                        regTerm = this.state.alertRegion.filter(term => term.text.toLowerCase() == catValue.toLowerCase());
                        retVal = this.props.webURL + regionPath + regTerm[0].imagePath;
                    }
                    break;
                case ConfigKey.TherapeuticArea:
                    let taTerm: any;
                    let taPath = Common.getConfigValue(this.state.configData, ConfigType.ImagePath, ConfigKey.TherapeuticArea);
                    if (catValue.indexOf(',') >= 0) {
                        taTerm = this.state.alertTA.filter(term => term.text.toLowerCase() == catValue.split(',')[0].toLowerCase());
                        retVal = this.props.webURL + taPath + taTerm[0].imagePath;
                    } else {
                        taTerm = this.state.alertTA.filter(term => term.text.toLowerCase() == catValue.toLowerCase());
                        retVal = this.props.webURL + taPath + taTerm[0].imagePath;
                    }
                    break;
                default:
                    break;
            }
            return retVal;
        } catch (error) {
            LoggerService.errorLog(error, 'LastDayNewsComp > getIcon');
        }
    }
}