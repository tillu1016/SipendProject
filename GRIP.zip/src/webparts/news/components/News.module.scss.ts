/* tslint:disable */
require("./News.module.css");
const styles = {
  news: 'news_9899aadf',
  container: 'container_9899aadf',
  row: 'row_9899aadf',
  column: 'column_9899aadf',
  'ms-Grid': 'ms-Grid_9899aadf',
  title: 'title_9899aadf',
  subTitle: 'subTitle_9899aadf',
  description: 'description_9899aadf',
  button: 'button_9899aadf',
  label: 'label_9899aadf'
};

export default styles;
/* tslint:enable */