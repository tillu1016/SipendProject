import * as React from 'react';
import styles from './News.module.scss';
import { INewsProps } from './INewsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { Stack, Pivot, PivotItem } from '@fluentui/react';
import LastDayNewsComp from './LastDayNewsComp';
import LastWeekNewsComp from './LastWeekNewsComp';
import { Common } from '../../../common/common';
import { ConfigType, ConfigKey } from '../../../models/IConfiguration';
import { CurrentUser } from '@pnp/sp/src/siteusers';
import { LoggerService } from '../../../services/LoggerService';
import { PageName } from '../../../models/IAlertAnalytics';

interface NewsCompState {
  isUserAdmin: boolean;
  alertRegion: any[];
  alertTA: any[];
  currentUser: CurrentUser;
  configData: any[];
  weeksAlerts: any;
  todaysAlerts: any;
  regTADataLoaded: boolean;
}

export default class News extends React.Component<INewsProps, NewsCompState> {
  constructor(props) {
    super(props);
    this.state = {
      isUserAdmin: false,
      alertRegion: [],
      alertTA: [],
      currentUser: null,
      configData: [],
      weeksAlerts: [],
      todaysAlerts: [],
      regTADataLoaded: false
    };
  }

  public render(): React.ReactElement<INewsProps> {
    return (
      <div className={styles.news}>
        <Stack className="news_tab">
          <Stack.Item>
            <h1>News</h1>
            <Pivot>
              <PivotItem headerText='Last Day' itemKey='newsLastDay' >
                <LastDayNewsComp
                  context={this.props.context}
                  webURL={this.props.webURL}
                  alertRegion ={this.state.alertRegion}
                  alertTA={this.state.alertTA}
                  isUserAdmin={this.state.isUserAdmin}
                  currentUser={this.state.currentUser}
                  configData={this.state.configData}
                  updateData={this.updateData}
                  todaysAlerts={this.state.todaysAlerts}
                  regTADataLoaded={this.state.regTADataLoaded}
                >
                  </LastDayNewsComp>
              </PivotItem>
              <PivotItem headerText='Last Week' itemKey='newsLastWeek' >
                <LastWeekNewsComp
                  context={this.props.context}
                  webURL={this.props.webURL}
                  alertRegion ={this.state.alertRegion}
                  alertTA={this.state.alertTA}
                  isUserAdmin={this.state.isUserAdmin}
                  currentUser={this.state.currentUser}
                  configData={this.state.configData}
                  updateData={this.updateData}
                  weeksAlerts={this.state.weeksAlerts}
                  regTADataLoaded={this.state.regTADataLoaded}
                ></LastWeekNewsComp>
              </PivotItem>
            </Pivot>
          </Stack.Item>
        </Stack>
      </div>
    );
  }

  public componentDidMount() {
    try {
      Common.getConfigData().then(resp => {
        if (resp) {
          this.setState({ configData: resp }, () => {
            Common.errorLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ErrorLog);
            Common.auditLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AuditLog);
            let adminGrpName: string = Common.getConfigValue(resp, ConfigType.Roles, ConfigKey.Administrator);

            Common.getCurrentUserId().then((curUser: CurrentUser) => {
              this.setState({ currentUser: curUser }, () => {
                Common.checkIfUserAdmin(adminGrpName).then(isUsrAdm => {
                  this.setState({ isUserAdmin: isUsrAdm });
                  //log user visits          
                  let AlertAnalyticsList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AlertAnalytics);
                  Common.logSiteVisit(AlertAnalyticsList, PageName.Home, isUsrAdm, this.state.currentUser["Id"], null);
                });
              });
              this.getTaxonomyData();
            });
          });
        }
      });
    } catch (error) {
      LoggerService.errorLog(error, 'News > componentDidMount');
    }
  }

  private getTaxonomyData = (): void => {
    try {
      Common.getTermSetData(this.state.configData, ConfigType.Taxonomy, ConfigKey.Region).then(regions => {
        this.setState({ alertRegion: regions }, () => {
          Common.getTermSetData(this.state.configData, ConfigType.Taxonomy, ConfigKey.TherapeuticArea).then(tas => {
            this.setState({ alertTA: tas, regTADataLoaded:true });
          });
        });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'News > getTaxonomyData');
    }
  }
  
  private updateData = (type: string, data: []):void => {
    if (type == "lastday") {
      this.setState({ todaysAlerts: data });
    } else if (type == "lastweek") {
      this.setState({ weeksAlerts: data });
    }
  }
}
