import * as React from 'react';
import { ListService } from '../../../services/ListService';
import { IAlert, AlertStatus } from '../../../models/IAlert';
import { ShimmerElementType, Shimmer, PrimaryButton, Link, IconButton, IIconProps, ShimmerElementsGroup, TooltipHost, DialogFooter, Dialog, DialogType, DefaultButton } from '@fluentui/react';
import { Common } from '../../../common/common';
import { ConfigType, ConfigKey } from '../../../models/IConfiguration';
import { LoggerService } from '../../../services/LoggerService';
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { CurrentUser } from '@pnp/sp/src/siteusers';

interface LastWeekNewsCompState {
    isDataLoaded: boolean;
    weeksAlerts: any;
    isUserAdmin: boolean;
    hideUnpubDialog: boolean;
    alertRegion: any[];
    alertTA: any[];
    isEmpty: boolean;
    currentUser: CurrentUser;
    configData: any[];
    regTADataLoaded: boolean;
}

interface LastWeekNewsCompProps {
    webURL: string;
    context: WebPartContext;
    alertRegion: any[];
    alertTA: any[];
    isUserAdmin: boolean;
    currentUser: CurrentUser;
    configData: any[];
    updateData: (type: string, data: any) => void;
    weeksAlerts: any;
    regTADataLoaded: boolean;
}

const getNewsElementShimmer = (): JSX.Element => {
    return (
        <div>
            <ShimmerElementsGroup
                flexWrap
                shimmerElements={[
                    { type: ShimmerElementType.line, width: 500, height: 8 },
                    { type: ShimmerElementType.gap, width: 500, height: 10 },
                    { type: ShimmerElementType.line, width: 500, height: 8 },
                ]}
            />
            <ShimmerElementsGroup
                flexWrap
                shimmerElements={[
                    { type: ShimmerElementType.gap, width: 500, height: 21 },
                ]}
            />
            <ShimmerElementsGroup
                flexWrap
                shimmerElements={[
                    { type: ShimmerElementType.line, width: 500, height: 8 },
                    { type: ShimmerElementType.gap, width: 500, height: 5 },
                    { type: ShimmerElementType.line, width: 500, height: 8 },
                ]}
            />
            <ShimmerElementsGroup
                flexWrap
                shimmerElements={[
                    { type: ShimmerElementType.gap, width: 500, height: 5 },
                    { type: ShimmerElementType.circle, height: 25 },
                    { type: ShimmerElementType.gap, width: 10, height: 30 },
                ]}
            />
            <ShimmerElementsGroup
                flexWrap
                shimmerElements={[
                    { type: ShimmerElementType.gap, width: 500, height: 10 },
                    { type: ShimmerElementType.circle, height: 25 },
                    { type: ShimmerElementType.gap, width: 10, height: 30 },
                ]}
            />
            <ShimmerElementsGroup
                flexWrap
                shimmerElements={[
                    { type: ShimmerElementType.gap, width: 500, height: 10 },
                    { type: ShimmerElementType.circle, height: 25 },
                    { type: ShimmerElementType.gap, width: 10, height: 30 },
                ]}
            />
        </div>
    );
};

export default class LastWeekNewsComp extends React.Component<LastWeekNewsCompProps, LastWeekNewsCompState>{  
    private _itemId: number = 0;

    constructor(props) {
        super(props);
        this.state = {
            isDataLoaded: false,
            weeksAlerts: this.props.weeksAlerts,           
            hideUnpubDialog: true,           
            isEmpty: false,
            isUserAdmin: this.props.isUserAdmin,
            alertRegion: this.props.alertRegion,
            alertTA: this.props.alertTA,
            currentUser: this.props.currentUser,
            configData: this.props.configData,
            regTADataLoaded: this.props.regTADataLoaded
            
        };
    }

    public componentDidMount() {
        try {            
            if (this.state.configData.length > 0) {
                if (this.state.weeksAlerts.length == 0 && this.state.regTADataLoaded) {
                    this.getLastWeekAlerts(false);
                }
                else {
                    this.setState({ isDataLoaded: true });
                }
            }              
        } catch (error) {
            LoggerService.errorLog(error, 'LastWeekNewsComp > componentDidMount');
        }
    }

    public componentDidUpdate(prevProps: LastWeekNewsCompProps) {
         if (this.state.configData != prevProps.configData && this.state.regTADataLoaded != prevProps.regTADataLoaded) {
            this.setState({ configData: prevProps.configData, regTADataLoaded: prevProps.regTADataLoaded }, () => {
                this.getLastWeekAlerts(false);
            });
        }         
        if (this.state.alertRegion != prevProps.alertRegion) {
            this.setState({ alertRegion: prevProps.alertRegion });
        }
        if (this.state.alertTA != prevProps.alertTA) {
            this.setState({ alertTA: prevProps.alertTA });
        }
        if (this.state.isUserAdmin != prevProps.isUserAdmin) {
            this.setState({ isUserAdmin: prevProps.isUserAdmin });
        }
        if (this.state.currentUser != prevProps.currentUser) {
            this.setState({ currentUser: prevProps.currentUser });
        }
    }

    public render(): JSX.Element {
        let viewAlPage = Common.getConfigValue(this.state.configData, ConfigType.Page, ConfigKey.ViewAlert);
        return (
            <div>
                {this.state.isDataLoaded ? null :
                    <div className="news_container">
                        <div className="news_box extraPad"><Shimmer customElementsGroup={getNewsElementShimmer()} /></div>
                        <div className="news_box extraPad"><Shimmer customElementsGroup={getNewsElementShimmer()} /></div>
                        <div className="news_box extraPad"><Shimmer customElementsGroup={getNewsElementShimmer()} /></div>
                        <div className="news_box extraPad"><Shimmer customElementsGroup={getNewsElementShimmer()} /></div>
                    </div>}
                {this.state.isEmpty ?
                    <div className="news_container">
                        <div className="empty_box emptyAlert">
                            <h1>No Alerts for last week</h1>
                        </div></div> : null}
                <div className="news_container">
                    {this.state.weeksAlerts.length > 0 ? this.state.weeksAlerts.map(item =>
                        <div className="news_box">
                            <TooltipHost
                                content={item.title}
                                id={"titleTooltip_" + item.id}
                                calloutProps={{ gapSpace: 0 }}
                                styles={{ root: { display: 'inline-block' } }}
                            >
                                {Common.isIE ?
                                    <p className="title_txtIE"><a href={this.props.webURL + viewAlPage + '#id=' + item.id}>
                                        {item.title.length > 80 ? item.title.substring(0, 80) + '...' : item.title}
                                    </a></p> :
                                    <p className="title_txt"><Link href={this.props.webURL + viewAlPage + '#id=' + item.id}>{item.title}</Link></p>}
                            </TooltipHost>
                            {Common.isIE ?
                                <p className="red_txtIE">​Impact: {item.impact.length > 70 ? item.impact.substring(0, 70) + '...' : item.impact}</p> :
                                <p className="red_txt">​Impact: {item.impact}</p>}
                            {item.region.indexOf(',') >= 0 ?
                                <p className="img_details">
                                    <img src={this.getIcon(ConfigKey.Region, item.region)} />
                                    <img className="globe_icon" src={this.props.webURL + "/SiteAssets/Images/Region/world_icon2.png"} />
                                    {Common.isIE ?
                                        <span>{item.region.length > 70 ? item.region.substring(0, 70) + '...' : item.region}</span> :
                                        <span>{item.region}</span>}
                                </p> :
                                <p className="img_details"><img src={this.getIcon(ConfigKey.Region, item.region)} /><span>{item.region}</span></p>
                            }
                            {item.therapeuticArea.indexOf(',') >= 0 ?
                                <p className="img_details">
                                    <img src={this.getIcon(ConfigKey.TherapeuticArea, item.therapeuticArea)} />
                                    <img className="globe_icon" src={this.props.webURL + "/SiteAssets/Images/TherapeuticArea/all_therapeutic_areas.png"} />
                                    {Common.isIE ?
                                        <span>{item.therapeuticArea.length > 70 ? item.therapeuticArea.substring(0, 70) + '...' : item.therapeuticArea}</span> :
                                        <span>{item.therapeuticArea}</span>}
                                </p> :
                                <p className="img_details"><img src={this.getIcon(ConfigKey.TherapeuticArea, item.therapeuticArea)} />
                                    <span> {item.therapeuticArea}</span></p>
                            }
                            <p className="auth_details">
                                {item.authorPic ?
                                    <span className="profile_image">
                                        {Common.isIE ? <img src={item.authorPic.substring(0, item.authorPic.indexOf('?'))} /> :
                                            <img src={item.authorPic} />}
                                    </span> :
                                    <span className="profile_image">
                                        <img src={this.props.webURL + '/SiteAssets/Images/BlankPerson.jpg'} />
                                    </span>
                                }
                                {item.author}<span>{item.publicationDate}</span>
                                {this.state.isUserAdmin ?
                                    <IconButton className="v_ellipsis"
                                        menuProps={
                                            {
                                                items: [
                                                    {
                                                        key: 'edit',
                                                        text: 'Edit',
                                                        iconProps: { iconName: 'EditNote' },
                                                        onClick: () => { this.onMenuClick('Edit', item.id); }
                                                    },
                                                    {
                                                        key: 'unpublish',
                                                        text: 'Unpublish',
                                                        iconProps: { iconName: 'UnpublishContent' },
                                                        onClick: () => { this.onMenuClick('Unpublish', item.id); }
                                                    },
                                                ]
                                            }}
                                        //iconProps={Common.isIE ? { iconName: "MoreVertical" } : null}
                                        title="More"
                                        ariaLabel="More"
                                        menuIconProps={{ iconName: "MoreVertical" }}
                                    /> : null}
                            </p>
                        </div>
                    ) : null
                    }
                    <div className="viewMore">
                        <PrimaryButton onClick={this.onViewMoreClick.bind(this)} text="View More" />
                    </div>
                </div>
                <Dialog
                    hidden={this.state.hideUnpubDialog}
                    onDismiss={this.closeUnpubDialog.bind(this)}
                    dialogContentProps={{
                        type: DialogType.normal,
                        title: 'Unpublish Alert',
                        subText: "Do you want to unpublish this alert?"
                    }}
                    modalProps={{
                        isBlocking: true,
                        containerClassName: 'ms-dialogMainOverride'
                    }}
                >
                    <DialogFooter>
                        <PrimaryButton onClick={this.unpublishAlert.bind(this)} text="Confirm" />
                        <DefaultButton onClick={this.closeUnpubDialog.bind(this)} text="Cancel" />
                    </DialogFooter>
                </Dialog>
            </div >
        );
    }

    private getLastWeekAlerts = (isEmpty: boolean): void => {
        try {
            let alertsDBListName = Common.getConfigValue(this.state.configData, ConfigType.Lists, ConfigKey.AlertsDatabase);
            let lastWkSt = new Date(new Date().getTime() - (7 * 24 * 60 * 60 * 1000));
            let lastWeekStStr = lastWkSt.getFullYear() + '-' + (lastWkSt.getMonth() + 1) + '-' + lastWkSt.getDate();
            //let lastWkEnd = new Date(new Date().getTime() - (1 * 24 * 60 * 60 * 1000));
            //let lastWeekEndStr = lastWkEnd.getFullYear() + '-' + (lastWkEnd.getMonth() + 1) + '-' + lastWkEnd.getDate();
            let lastWeekEndStr = new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + new Date().getDate();
            //lastWeekStStr += 'T00%3a00%3a00';
            //lastWeekEndStr += 'T11%3a59%3a59';
            
            let camlQ: string = `<View>
            <Query>`;
            if (isEmpty) {
                camlQ += `<Where>
                                <And>
                                    <Eq>
                                        <FieldRef Name='ADBStatus'/>
                                        <Value Type='Text'>${AlertStatus.Publish}</Value>
                                    </Eq>
                                    <Lt>
                                        <FieldRef Name='ADBPublicationDate' />
                                        <Value Type='Text'>${lastWeekEndStr}</Value>
                                    </Lt>
                                </And>
                        </Where>`;
            }
            else {
                camlQ += `<Where>
                                <And>
                                    <And>
                                        <Geq>
                                            <FieldRef Name='ADBPublicationDate' />
                                            <Value Type='Text'>${lastWeekStStr}</Value>
                                        </Geq>
                                        <Lt>
                                            <FieldRef Name='ADBPublicationDate' />
                                            <Value Type='Text'>${lastWeekEndStr}</Value>
                                        </Lt>                                    
                                    </And>
                                    <Eq><FieldRef Name='ADBStatus'/><Value Type='Text'>${AlertStatus.Publish}</Value></Eq>
                                </And>
                        </Where>`;
            }
            camlQ += `<OrderBy><FieldRef Name='ADBPublicationDate' Ascending='False' /></OrderBy>
            </Query>
            <ViewFields><FieldRef Name='ID'/><FieldRef Name='ADBImpact'/><FieldRef Name='ADBPublicationDate'/><FieldRef Name='G2Region'/>
            <FieldRef Name='G2TherapeuticArea'/><FieldRef Name='ADBAuthor'/><FieldRef Name='Title'/></ViewFields>
            <RowLimit Paged="TRUE">4</RowLimit>
            <ExpandUserField>True</ExpandUserField>
            </View>`;

            ListService.getDataFromLargeList(alertsDBListName, camlQ).then(data => {
                if (data) {
                    if (data.Row.length > 0) {
                        let weeksAlerts: any = [];
                        data.Row.map(alertItem => {
                            weeksAlerts.push({
                                id: alertItem['ID'],
                                title: alertItem['Title'],
                                impact: alertItem["ADBImpact"],
                                publicationDate: new Date(alertItem["ADBPublicationDate"]).toDateString(),
                                region: Common.getManagedMetadataString(alertItem["G2Region"]),
                                therapeuticArea: Common.getManagedMetadataString(alertItem["G2TherapeuticArea"]),
                                author: alertItem["ADBAuthor"][0]["title"],
                                authorPic: alertItem["ADBAuthor"][0]["picture"] ? alertItem["ADBAuthor"][0]["picture"].replace(":443", '') : ''
                            });
                        });
                        this.setState({ weeksAlerts: [...weeksAlerts], isDataLoaded: true }, () => {
                            this.props.updateData("lastweek", weeksAlerts);
                        });
                    } else
                        if (isEmpty)
                            this.setState({ isEmpty: true, isDataLoaded: true });
                        else
                            this.getLastWeekAlerts(true);
                } else
                    if (isEmpty)
                        this.setState({ isEmpty: true, isDataLoaded: true });
                    else
                        this.getLastWeekAlerts(true);
            })
                .catch(error => {
                    LoggerService.errorLog(error, 'LastWeekNewsComp > getLastWeekAlerts > getDataFromLargeList');
                });
        } catch (error) {
            LoggerService.errorLog(error, 'LastWeekNewsComp > getLastWeekAlerts');
        }
    }

    private onViewMoreClick = (): void => {
        try {
            LoggerService.auditLog("Clicked on View More", 'LastWeekNewsComp > onViewMoreClick');
            let viewAlertsPage = Common.getConfigValue(this.state.configData, ConfigType.Page, ConfigKey.ManageAlerts);
            window.location.href = this.props.webURL + viewAlertsPage;
        } catch (error) {
            LoggerService.errorLog(error, 'LastWeekNewsComp > onViewMoreClick');
        }
    }

    private onMenuClick(type: string, itemId: number) {
        try {
            switch (type) {
                case 'Edit':
                    LoggerService.auditLog("Clicked on Edit Alert - " + itemId, 'LastWeekNewsComp > onMenuClick');
                    let editAlertsPage = Common.getConfigValue(this.state.configData, ConfigType.Page, ConfigKey.AddEditAlerts);
                    window.location.href = this.props.webURL + editAlertsPage + '#id=' + itemId;
                    break;
                case 'Unpublish':
                    LoggerService.auditLog("Clicked on Unpublish Alert - " + itemId, 'LastWeekNewsComp > onMenuClick');
                    this._itemId = itemId;
                    this.setState({ hideUnpubDialog: false });
                    break;
                default:
                    break;
            }
        } catch (error) {
            LoggerService.errorLog(error, 'LastWeekNewsComp > onMenuClick');
        }
    }

    private unpublishAlert = (): void => {
        try {
            let alertsDBListName = Common.getConfigValue(this.state.configData, ConfigType.Lists, ConfigKey.AlertsDatabase);

            let data: any = {
                Id: this._itemId,
                ADBStatus: AlertStatus.Unpublish
            };
            ListService.UpdateListDataByID(alertsDBListName, this._itemId, data).then(resp => {
                if (resp) {
                    LoggerService.auditLog("Alert Unpublished - " + this._itemId, 'LastWeekNewsComp > unpublishAlert');
                    this._itemId = 0;
                    this.setState({ hideUnpubDialog: true }, () => this.getLastWeekAlerts(false));
                }
            }).catch(err => {
                LoggerService.errorLog(err, 'LastWeekNewsComp > unpublishAlert > UpdateListDataByID');
                this.setState({ hideUnpubDialog: true });
            });
        } catch (error) {
            LoggerService.errorLog(error, 'LastWeekNewsComp > unpublishAlert');
            this.setState({ hideUnpubDialog: true });
        }
    }

    private closeUnpubDialog() {
        LoggerService.auditLog("Alert Unpublish cancelled - " + this._itemId, 'LastWeekNewsComp > closeUnpubDialog');
        this._itemId = 0;
        this.setState({ hideUnpubDialog: true });
    }

    private getIcon = (category: string, catValue: string): string => {
        try {
            let retVal = '';
            switch (category) {
                case ConfigKey.Region:
                    let regTerm: any;
                    let regionPath = Common.getConfigValue(this.state.configData, ConfigType.ImagePath, ConfigKey.Region);
                    if (catValue.indexOf(',') >= 0) {
                        regTerm = this.state.alertRegion.filter(term => term.text.toLowerCase() == catValue.split(',')[0].toLowerCase());
                        retVal = this.props.webURL + regionPath + regTerm[0].imagePath;
                    } else {
                        regTerm = this.state.alertRegion.filter(term => term.text.toLowerCase() == catValue.toLowerCase());
                        retVal = this.props.webURL + regionPath + regTerm[0].imagePath;
                    }
                    break;
                case ConfigKey.TherapeuticArea:
                    let taTerm: any;
                    let taPath = Common.getConfigValue(this.state.configData, ConfigType.ImagePath, ConfigKey.TherapeuticArea);
                    if (catValue.indexOf(',') >= 0) {
                        taTerm = this.state.alertTA.filter(term => term.text.toLowerCase() == catValue.split(',')[0].toLowerCase());
                        retVal = this.props.webURL + taPath + taTerm[0].imagePath;
                    } else {
                        taTerm = this.state.alertTA.filter(term => term.text.toLowerCase() == catValue.toLowerCase());
                        retVal = this.props.webURL + taPath + taTerm[0].imagePath;
                    }
                    break;
                default:
                    break;
            }
            return retVal;
        } catch (error) {
            LoggerService.errorLog(error, 'LastWeekNewsComp > getIcon');
        }
    }
}