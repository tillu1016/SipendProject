declare interface ISearchAuditingWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SearchAuditingWebPartStrings' {
  const strings: ISearchAuditingWebPartStrings;
  export = strings;
}
