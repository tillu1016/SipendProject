export interface ISearchAuditingProps {
  description: string;
}
