import * as React from 'react';
import styles from './SearchAuditing.module.scss';
import { ISearchAuditingProps } from './ISearchAuditingProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { createHashHistory } from 'history';
import { LoggerService } from "../../../services/LoggerService";
import { Common } from '../../../common/common';
import { ConfigType, ConfigKey, IConfiguration } from '../../../models/IConfiguration';

export interface ISearchAuditingState {
    searchTerm: string;
}

export default class SearchAuditing extends React.Component<ISearchAuditingProps, ISearchAuditingState> {  
  
  public componentDidMount() {
    //window.addEventListener("hashchange", this._hashchange.bind(this), false);

    try {
      Common.getConfigData().then(resp => {
        if (resp) {
          Common.errorLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ErrorLog);
          Common.auditLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AuditLog);
          var prevHash = window.location.hash;
          window.setInterval(() => {            
            if (window.location.hash != prevHash) {
                prevHash = window.location.hash;
              if (window.location.hash.split("#").length > 1) {
                this._addAuditLog(window.location.hash.split("#")[1]);
              }
            }
          }, 500);
        }
      });
    } catch (error) {
      LoggerService.errorLog(error, 'SearchAuditing > componentDidMount');
    }
  }

  public _hashchange() {
    if (window.location.hash.split("#").length > 1) {
      this._addAuditLog(window.location.hash.split("#")[1]);
    }
  }
 
  public _addAuditLog(seachTerm) {
    //add audit log
    console.log("search term:" + seachTerm);    
    LoggerService.auditLog("Search term: " + seachTerm , 'SearchAuditing > _addAuditLog');
  }

  public render(): React.ReactElement<ISearchAuditingProps> {
    return (
      <div className={styles.searchAuditing}>        
      </div>
    );
  }
}
