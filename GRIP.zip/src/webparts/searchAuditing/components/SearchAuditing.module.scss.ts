/* tslint:disable */
require("./SearchAuditing.module.css");
const styles = {
  searchAuditing: 'searchAuditing_7c37ae70',
  container: 'container_7c37ae70',
  row: 'row_7c37ae70',
  column: 'column_7c37ae70',
  'ms-Grid': 'ms-Grid_7c37ae70',
  title: 'title_7c37ae70',
  subTitle: 'subTitle_7c37ae70',
  description: 'description_7c37ae70',
  button: 'button_7c37ae70',
  label: 'label_7c37ae70'
};

export default styles;
/* tslint:enable */