import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'ManageSubmitRIforApprovalWebPartStrings';
import ManageSubmitRIforApproval from './components/ManageSubmitRIforApproval';
import { IManageSubmitRIforApprovalProps } from './components/IManageSubmitRIforApprovalProps';
import { sp } from '@pnp/sp';
import { INotification } from "../../models/INotification";
import { IDynamicDataPropertyDefinition } from '@microsoft/sp-dynamic-data';

export interface IManageSubmitRIforApprovalWebPartProps {
  description: string;
}

export default class ManageSubmitRIforApprovalWebPart extends BaseClientSideWebPart<IManageSubmitRIforApprovalWebPartProps> {
  private _appNotification: INotification;

  public render(): void {
    const element: React.ReactElement<IManageSubmitRIforApprovalProps> = React.createElement(
      ManageSubmitRIforApproval,
      {
        description: this.properties.description,
        webURL: this.context.pageContext.web.absoluteUrl,
        onSetNotification: this.handleSetNotification,
        context: this.context
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onInit(): Promise<void> {
    this.context.dynamicDataSourceManager.initializeSource(this);
    this.handleSetNotification = this.handleSetNotification.bind(this);

    return super.onInit().then(_ => {
      sp.setup({
        spfxContext: this.context
      });
    });
  }

  public getPropertyDefinitions(): ReadonlyArray<IDynamicDataPropertyDefinition> {
    return [
      {
        id: 'publishToExtensions',
        title: 'Publish to App Notification Extensions'
      },
      {
        id: 'appNotification',
        title: 'Get App Notification'
      }
    ];
  }

  public getPropertyValue(propertyId: string): boolean | INotification {
    switch (propertyId) {
      case 'publishToExtensions':
        return true;
      case 'appNotification':
        return this._appNotification;
    }
    throw new Error('Bad property ID');
  }

  private handleSetNotification = (appNotification: INotification): void => {
    this._appNotification = appNotification;
    // notify subscribers about the new app notification
    this.context.dynamicDataSourceManager.notifyPropertyChanged('appNotification');
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
