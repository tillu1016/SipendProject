declare interface IManageSubmitRIforApprovalWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ManageSubmitRIforApprovalWebPartStrings' {
  const strings: IManageSubmitRIforApprovalWebPartStrings;
  export = strings;
}
