import "@pnp/polyfill-ie11";
import 'core-js/es7/map';
import 'core-js/es6/array';
import 'core-js/fn/string/includes';
import * as React from 'react';
import '@progress/kendo-theme-default/dist/all.css';
import styles from './ManageSubmitRIforApproval.module.scss';
import { IManageSubmitRIforApprovalProps } from './IManageSubmitRIforApprovalProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { ListService } from '../../../services/ListService';
import {
  Stack, Dropdown, TextField, SearchBox, DetailsList, IColumn, DetailsListLayoutMode, DefaultButton, Dialog, DialogType,
  SpinButton, ComboBox, DialogFooter, PrimaryButton, Link, SelectionMode, TooltipHost, IconButton, IIconProps, Label,
  IStackItemStyles, ShimmeredDetailsList, ActionButton, MessageBar, MessageBarType, IComboBoxOption, Checkbox
} from '@fluentui/react';
import { IAlert, AlertIconType, AlertStatus } from '../../../models/IAlert';
import { ConfigType, IConfiguration, ConfigKey } from '../../../models/IConfiguration';
import { Common } from '../../../common/common';
import { CurrentUser } from '@pnp/sp/src/siteusers';
import { Grid, GridColumn } from '@progress/kendo-react-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import { Tooltip } from '@progress/kendo-react-tooltip';
import { LoggerService } from "../../../services/LoggerService";
import { PageName } from "../../../models/IAlertAnalytics";
import BlockUIComp from '../../../common/BlockUIComp';
import { NotificationType } from "../../../models/INotification";
import { ColumnMenu, ColumnMenuCheckboxFilter } from '../../../common/ColumnMenu';
import { GridColumnCell } from '../../../common/GridColumnComp';
import * as moment from 'moment-timezone';
import { EmailService } from '../../../services/EmailService';
import { PermissionsService } from '../../../services/PermissionsService';

export interface IManageAlertsState {
  alertRegionOptions: any[];
  alertTAOptions: any[];
  alertRegTopicOptions: any[];
  selRegion: any[];
  selTA: any[];
  selRegTopic: any[];
  selAuthor: any[];
  searchText: string;
  listColumns: IColumn[];
  allAlerts: IAlert[];
  hideSignUpDialog: boolean;
  isUserAdmin: boolean;
  showNewEditPanel: boolean;
  newEditPanelHeaderText: string;
  hideDeleteDialog: boolean;
  hideShareDialog: boolean;
  exportToPDFItem: IAlert;
  showShimmer: boolean;
  skip: number;
  take: number;
  columns: any;
  sort: any[];
  filter: any;
  alertAuthorOptions: any[];
  showSuccessMessage: boolean; successMessage: string; showErrorMessage: boolean; errorMessage: string; hideLoadingDialog: boolean; loadingText: string;
  addEditAlertPage: string; disableAlertSubmit: boolean; result: any; dataState: any; pageable: any;
  admMems: string[];
}

export default class ManageSubmitRIforApproval extends React.Component<IManageSubmitRIforApprovalProps, IManageAlertsState> {
  private _configData: IConfiguration[] = [];
  private _allAlerts: any[] = [];
  private _selRegionsObj: any[] = [];
  private _selTAObj: any[] = [];
  private _selRegTopicObj: any[] = [];
  private _selAuthorObj: any[] = [];
  private _currUser: CurrentUser;
  private _alertIdToDelete: number = 0;
  private _refTextToCopy;
  private _addNewAlertURL: string = "";
  private _searchText: string = "";
  
  private MSColumnMenuCheckboxFilter = (props) => <ColumnMenuCheckboxFilter {...props} data={this.state.allAlerts} />;
  constructor(props) {
    super(props);
    const dataState = this.createDataState({
      take: Common.pageSize,
      skip: 0,
      sort: [{ field: 'id', dir: 'desc' }]
    });

    this.state = {
      alertRegionOptions: [],
      alertTAOptions: [],
      alertRegTopicOptions: [],
      selRegion: [],
      selTA: [],
      selRegTopic: [],
      selAuthor: [],
      searchText: '',
      listColumns: [],
      allAlerts: [],
      hideSignUpDialog: true,
      isUserAdmin: false,
      showNewEditPanel: false,
      newEditPanelHeaderText: "",
      hideDeleteDialog: true,
      hideShareDialog: true,
      exportToPDFItem: {} as IAlert,
      showShimmer: true,
      skip: 0,
      take: Common.pageSize,
      columns: [],
      sort: [],
      filter: {
        logic: "and",
        filters: []
      },
      alertAuthorOptions: [],
      showSuccessMessage: false, successMessage: '', showErrorMessage: false, errorMessage: '', addEditAlertPage: '', disableAlertSubmit: true, hideLoadingDialog: false, loadingText: "Please Wait...",
      result: [], dataState: [],
      pageable: {
        buttonCount: 5,
        info: true,
        type: 'numeric',
        pageSizes: [50, 100, 200],
        previousNext: true
      },
      admMems: []
    };
    this._refTextToCopy = React.createRef();
  }

  public componentDidMount() {
    try {
      this.createDataState({ take: this.state.take, skip: this.state.skip, sort: this.state.sort });
      Common.timeZone = moment.tz.guess();
      moment.tz.setDefault(Common.timeZone);

      Common.getConfigData().then(resp => {
        if (resp) {
          this._configData = resp;
          Common.errorLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ErrorLog);
          Common.auditLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AuditLog);
          Common.pageSize = Number.parseInt(Common.getConfigValue(resp, ConfigType.Grid, ConfigKey.PageSize));

          let adminGrpName: string = Common.getConfigValue(this._configData, ConfigType.Roles, ConfigKey.Administrator);
          this.setState({ take: Common.pageSize });

          Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.Region).then(regions => {
            this.setState({ alertRegionOptions: regions });
          });
          Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.RegulatoryTopic).then(regTopics => {
            this.setState({ alertRegTopicOptions: regTopics });
          });
          Common.getTermSetData(this._configData, ConfigType.Taxonomy, ConfigKey.TherapeuticArea).then(tas => {
            this.setState({ alertTAOptions: tas });
          });

          Common.getCurrentUserId().then((curUser: CurrentUser) => {
            this._currUser = curUser;
            Common.checkIfUserAdmin(adminGrpName).then(isUsrAdm => {
              //log user visits          
              let AlertAnalyticsList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AlertAnalytics);
              Common.logSiteVisit(AlertAnalyticsList, PageName.ManageSubmitRItoTeam, isUsrAdm, this._currUser["Id"], null);

              this.setState({ isUserAdmin: isUsrAdm }, () => {
                this.getAllAlertsData();
              });
            });
          });

          this.getAdminMembers().then(result => {
            this.setState({ admMems: result });
          });
        }
      });

      this._addNewAlertURL = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.AddEditSubmitRItoTeam);
      this._addNewAlertURL = this.props.webURL + this._addNewAlertURL;
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > componentDidMount');
    }
  }

  private async getAdminMembers(): Promise<string[]> {
    try {
      let grpName = Common.getConfigValue(this._configData, ConfigType.Roles, ConfigKey.Administrator);
      return await PermissionsService.getGroupMembers(grpName).then(members => {
        return members.map(mem => mem.Email);
      });
    } catch (error) {
      LoggerService.errorLog(error, 'AddEditAlerts > getAdminMembers');
    }
  }

  private _getQueryParam = (): void => {
    try {      
      let viewType = Common.getQueryStringValue('viewtype');
      let viewId = Common.getQueryStringValue('viewid');
      let viewName = Common.getQueryStringValue('viewname');

      if (viewType.length > 0 && viewId.length > 0 && viewName.length > 0) {

        let arrVal: any = { key: viewId, text: viewName, selected: true };
        switch (viewType) {
          case ConfigKey.Region.toLowerCase():
            this.setMultiselectState(ConfigKey.Region, "selRegion", arrVal);
            break;
          case ConfigKey.TherapeuticArea.toLowerCase():
            this.setMultiselectState(ConfigKey.TherapeuticArea, "selTA", arrVal);
            break;
          default:
            break;
        }
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > _getQueryParam');
    }
  }

  private onIconClick(type: string, item: any) {
    try {
      LoggerService.auditLog("Clicked on Icon - " + type, 'ManageSubmitRIforApproval > onIconClick');
      switch (type) {
        case AlertIconType.Delete:
          this._alertIdToDelete = item.id;
          this.setState({ hideDeleteDialog: false });
          break;
        default:
          break;
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > onIconClick');
    }
  }

  private getAllAlertsData() {
    try {
      let alertDBListName = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.AlertsSubmitRItoTeam);
      let camlQ: string = "";
      this.state.isUserAdmin ?
        camlQ = `<View>
      <ViewFields><FieldRef Name='ID'/><FieldRef Name='Title'/><FieldRef Name='ADBStatus'/><FieldRef Name='G2Region'/><FieldRef Name='G2DocumentType'/>
      <FieldRef Name='G2RegulatoryTopic'/><FieldRef Name='G2TherapeuticArea'/>      
      <FieldRef Name='ADBImpact'/><FieldRef Name='ADBAlertBody'/><FieldRef Name='ADBPublicationDate'/><FieldRef Name='ADBAuthor'/><FieldRef Name='Author'/></ViewFields>
      <RowLimit>4999</RowLimit>
      <ExpandUserField>True</ExpandUserField><Query><OrderBy><FieldRef Name='Modified' Ascending='False' /></OrderBy></Query></View>`
        :
        camlQ = `<View>
      <ViewFields><FieldRef Name='ID'/><FieldRef Name='Title'/><FieldRef Name='ADBStatus'/><FieldRef Name='G2Region'/><FieldRef Name='G2DocumentType'/>
      <FieldRef Name='G2RegulatoryTopic'/><FieldRef Name='G2TherapeuticArea'/>      
      <FieldRef Name='ADBImpact'/><FieldRef Name='ADBAlertBody'/><FieldRef Name='ADBPublicationDate'/><FieldRef Name='ADBAuthor'/><FieldRef Name='Author'/></ViewFields>
      <RowLimit>4999</RowLimit>
      <ExpandUserField>True</ExpandUserField><Query><Where><Eq><FieldRef Name='Author' LookupId='True'/><Value Type='Lookup'><UserID/></Value></Eq></Where><OrderBy><FieldRef Name='Modified' Ascending='False' /></OrderBy></Query></View>`;

      ListService.getDataFromLargeList(alertDBListName, camlQ).then(data => {
        if (data) {
          this._allAlerts = [];
          data.Row.map((alert) => {
            this._allAlerts.push({
              icons: '', id: alert['ID'],
              title: alert['Title'], impact: alert["ADBImpact"], body: Common.modifyRelativeURL(alert["ADBAlertBody"], this.props.context.pageContext.site.serverRelativeUrl, this.props.context.pageContext.site.absoluteUrl),
              publicationDate: alert["ADBPublicationDate"] ? moment(alert["ADBPublicationDate"]).toDate() : null,
              status: this.state.isUserAdmin ? alert["ADBStatus"] :
                (alert["ADBStatus"] != AlertStatus.Submitted && alert["ADBStatus"] != AlertStatus.Publish && alert["ADBStatus"] != AlertStatus.Rejected ? "Review In Progress" : alert["ADBStatus"]),
              region: Common.getManagedMetadataString(alert["G2Region"]),
              documentType: Common.getManagedMetadataString(alert["G2DocumentType"]),
              regulatoryTopic: Common.getManagedMetadataString(alert["G2RegulatoryTopic"]),
              therapeuticArea: Common.getManagedMetadataString(alert["G2TherapeuticArea"]),
              author: alert.ADBAuthor ? alert.ADBAuthor[0]['title'] : '',
              createdBy: alert.Author[0]['title'],
              createdById: alert.Author[0]['id'],
              createdByEmail: alert.Author[0]['email']
            });
          });

          this.setState({ allAlerts: this._allAlerts, showShimmer: false, hideLoadingDialog: true }, () => {
            this._getQueryParam();
            this.getDistinctAuthors();
            this.createDataState({ take: this.state.take, skip: this.state.skip, sort: this.state.sort });
            this.onDDLFilter();
          });
        }
      }).catch(error => {
        LoggerService.errorLog(error, 'ManageSubmitRIforApproval > getAllAlertsData > getDataFromLargeList');
        this.setState({ hideLoadingDialog: true });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > getAllAlertsData');
    }
  }

  public render(): React.ReactElement<IManageSubmitRIforApprovalProps> {
    return (
      <div className={styles.manageAlerts} >
        <Stack>
          {this.state.showSuccessMessage ?
            <Stack.Item className="report_mgs">
              <MessageBar messageBarType={MessageBarType.success} isMultiline={false} onDismiss={() => {
                this.setState({ ...this.state, showSuccessMessage: false });
              }}>
                {this.state.successMessage}
              </MessageBar>
            </Stack.Item> : null}
          {this.state.showErrorMessage ?
            <Stack.Item className="report_mgs">
              <MessageBar messageBarType={MessageBarType.error} isMultiline={false} onDismiss={() => {
                this.setState({ ...this.state, showErrorMessage: false });
              }}>
                {this.state.errorMessage}
              </MessageBar>
            </Stack.Item> : null}
          <Stack.Item>
            <h1>Manage Submit RI to Team</h1>
          </Stack.Item>
          <Stack.Item className="filter_container">
            <div className="filterSectionLeft">
              <div className="maFiltersDropdown">
                <Dropdown
                  placeholder="Select an option"
                  label="Region"
                  options={this.state.alertRegionOptions}
                  multiSelect
                  onChange={this._onDDLRegionChange.bind(this)}
                  selectedKeys={this.state.selRegion}
                  dropdownWidth={350}
                />
              </div>
              <div className="maFiltersDropdown">
                <Dropdown
                  placeholder="Select an option"
                  label="Therapeutic Area"
                  multiSelect
                  options={this.state.alertTAOptions}
                  onChange={this._onDDLTAChange.bind(this)}
                  selectedKeys={this.state.selTA}
                  dropdownWidth={350}
                />
              </div>
              <div className="maFiltersDropdown">
                <Dropdown
                  placeholder="Select an option"
                  label="Regulatory Topic"
                  multiSelect
                  options={this.state.alertRegTopicOptions}
                  onChange={this._onDDLRegTopicChange.bind(this)}
                  selectedKeys={this.state.selRegTopic}
                  dropdownWidth={350}
                />
              </div>
              {
                this.state.isUserAdmin ?
                  <div className="maFiltersDropdown">
                    <Dropdown
                      placeholder="Select an option"
                      label="Author"
                      multiSelect
                      options={this.state.alertAuthorOptions}
                      onChange={this._onDDLAuthorChange.bind(this)}
                      selectedKeys={this.state.selAuthor}
                      disabled={this.state.alertAuthorOptions.length == 0 ? true : false}
                      dropdownWidth={350}
                    />
                  </div>
                  :
                  null
              }
            </div>
            <div className="filterSectionRight">
              <div className="maSignUpContainer">
                {!this.state.isUserAdmin ?
                  <PrimaryButton className="maSignUpButton" text="Submit RI to Team" onClick={this.onSubmitRIClick.bind(this)} />
                  : null}
              </div>
              <div className="maSearchBox">
                <SearchBox className="searchBox" placeholder="Search Alerts"
                  onClear={ev => {
                    this._searchText = '';
                    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
                    this.onDDLFilter();
                  }}
                  onChange={(newValue) => {
                    let srchTxt: string = newValue ? newValue.currentTarget.value : "";
                    this._searchText = srchTxt;
                    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
                    this.onDDLFilter();
                  }}
                />
              </div>
            </div>
          </Stack.Item>
          <Stack.Item>
            <Tooltip openDelay={100} position="auto" anchorElement="element">
              <Grid
                style={{ height: '600px' }}
                data={this.state.result.length > 0 ?
                  orderBy(this.state.result.data, this.state.sort) :
                  this.state.result}
                {...this.state.dataState}
                onDataStateChange={this.dataStateChange}
                total={this.state.result.total}
                pageable={this.state.pageable}
                reorderable={true}
                sortable
                sort={this.state.sort}
                resizable
                onSortChange={(e) => { this._sortChange(e); }}
              >
                {this.state.isUserAdmin ?
                  <GridColumn field="icons" title="Actions" width="135" cell={this.showIcons}></GridColumn> :
                  <GridColumn field="icons" title="Actions" width="80px" cell={this.showIcons}></GridColumn>}
                <GridColumn field="title" title="Title" width="380px" filter="text" columnMenu={ColumnMenu} cell={GridColumnCell}></GridColumn>
                <GridColumn field="status" title="Status" width="100px" filter={'text'} columnMenu={this.MSColumnMenuCheckboxFilter}></GridColumn>
                <GridColumn field="region" title="Region" width="150px" cell={GridColumnCell}></GridColumn>
                <GridColumn field="therapeuticArea" title="Therapeutic Area" width="200px" cell={GridColumnCell}></GridColumn>
                <GridColumn field="regulatoryTopic" title="Regulatory Topic" width="250px" cell={GridColumnCell}></GridColumn>
                <GridColumn field="documentType" title="Document Type" width="200px" filter={'text'} columnMenu={this.MSColumnMenuCheckboxFilter} cell={GridColumnCell}></GridColumn>
                <GridColumn field="publicationDate" title="Publication Date" width="150px" format="{0:MMM dd, yyyy}" filter={'date'} columnMenu={ColumnMenu}></GridColumn>
                {this.state.isUserAdmin ?
                  <GridColumn field="author" title="Author" width="100px" cell={GridColumnCell}></GridColumn> : null}
              </Grid>
            </Tooltip>
          </Stack.Item>
          <Stack.Item>
            <Dialog
              hidden={this.state.hideDeleteDialog}
              onDismiss={this.closeDeleteDialog.bind(this)}
              dialogContentProps={{
                type: DialogType.normal,
                title: 'Delete Alert',
                subText: "Do you want to delete this alert?"
              }}
              modalProps={{
                isBlocking: true,
                containerClassName: 'ms-dialogMainOverride'
              }}
            >
              <DialogFooter>
                <PrimaryButton onClick={this.deleteAlert.bind(this)} text="Confirm" />
                <DefaultButton onClick={this.closeDeleteDialog.bind(this)} text="Cancel" />
              </DialogFooter>
            </Dialog>
          </Stack.Item>
        </Stack>
        <BlockUIComp hideLoadingDialog={this.state.hideLoadingDialog} loadingText={this.state.loadingText}></BlockUIComp>
      </div>
    );
  }

  private closeDeleteDialog() {
    this.setState({ hideDeleteDialog: true });
  }

  private onSubmitRIClick() {
    try {
      LoggerService.auditLog("Clicked on Submit RI to Team", 'ManageSubmitRIforApproval > onSubmitRIClick');
      let submitRIPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.AddEditSubmitRItoTeam);
      window.location.href = this.props.webURL + submitRIPage;
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > onSubmitRIClick');
    }
  }

  private _onDDLRegionChange = (event, value): void => {
    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
    this.setMultiselectState(ConfigKey.Region, "selRegion", value);
  }

  private _onDDLTAChange = (event, value): void => {
    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
    this.setMultiselectState(ConfigKey.TherapeuticArea, "selTA", value);
  }

  private _onDDLRegTopicChange = (event, value): void => {
    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
    this.setMultiselectState(ConfigKey.RegulatoryTopic, "selRegTopic", value);
  }

  private _onDDLAuthorChange = (event, value): void => {
    this.createDataState({ take: this.state.take, skip: 0, sort: this.state.sort });
    this.setMultiselectState('Author', "selAuthor", value);
  }

  private setMultiselectState = (stateName: string, selStateName: string, ddlVal: any[]) => {
    try {
      let selIDs = this.state[selStateName];
      let keyIdx: number = -1;

      if (ddlVal["selected"]) {
        selIDs.push(ddlVal["key"]);
      } else {
        var keyIdx2 = selIDs.findIndex(x => x == ddlVal["key"]);
        if (keyIdx2 !== -1) {
          selIDs.splice(keyIdx2, 1);
        }
      }

      switch (stateName) {
        case ConfigKey.Region:
          if (ddlVal["selected"]) {
            this._selRegionsObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
          } else {
            keyIdx = this._selRegionsObj.findIndex(x => x.key == ddlVal["key"]);
            if (keyIdx !== -1) {
              this._selRegionsObj.splice(keyIdx2, 1);
            }
          }
          this.setState({ selRegion: [...selIDs] }, () => this.onDDLFilter());
          break;
        case ConfigKey.TherapeuticArea:
          if (ddlVal["selected"]) {
            this._selTAObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
          } else {
            keyIdx = this._selTAObj.findIndex(x => x.key == ddlVal["key"]);
            if (keyIdx !== -1) {
              this._selTAObj.splice(keyIdx2, 1);
            }
          }
          this.setState({ selTA: [...selIDs] }, () => this.onDDLFilter());
          break;
        case ConfigKey.RegulatoryTopic:
          if (ddlVal["selected"]) {
            this._selRegTopicObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
          } else {
            keyIdx = this._selRegTopicObj.findIndex(x => x.key == ddlVal["key"]);
            if (keyIdx !== -1) {
              this._selRegTopicObj.splice(keyIdx2, 1);
            }
          }
          this.setState({ selRegTopic: [...selIDs] }, () => this.onDDLFilter());
          break;
        case "Author":
          if (ddlVal["selected"]) {
            this._selAuthorObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
          } else {
            keyIdx = this._selAuthorObj.findIndex(x => x.key == ddlVal["key"]);
            if (keyIdx !== -1) {
              this._selAuthorObj.splice(keyIdx2, 1);
            }
          }
          this.setState({ selAuthor: [...selIDs] }, () => this.onDDLFilter());
          break;
        default:
          break;
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > setMultiselectState');
    }
  }

  private onSearch(newVal) {
    try {
      LoggerService.auditLog("Search string - " + newVal, 'ManageSubmitRIforApproval > onSearch');

      let arrTMPFilteredAlerts: any[] = this.state.allAlerts;
      if (newVal && newVal.trim().length > 0) {
        newVal = newVal.toLowerCase();
        let filteredAlerts = arrTMPFilteredAlerts.filter(item => {
          return item.title.toLowerCase().indexOf(newVal) >= 0 ||
            item.status.toLowerCase().indexOf(newVal) >= 0 || item.documentType.toLowerCase().indexOf(newVal) >= 0 ||
            item.region.toLowerCase().indexOf(newVal) >= 0 || item.regulatoryTopic.toLowerCase().indexOf(newVal) >= 0 ||
            item.therapeuticArea.toLowerCase().indexOf(newVal) >= 0;
        });

        this.setState({
          allAlerts: filteredAlerts
          , result: process(filteredAlerts.slice(0), this.state.dataState)
        });
      }      
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > onSearch');
    }
  }

  private onDDLFilter() {
    try {
      //get fresh data based on new selection of ddls
      let arrFilteredAlerts: any[] = [];
      if (this._selRegionsObj.length == 0 && this._selTAObj.length == 0 && this._selRegTopicObj.length == 0 && this._selAuthorObj.length == 0) {
        this.setState({ allAlerts: this._allAlerts, result: process(this._allAlerts.slice(0), this.state.dataState) }, () => {
          if (this._searchText) {
            this.onSearch(this._searchText);
          }
        });
      }
      else {
         arrFilteredAlerts = this._allAlerts.filter(item => {
          let regionFlag = true, therapeuticFlag = true, regulatoryTopicFlag = true, authorFlag = true; 
          if (this._selRegionsObj.length > 0) {
            let regSelVals = item.region.split(',').map(reg => reg.toLowerCase().trim());
            if (this._selRegionsObj.filter(ele => regSelVals.indexOf(ele.text.toLowerCase()) !== -1).length == 0)
              regionFlag = false;
          }
          if (this._selTAObj.length > 0) {
            let taSelVals = item.therapeuticArea.split(',').map(ta => ta.toLowerCase().trim());
            if (this._selTAObj.filter(ele => taSelVals.indexOf(ele.text.toLowerCase()) !== -1).length == 0)
              therapeuticFlag = false;
          }
          if (this._selRegTopicObj.length > 0) {
            let regTopicSelVals = item.regulatoryTopic.split(',').map(regT => regT.toLowerCase().trim());
            if (this._selRegTopicObj.filter(ele => regTopicSelVals.indexOf(ele.text.toLowerCase()) !== -1).length == 0)
              regulatoryTopicFlag = false;
          }
          if (this._selAuthorObj.length > 0) {
            let authorSelVals = item.author.toLowerCase().trim();
            if (this._selAuthorObj.filter(ele => authorSelVals.indexOf(ele.text.toLowerCase()) !== -1).length == 0)
              authorFlag = false;
          }
          if (regionFlag && therapeuticFlag && regulatoryTopicFlag && authorFlag) {
            return true;
          }
        });
        
        this.setState({           
          allAlerts: arrFilteredAlerts, result: process(arrFilteredAlerts.slice(0), this.state.dataState)
        }, () => {
            if (this._searchText) {
              this.onSearch(this._searchText);
            }
        });
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > onDDLFilter');
    }
  }

  private deleteAlert = (): void => {
    try {
      Common.recycleAlert(this._configData, ConfigType.Lists, ConfigKey.AlertsSubmitRItoTeam, this._alertIdToDelete).then(resp => {
        LoggerService.auditLog("Deleted Submitted RI - " + this._alertIdToDelete, 'ManageSubmitRIforApproval > deleteAlert');        

        var itemIndex = 0;
        for (let index = 0; index < this._allAlerts.length; index++) {
          if (this._allAlerts[index].id == this._alertIdToDelete) {
            itemIndex = index;
            break;
          }
        }
        let alertToDelete: IAlert = this._allAlerts[itemIndex];
        this.getEmailTemplate(AlertStatus.Delete, alertToDelete);

        this._allAlerts.splice(itemIndex, 1);       

        this.setState({ allAlerts: this._allAlerts }, () => {
          this.getDistinctAuthors();
          this.onDDLFilter();
        });  

        this._alertIdToDelete = 0;
        this.setState({ hideDeleteDialog: true });
      }).catch(error => {
        LoggerService.errorLog(error, 'ManageSubmitRIforApproval > deleteAlert > deleteAlert');
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > deleteAlert');
    }
  }

  private getEmailTemplate = (notificationType: string, alertToDelete: IAlert): void => {
    try {
      let emailTmplList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.EmailTemplates);
      switch (notificationType) {
        case AlertStatus.Delete:
          ListService.GetDataByFilterWithExpand(emailTmplList, `Title eq 'RI-DeleteRI'`,
            '*, ETFrom/EMail, ETTo/EMail, ETCc/EMail', 'ETFrom, ETTo, ETCc').then(response => {
              if (response) {
                this._prepDeleteEmail(response, alertToDelete);
              }
            });
          break;
        default:
          break;
      }
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > getEmailTemplate');
    }
  }

  private async _prepDeleteEmail(emailTemplate: any[], alertToDelete: IAlert) {
    try {
      let emailFrom = '';
      let emailTo: any[] = [];
      let emailCc: any[] = [];
      let emailSub = emailTemplate[0]['ETSubject'];
      let emailBody = emailTemplate[0]['ETBody'];
      let viewAlertPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ViewSubmitRItoTeam);     

      if (emailTemplate[0]["ETFrom"])
        emailFrom = emailTemplate[0]['ETFrom'].EMail;
      
      //To Emails
      if (emailTemplate[0]["ETTo"])
        emailTo = emailTemplate[0]["ETTo"].map(em => em.EMail);
      emailTo.push(alertToDelete.createdByEmail);


      //Cc Emails
      if (emailTemplate[0]["ETCc"])
        emailCc = emailTemplate[0]["ETCc"].map(em => em.EMail);
      emailCc = emailCc.concat(this.state.admMems);


      emailSub = emailSub.replace("#Title#", alertToDelete.title);
      emailBody = emailBody.replace("#Requestor#", alertToDelete.createdBy);
      emailBody = emailBody.replace("#LinkToItem#", "<a href='" + this.props.webURL + viewAlertPage + "#" + encodeURIComponent("id=" + alertToDelete.id) + "'>view RI</a>");
      emailBody = emailBody.replace("#DeletedBy#", this._currUser["Title"]);

      this._sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody);

    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > _prepDeleteEmail');
    }
  }

  private _sendEmail(emailFrom: string, emailTo: any[], emailCc: any[], emailSub: string, emailBody: string) {
    try {
      emailTo = emailTo.filter((x) => { return x !== undefined && x !== null; });
      emailCc = emailCc.filter((x) => { return x !== undefined && x !== null; });

      EmailService.sendEmail(emailFrom, emailTo, emailCc, emailSub, emailBody).then(result => {
        LoggerService.auditLog("Email sent", 'ManageSubmitRIforApproval > _sendEmail');
      }).catch(error => {
        LoggerService.errorLog(error, 'ManageSubmitRIforApproval > _sendEmail > sendEmail');
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > _sendEmail');
    }
  }

  private showIcons = (props) => {
    try {
      let viewAlertPage = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.ViewSubmitRItoTeam);
      let viewLink = this.props.webURL + viewAlertPage + "#" + encodeURIComponent("Id=");
      let editLink = Common.getConfigValue(this._configData, ConfigType.Page, ConfigKey.AddEditSubmitRItoTeam);
      editLink = this.props.webURL + editLink + "#" + encodeURIComponent("Id=");
      return (
        <td>
          <div>
            <Link className='ms-Icon ms-Icon--Preview maIcons' href={viewLink + props.dataItem.id} title="View Alert"></Link>
            {this.state.isUserAdmin ? <Link className='ms-Icon ms-Icon--Edit maIcons' href={editLink + props.dataItem.id} title="Edit Alert"></Link> : null}
            {this.state.isUserAdmin ? <Link className='ms-Icon ms-Icon--Delete maIcons' onClick={() => this.onIconClick(AlertIconType.Delete, props.dataItem)} title="Delete Alert"></Link> : null}
          </div>
        </td>
      );
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > showIcons');
    }
  }

  private _sortChange = (event) => {
    try {
      this.setState({
        sort: event.sort
      }, () => {
        this.createDataState({
          take: this.state.take,
          skip: this.state.skip,
          sort: this.state.sort
        });
      });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageAlerts > _sortChange');
    }
  }

  private getDistinctAuthors(): void {
    try {
      let arrAuthors: any[] = [];
      arrAuthors = [...new Set(this.state.allAlerts.map(x => x.author))];
      arrAuthors.sort();

      let arrAuthorObj: any[] = [];
      arrAuthors.map((item) => {
        if (item)
          arrAuthorObj.push({ key: item, text: item });
      });
      this.setState({ alertAuthorOptions: arrAuthorObj });

    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > getDistinctAuthors');
    }
  }

  private dataStateChange = (event) => {
    this.createDataState(event.data);
  }

  private createDataState(dataState: any) {
    try {
      if (this.state)
        this.setState({ result: process(this.state.allAlerts.slice(0), dataState), dataState: dataState });
    } catch (error) {
      LoggerService.errorLog(error, 'ManageSubmitRIforApproval > createDataState');
    }
  }
}
