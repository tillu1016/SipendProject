/* tslint:disable */
require("./ManageSubmitRIforApproval.module.css");
const styles = {
  manageAlerts: 'manageAlerts_b40b7fc5',
  container: 'container_b40b7fc5',
  row: 'row_b40b7fc5',
  column: 'column_b40b7fc5',
  'ms-Grid': 'ms-Grid_b40b7fc5',
  title: 'title_b40b7fc5',
  subTitle: 'subTitle_b40b7fc5',
  description: 'description_b40b7fc5',
  button: 'button_b40b7fc5',
  label: 'label_b40b7fc5'
};

export default styles;
/* tslint:enable */