import { INotification } from "../../../models/INotification";
import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IManageSubmitRIforApprovalProps {
  description: string;
  webURL: string;
  onSetNotification: (notification: INotification) => void;
  context: WebPartContext;
}
