declare interface IAboutUsOurNetworkWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AboutUsOurNetworkWebPartStrings' {
  const strings: IAboutUsOurNetworkWebPartStrings;
  export = strings;
}
