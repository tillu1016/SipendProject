import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IAboutUsOurNetworkProps {
  context: WebPartContext;
  webURL: string;
}
