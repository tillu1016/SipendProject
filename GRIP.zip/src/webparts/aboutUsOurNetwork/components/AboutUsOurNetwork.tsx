import * as React from 'react';
import styles from './AboutUsOurNetwork.module.scss';
import { IAboutUsOurNetworkProps } from './IAboutUsOurNetworkProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { Common } from '../../../common/common';
import { ConfigType, ConfigKey, IConfiguration } from '../../../models/IConfiguration';
import { LoggerService } from '../../../services/LoggerService';
import { ListService } from '../../../services/ListService';
import { TooltipHost, Link } from '@fluentui/react';
import { PageName } from '../../../models/IAlertAnalytics';
import { CurrentUser } from '@pnp/sp/src/siteusers';

interface AboutUsOurNetworkState {
  ourNetworkData: any;
}

export default class AboutUsOurNetwork extends React.Component<IAboutUsOurNetworkProps, AboutUsOurNetworkState> {
  private _configData: IConfiguration[] = [];

  constructor(props) {
    super(props);
    this.state = {
      ourNetworkData: []
    };
  }

  public componentDidMount() {
    try {
      Common.getConfigData().then(resp => {
        if (resp) {
          this._configData = resp;
          Common.errorLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.ErrorLog);
          Common.auditLogList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AuditLog);
          let adminGrpName: string = Common.getConfigValue(resp, ConfigType.Roles, ConfigKey.Administrator);
          let currUser: CurrentUser;

          this.getOurNetworkData();

          Common.getCurrentUserId().then((curUser: CurrentUser) => {
            currUser = curUser;
            Common.checkIfUserAdmin(adminGrpName).then(isUsrAdm => {
              let AlertAnalyticsList = Common.getConfigValue(resp, ConfigType.Lists, ConfigKey.AlertAnalytics);
              Common.logSiteVisit(AlertAnalyticsList, PageName.AboutUs, isUsrAdm, currUser["Id"], null);
            });
          });

        }
      })
        .catch(error => {
          LoggerService.errorLog(error, 'AboutUsVisionMission > componentDidMount > getConfigData');
        });
    } catch (error) {
      LoggerService.errorLog(error, 'AboutUsOurNetwork > componentDidMount');
    }
  }

  public render(): React.ReactElement<IAboutUsOurNetworkProps> {
    return (
      <div className={styles.aboutUsOurNetwork}>
        <div className="our_network">
          <h3>Our Network / Presence</h3>
          <div className="our_network_images">
            {this.state.ourNetworkData.map(item =>
              <TooltipHost
                content={item.Introduction}
                id={"titleTooltip_" + item.Id}
                calloutProps={{ gapSpace: 0 }}
                styles={{ root: { display: 'inline-block' } }}
              >
                <div className="our_network_item" aria-describedby={"titleTooltip_" + item.Id}>
                  <Link href={item.Link.Url} target="_blank">
                    <img src={item.FileRef} /></Link>
                </div>
              </TooltipHost>
            )}
          </div>
        </div>
      </div>
    );
  }

  private getOurNetworkData = (): void => {
    try {
      let ourNetworkList = Common.getConfigValue(this._configData, ConfigType.Lists, ConfigKey.OurNetwork);
      ListService.GetDataBySelect(ourNetworkList, '*, Introduction, Link, Id, FileLeafRef, FileRef').then(data => {
        if (data) {
          this.setState({ ourNetworkData: data });
        }
      }).catch(error => {
        LoggerService.errorLog(error, 'AboutUsOurNetwork > getOurNetworkData > GetAllData');
      });
    } catch (error) {
      LoggerService.errorLog(error, 'AboutUsOurNetwork > getOurNetworkData');
    }
  }
}
