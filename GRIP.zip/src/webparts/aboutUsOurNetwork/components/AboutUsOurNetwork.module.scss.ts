/* tslint:disable */
require("./AboutUsOurNetwork.module.css");
const styles = {
  aboutUsOurNetwork: 'aboutUsOurNetwork_1533333e',
  container: 'container_1533333e',
  row: 'row_1533333e',
  column: 'column_1533333e',
  'ms-Grid': 'ms-Grid_1533333e',
  title: 'title_1533333e',
  subTitle: 'subTitle_1533333e',
  description: 'description_1533333e',
  button: 'button_1533333e',
  label: 'label_1533333e'
};

export default styles;
/* tslint:enable */