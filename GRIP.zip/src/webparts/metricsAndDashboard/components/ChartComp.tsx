import 'core-js/es7/map';
import 'core-js/es6/array';
import 'core-js/fn/string/includes';
import 'core-js/fn/array/entries';
import 'core-js/fn/array/virtual/entries';
import 'core-js/fn/object/entries';
import * as React from 'react';
import { ListService } from '../../../services/ListService';
import { LoggerService } from '../../../services/LoggerService';
import { Common } from '../../../common/common';
import { ConfigType, ConfigKey, IConfiguration } from '../../../models/IConfiguration';
import * as moment from 'moment-timezone';
import '@progress/kendo-theme-default/dist/all.css';
import '@progress/kendo-react-charts';
import '@progress/kendo-react-popup';
import '@progress/kendo-react-inputs';
import '@progress/kendo-react-intl';
import '@progress/kendo-data-query';
import '@progress/kendo-drawing';
import '@progress/kendo-file-saver';
import { Chart, ChartLegend, ChartSeries, ChartSeriesItem, ChartCategoryAxis, ChartCategoryAxisItem, ChartCategoryAxisTitle, ChartSeriesLabels } from '@progress/kendo-react-charts';
import { Label, Stack, PivotItem, Pivot, Dropdown, Link, PrimaryButton, Panel, PanelType, IStackStyles, IStackItemStyles, DefaultButton, Dialog, DialogType, DialogFooter, MessageBar, MessageBarType, ProgressIndicator, TextField, IFocusTrapZoneProps, SpinnerSize, Spinner } from '@fluentui/react';
import MetricsAndDashboard from './MetricsAndDashboard';
import { DateRangeType, CategoryType } from '../../../models/IMetricsDashboard';
import { Grid, GridCellProps, GridColumn } from '@progress/kendo-react-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import { PDFExport, savePDF } from "@progress/kendo-react-pdf";
import { ExcelExport } from "@progress/kendo-react-excel-export";
import { sp } from '@pnp/sp';
import { PageName } from '../../../models/IAlertAnalytics';
import ReactHtmlParser from 'react-html-parser';
import BlockUIComp from '../../../common/BlockUIComp';
import { ColumnMenu, ColumnMenuCheckboxFilter } from '../../../common/ColumnMenu';
import { Tooltip } from '@progress/kendo-react-tooltip';
import { GridColumnCell } from '../../../common/GridColumnComp';
import { GridColumnTitleLink } from '../../../common/GridColumnTitleLinkComp';

import { AlertStatus } from '../../../models/IAlert';

import * as tinymce from 'tinymce';
import 'tinymce/plugins/advlist';
import 'tinymce/plugins/autoresize';
import 'tinymce/plugins/code';
import 'tinymce/plugins/fullscreen';
import 'tinymce/plugins/hr';
import 'tinymce/plugins/imagetools';
import 'tinymce/plugins/paste';
import 'tinymce/plugins/searchreplace';
import 'tinymce/plugins/template';
import 'tinymce/plugins/textcolor';
import 'tinymce/plugins/print';
import 'tinymce/plugins/preview';
import 'tinymce/plugins/table';
import 'tinymce/plugins/pagebreak';
import 'tinymce/plugins/hr';
import 'tinymce/plugins/insertdatetime';
require('tinymceImage');
require('tinymceLink');
require('tinymceLists');

import { Editor } from "@tinymce/tinymce-react";
import { WebPartContext } from "@microsoft/sp-webpart-base";


const stackStyles: IStackStyles = {
    root: {
        padding: 10,
        margin: 10
    }
};
const stackItemStyles: IStackItemStyles = {
    root: {
        padding: 5
    }
};

const focusTrapZoneProps: IFocusTrapZoneProps = {
    forceFocusInsideTrap: false
};


interface ChartCompState {
    pcRegionSeries: any[]; pcTASeries: any[]; pcRegTopicSeries: any[]; pcDocTypeSeries: any[]; filteredData: any[];
    yearChartSeriesItemColl: any; yearCategories: any; selByCategory: string; selByCategoryText: string; sort: any[]; skip: number; take: number; filter: any;
    listViewData: any[]; gridSubData: any[]; subSort: any[]; subSkip: number; subTake: number; subFilter: any; pcSubSeries: any[];
    subEmails: string; pcSubCatRegionSeries: any[]; pcSubCatTASeries: any[]; pcSubCatRegTopicSeries: any[]; analyticsGridData: any[];
    hideLoadingDialog: boolean; loadingText: string; result: any; dataState: any; pageable: any; subResult: any; subDataState: any;
    subPageable: any; isShowEMailAllPanel: boolean; disableEMailAllSubmitBtn: boolean; eMailAllSubsData: any; hideUploadDialog: boolean;
    showUploadMsg: string; disableUploadButton: boolean; showErrorMessage: boolean; hideSubscrLoadingDialog: boolean;
}

interface ChartCompProps {
    webURL: string;
    chartData: any;
    allAlerts: any[];
    allSubscriptions: any[];
    configData: IConfiguration[];
    context: WebPartContext;
}

const labelContent = (props) => {
    let formatedNumber = Number(props.dataItem.value).toLocaleString(undefined, { minimumFractionDigits: 0 });
    let data = `${props.dataItem.category} ${formatedNumber}`;

    let tmpArray = data.split(" ");
    if (tmpArray.length > 3) {
        let finalData = tmpArray[0];
        for (let index = 1; index < tmpArray.length; index++) {
            index % 2 == 0 ? finalData = finalData.concat('\n', tmpArray[index]) : finalData = finalData.concat(' ', tmpArray[index]);
        }
        data = finalData;
    }

    return data;
};

export default class ChartComp extends React.Component<ChartCompProps, ChartCompState>{

    private _yearByCategoryOptions: any[] = [];
    private _filterCategory: any[] = [];
    private _filterCatField: string = "";
    public _pdfContainer;
    public _alertGridExcelExport;
    public _visitsGridExcelExport;
    public _subscriptionGridExcelExport;
    public _emailLink;
    private _filteredAnalytics: any[] = [];
    private alertsColMenuCBFilter = (props) => <ColumnMenuCheckboxFilter {...props} data={this.state.listViewData} />;
    private subsColMenuCBFilter = (props) => <ColumnMenuCheckboxFilter {...props} data={this.state.gridSubData} />;

    private _loadedRegionSeries: boolean = false;
    private _loadedTASeries: boolean = false;
    private _loadedRegTopicSeries: boolean = false;
    private _loadedDocTypeSeries: boolean = false;

    private _loadedDateRangeSeries: boolean = false;

    private _loadedListViewData: boolean = false;

    private _loadedSubsGridData: boolean = false;
    private _loadedSubRegionSeries: boolean = false;
    private _loadedSubTASeries: boolean = false;
    private _loadedSubRegTopicSeries: boolean = false;
    private _loadedPageVisits: boolean = false;

    private _imgUploadPath: string = "";
    private _docUploadPath: string = "";
    private _uploadedFile: any;



    public DayPickerStrings: any = {
        months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
        shortDays: ['S', 'M', 'T', 'W', 'T', 'F', 'S'],
        quarter: ['Quarter 1', 'Quarter 2', 'Quarter 3', 'Quarter 4'],
        shortQuarter: ['Q1', 'Q2', 'Q3', 'Q4']
    };

    constructor(props) {
        super(props);

        tinymce.init({

        });

        this.createDataStateAlerts({
            take: Common.pageSize,
            skip: 0,
            sort: [{ field: 'publicationDate', dir: 'desc' }]
        });

        this.createDataStateSubs({
            take: 5, //Common.pageSize,
            skip: 0,
            sort: [{ field: 'created', dir: 'asc' }]
        });

        this.state = {
            pcRegionSeries: [], pcTASeries: [], pcRegTopicSeries: [], pcDocTypeSeries: [], filteredData: [],
            yearChartSeriesItemColl: [], yearCategories: [], selByCategory: '', selByCategoryText: '',
            isShowEMailAllPanel: false, disableEMailAllSubmitBtn: true,
            eMailAllSubsData: {
                subject: "",
                body: ""
            },
            sort: [
                { field: 'publicationDate', dir: 'desc' }
            ],
            filter: {
                logic: "and",
                filters: []
            }, skip: 0, take: Common.pageSize,
            listViewData: [],
            gridSubData: [],
            subSort: [
                { field: 'created', dir: 'desc' }
            ],
            subFilter: {
                logic: "and",
                filters: []
            }, subSkip: 0, subTake: Common.pageSize,
            pcSubSeries: [], subEmails: "", pcSubCatRegionSeries: [], pcSubCatTASeries: [], pcSubCatRegTopicSeries: [], analyticsGridData: [],
            hideLoadingDialog: false, hideSubscrLoadingDialog: false, loadingText: "Please Wait...", result: [], dataState: [],
            pageable: {
                buttonCount: 5,
                info: true,
                type: 'numeric',
                pageSizes: [50, 100, 200],
                previousNext: true
            }, subResult: [], subDataState: [],
            subPageable: {
                buttonCount: 5,
                info: true,
                type: 'numeric',
                pageSizes: [50, 100, 200],
                previousNext: true
            },
            hideUploadDialog: true,
            disableUploadButton: true,
            showUploadMsg: "",
            showErrorMessage: false
        };
    }

    public componentDidUpdate(prevProps: ChartCompProps) {

        try {
            if (prevProps.chartData !== this.props.chartData && this.props.chartData) {
                this.setState({ hideLoadingDialog: false }, () => {
                    this._loadedRegionSeries = false; this._loadedTASeries = false; this._loadedRegTopicSeries = false;
                    this._loadedDocTypeSeries = false; this._loadedDateRangeSeries = false; this._loadedListViewData = false;

                    this.getFilteredAlertsData();

                    let isDateModified = this.isDateFiltersModified(prevProps, this.props);

                    if (isDateModified) {
                        this._loadedSubsGridData = false; this._loadedSubRegionSeries = false; this._loadedSubTASeries = false;
                        this._loadedSubRegTopicSeries = false; this._loadedPageVisits = false;

                        this.setState({ hideSubscrLoadingDialog: false });
                        this.getfilterSubscriptionData();
                        this.filterAnalyticsData();
                    }
                });
            }


        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > componentDidUpdate');
        }

    }

    public componentDidMount() {


        try {

            this._yearByCategoryOptions = [{ key: CategoryType.Region, text: "By Region" }, { key: CategoryType.TherapeuticArea, text: "By Therapeutic Area" },
            { key: CategoryType.RegulatoryTopic, text: "By Regulatory Topic" }, { key: CategoryType.DocumentType, text: "By Document Type" },
            { key: CategoryType.Author, text: "By Author" }];
            this.setState({ selByCategory: CategoryType.Region, selByCategoryText: 'By Region' });

            Common.pageSize = Number.parseInt(Common.getConfigValue(this.props.configData, ConfigType.Grid, ConfigKey.PageSize));
            this.setState({ take: Common.pageSize, subTake: Common.pageSize });


            this._imgUploadPath = Common.getConfigValue(this.props.configData, ConfigType.Lists, ConfigKey.ImageUploadPath);
            this._docUploadPath = Common.getConfigValue(this.props.configData, ConfigType.Lists, ConfigKey.DocUploadPath);

            ListService.addFolder(this._imgUploadPath, new Date().getFullYear().toString());
            ListService.addFolder(this._docUploadPath, new Date().getFullYear().toString());


            this.getFilteredAlertsData();
            this.getfilterSubscriptionData();
            this.filterAnalyticsData();


        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > componentDidMount');
        }

    }

    public render(): JSX.Element {
        return (
            <div className="chartContainer">
                <Stack>
                    <Stack.Item>
                        <PrimaryButton className="md_button" text="Export to PDF" onClick={this.onExportToPDFClick.bind(this)} />
                    </Stack.Item>
                    <Stack.Item>
                        <Pivot>
                            <PivotItem headerText='Alerts By Category' itemKey='category' >
                                <div className="tab_cont">
                                    <div className="topPieCharts">
                                        <Label className="mdLabel">Region</Label>
                                        <Chart style={{ height: 380 }}>
                                            <ChartLegend visible={false} />
                                            <ChartSeries>
                                                <ChartSeriesItem type="pie" data={this.state.pcRegionSeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                            </ChartSeries>
                                        </Chart>
                                    </div>
                                    <div className="topPieCharts">
                                        <Label className="mdLabel">Therapeutic Area</Label>
                                        <Chart style={{ height: 380 }}>
                                            <ChartLegend visible={false} />
                                            <ChartSeries>
                                                <ChartSeriesItem type="pie" data={this.state.pcTASeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                            </ChartSeries>
                                        </Chart>
                                    </div>

                                    <div className="topPieCharts">
                                        <Label className="mdLabel">Regulatory Topic</Label>
                                        <Chart style={{ height: 380 }}>
                                            <ChartLegend visible={false} />
                                            <ChartSeries>
                                                <ChartSeriesItem type="pie" data={this.state.pcRegTopicSeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                            </ChartSeries>
                                        </Chart>
                                    </div>
                                    <div className="topPieCharts">
                                        <Label className="mdLabel">Document Type</Label>
                                        <Chart style={{ height: 380 }}>
                                            <ChartLegend visible={false} />
                                            <ChartSeries>
                                                <ChartSeriesItem type="pie" data={this.state.pcDocTypeSeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                            </ChartSeries>
                                        </Chart>
                                    </div>
                                </div>
                            </PivotItem>
                            <PivotItem headerText='Alerts List View' itemKey='listView' >
                                <div className="tab_cont">
                                    <PrimaryButton className="md_button" text="Export to Excel" onClick={this.onExportToExcelClick.bind(this, "Alert List View")} />
                                    <ExcelExport
                                        data={orderBy(this.state.listViewData, this.state.sort)}
                                        fileName={"Alert List View.xlsx"}
                                        ref={excelExport => (this._alertGridExcelExport = excelExport)}
                                    >
                                        <Tooltip openDelay={100} position="auto" anchorElement="element">
                                            <Grid
                                                style={{ height: '600px' }}
                                                data={this.state.result.length > 0 ?
                                                    orderBy(this.state.result.data, this.state.sort) :
                                                    this.state.result}
                                                {...this.state.dataState}
                                                onDataStateChange={this.dataStateChangeAlerts}
                                                total={this.state.result.total}
                                                pageable={this.state.pageable}
                                                sortable
                                                sort={this.state.sort}
                                                reorderable={true}
                                                resizable
                                                onSortChange={(e) => { this._sortChange(e); }}
                                            >
                                                <GridColumn field="title" title="Title" width="280px" filter={'text'} columnMenu={ColumnMenu} cell={GridColumnTitleLink}></GridColumn>
                                                <GridColumn field="region" title="Region" width="150px" cell={GridColumnCell}></GridColumn>
                                                <GridColumn field="therapeuticArea" title="Therapeutic Area" width="200px" cell={GridColumnCell}></GridColumn>
                                                <GridColumn field="regulatoryTopic" title="Regulatory Topic" width="250px" cell={GridColumnCell}></GridColumn>
                                                <GridColumn field="documentType" title="Document Type" width="200px" cell={GridColumnCell}></GridColumn>
                                                <GridColumn field="publicationDate" title="Publication Date" width="150px" format="{0:MMM dd, yyyy}" filter={'date'} columnMenu={ColumnMenu}></GridColumn>
                                                <GridColumn field="author" title="Author" width="100px" cell={GridColumnCell}></GridColumn>
                                                <GridColumn field="totalVisits" title="Number of Visits" width="100px" filter={'numeric'} columnMenu={ColumnMenu}></GridColumn>
                                                <GridColumn field="firstVisit" title="New Users" width="100px" filter={'numeric'} columnMenu={ColumnMenu}></GridColumn>
                                            </Grid>
                                        </Tooltip>
                                    </ExcelExport>
                                </div>
                            </PivotItem>
                            <PivotItem headerText='Alerts Comparison' itemKey='comparison'>
                                <div className="tab_cont">
                                    <div className="byCatContainerRight">
                                        <Dropdown
                                            className="byCategoryDDL"
                                            placeholder="Select an option"
                                            options={this._yearByCategoryOptions}
                                            onChange={this._onDDLByCategoryChange.bind(this)}
                                            selectedKey={this.state.selByCategory}
                                        />
                                    </div>
                                    <Chart>
                                        <ChartCategoryAxis>
                                            <ChartCategoryAxisItem labels={{ format: 'd', rotation: 'auto' }} categories={this.state.yearCategories}>
                                                <ChartCategoryAxisTitle text={this._yearByCategoryOptions.length > 0 ?
                                                    this._yearByCategoryOptions.filter(x => { return x.key == this.state.selByCategory; })[0].text :
                                                    null} />
                                            </ChartCategoryAxisItem>
                                        </ChartCategoryAxis>
                                        <ChartLegend position="top" orientation="horizontal" />
                                        <ChartSeries>
                                            {
                                                this.state.yearChartSeriesItemColl.map(item =>
                                                    <ChartSeriesItem type="column" data={item.data} name={item.name}><ChartSeriesLabels format="0" /></ChartSeriesItem>
                                                )
                                            }
                                        </ChartSeries>
                                    </Chart>
                                </div>
                            </PivotItem>
                            <PivotItem headerText='GRIP Analytics' itemKey='noofVisits' >
                                <div className="tab_cont">
                                    <PrimaryButton className="md_button" text="Export to Excel" onClick={this.onExportToExcelClick.bind(this, "Number of Visits")} />
                                    <ExcelExport
                                        data={this.state.analyticsGridData}
                                        fileName={"Number of Visits.xlsx"}
                                        ref={excelExport => (this._visitsGridExcelExport = excelExport)}
                                    >
                                        <Grid
                                            style={{ height: '600px' }}
                                            data={this.state.analyticsGridData}
                                            resizable
                                        >
                                            <GridColumn field="title" title="Page" width="280px"></GridColumn>
                                            <GridColumn field="totalVisits" title="Number of Visits" width="150px"></GridColumn>
                                            <GridColumn field="firstVisit" title="New Users" width="150px"></GridColumn>
                                        </Grid>
                                    </ExcelExport>
                                </div>
                            </PivotItem>
                            <PivotItem headerText='Subscriptions' itemKey='subscription'>
                                {(this.state.hideSubscrLoadingDialog) ?

                                    <div className="tab_cont">
                                        <div>
                                            <PrimaryButton className="md_button" text="Export to Excel" onClick={this.onExportToExcelClick.bind(this, 'Subscriptions')} />
                                            <PrimaryButton className="md_button" text="Email All" onClick={this.onEmailAllClick.bind(this)} />
                                        </div>
                                        <div className="subListView">
                                            <ExcelExport
                                                data={orderBy(this.state.gridSubData, this.state.subSort)}
                                                fileName={"Subscriptions List View.xlsx"}
                                                ref={excelExport => (this._subscriptionGridExcelExport = excelExport)}
                                            >
                                                <Grid
                                                    style={{ height: '600px' }}
                                                    data={this.state.subResult.length > 0 ?
                                                        orderBy(this.state.subResult.data, this.state.subSort) :
                                                        this.state.subResult}
                                                    {...this.state.subDataState}
                                                    onDataStateChange={this.dataStateChangeSubs}
                                                    total={this.state.subResult.total}
                                                    pageable={this.state.subPageable}
                                                    sortable
                                                    sort={this.state.subSort}
                                                    reorderable={true}
                                                    resizable
                                                    onSortChange={(e) => { this._subSortChange(e); }}
                                                >
                                                    <GridColumn field="title" title="Subscriber" width="350px" filter="text" columnMenu={this.subsColMenuCBFilter}></GridColumn>
                                                    <GridColumn field="office" title="Location" width="200px" filter="text" columnMenu={this.subsColMenuCBFilter}></GridColumn>
                                                    <GridColumn field="created" title="Date Subscribed" width="150px" format="{0:MMM dd, yyyy}" filter={'date'} columnMenu={ColumnMenu}></GridColumn>
                                                </Grid>
                                            </ExcelExport>
                                        </div>
                                        <div className="subChartView">
                                            <div className="subChartTitle">
                                                <Label className="mdLabel">Subscriptions By Frequency</Label>
                                            </div>

                                            <Chart style={{ height: 350 }}>
                                                <ChartLegend visible={true} />
                                                <ChartSeries>
                                                    <ChartSeriesItem type="pie" data={this.state.pcSubSeries} field="value"
                                                        categoryField="category" labels={{ visible: true, content: labelContent }} />
                                                </ChartSeries>
                                            </Chart>
                                        </div>
                                    </div>
                                    :
                                    <div className="subscriptionspincls"><Spinner className="subspinnercls" size={SpinnerSize.large} /></div>
                                }
                            </PivotItem>
                            <PivotItem headerText='Subscriptions By Category' itemKey='subByCat'>
                                {(this.state.hideSubscrLoadingDialog) ?
                                    <div className="tab_cont">
                                        <div className="subByCatPieCharts">
                                            <Label className="mdLabel">Region</Label>
                                            <Chart style={{ height: 350 }}>
                                                <ChartLegend visible={false} />
                                                <ChartSeries>
                                                    <ChartSeriesItem type="pie" data={this.state.pcSubCatRegionSeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                                </ChartSeries>
                                            </Chart>
                                        </div>
                                        <div className="subByCatPieCharts">
                                            <Label className="mdLabel">Therapeutic Area</Label>
                                            <Chart style={{ height: 350 }}>
                                                <ChartLegend visible={false} />
                                                <ChartSeries>
                                                    <ChartSeriesItem type="pie" data={this.state.pcSubCatTASeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                                </ChartSeries>
                                            </Chart>
                                        </div>
                                        <div className="subByCatPieCharts">
                                            <Label className="mdLabel">Regulatory Topic</Label>
                                            <Chart style={{ height: 350 }}>
                                                <ChartLegend visible={false} />
                                                <ChartSeries>
                                                    <ChartSeriesItem type="pie" data={this.state.pcSubCatRegTopicSeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                                </ChartSeries>
                                            </Chart>
                                        </div>
                                    </div>
                                    :
                                    <div className="subscriptionspincls"><Spinner className="subspinnercls" size={SpinnerSize.large} /></div>
                                }
                            </PivotItem>
                        </Pivot>
                    </Stack.Item>

                    <Stack.Item>
                        <Panel
                            isOpen={this.state.isShowEMailAllPanel}
                            onDismiss={this.closeEMailAllPanel.bind(this)}
                            closeButtonAriaLabel={"Close"}
                            hasCloseButton={true}
                            type={PanelType.large}
                            isBlocking={false}
                            focusTrapZoneProps={focusTrapZoneProps}
                        >
                            <Stack>
                                <Stack.Item>
                                    <Pivot selectedKey="gripalert">
                                        <PivotItem headerText={'Email All Subscribers'} itemKey='gripalert'>

                                            <Stack.Item styles={stackItemStyles}>
                                                <Label>To</Label>
                                                <Label>All Subscriber(s)</Label>
                                            </Stack.Item>

                                            <Stack.Item className="edit_signup" styles={stackItemStyles}>
                                                <TextField
                                                    label="Subject"
                                                    value={this.state.eMailAllSubsData.subject}
                                                    onChange={this.onSubjectTextChanged.bind(this)}
                                                    required={true}
                                                />

                                            </Stack.Item>

                                            <Stack.Item styles={stackItemStyles}>
                                                <Label className="aeLabel">Body <span className="requiredlbl"> *</span></Label>
                                                <Editor
                                                    value={this.state.eMailAllSubsData.body}
                                                    init={{
                                                        height: 500,
                                                        menubar: true,
                                                        plugins: [
                                                            'advlist lists link image print preview',
                                                            'searchreplace code fullscreen',
                                                            'insertdatetime table paste code, contextmenu'
                                                            //'table'
                                                        ],
                                                        toolbar: ['undo redo | bold italic underline strikethrough | formatselect | alignleft aligncenter alignright alignjustify | \
                  outdent indent |  numlist bullist | forecolor backcolor removeformat | hr | table insertfile image uploadDoc link | \
                  preview print | cut copy paste pastetext selectall'],
                                                        toolbar_sticky: true,
                                                        toolbar_drawer: 'sliding',
                                                        contextmenu: "copy paste | link | table",
                                                        image_advtab: false,
                                                        image_caption: false,
                                                        image_title: true,
                                                        automatic_uploads: true,
                                                        convert_urls: false,
                                                        branding: false,
                                                        images_upload_handler: (blobInfo, success, failure) => {
                                                            let file: any = blobInfo.blob();
                                                            let uniqueFile = file.name.substr(0, file.name.lastIndexOf('.')) + "-" + new Date().getTime() +
                                                                file.name.substr(file.name.lastIndexOf('.'));
                                                            let yrFolder: string = new Date().getFullYear().toString();
                                                            ListService.AddFile(`${this.props.context.pageContext.web.serverRelativeUrl}/${this._imgUploadPath}/${yrFolder}`,
                                                                uniqueFile, file, true)
                                                                .then(result => {
                                                                    success(this.props.webURL + "/" + this._imgUploadPath + "/" + yrFolder + "/" + result.data["Name"]);
                                                                })
                                                                .catch((e) => {
                                                                    failure(e);
                                                                });
                                                        },
                                                        setup: (editor) => {
                                                            editor.ui.registry.addButton('uploadDoc', {
                                                                icon: 'upload',
                                                                tooltip: 'Upload Document',
                                                                onAction: () => {
                                                                    this.uploadDoc(editor);
                                                                }
                                                            });
                                                        }

                                                    }}
                                                    onEditorChange={this.onBodyEditorChange.bind(this)}
                                                />
                                            </Stack.Item>

                                            <Stack.Item className="edit_signup" styles={stackItemStyles}>
                                                <Dialog
                                                    hidden={this.state.hideUploadDialog}
                                                    onDismiss={this.closeUploadDialog.bind(this)}
                                                    dialogContentProps={{
                                                        type: DialogType.normal,
                                                        title: 'Upload Document',
                                                    }}
                                                    modalProps={{
                                                        isBlocking: true,
                                                        containerClassName: 'ms-dialogMainOverrideUpload'
                                                    }}
                                                >
                                                    {this.state.showUploadMsg !== "" ?
                                                        <Stack.Item className="error_mgs">
                                                            <MessageBar messageBarType={MessageBarType.error} isMultiline={false} onDismiss={() => {
                                                                this.setState({ ...this.state, showErrorMessage: false });
                                                            }}>
                                                                {this.state.showUploadMsg}
                                                            </MessageBar>
                                                        </Stack.Item> : null}
                                                    <Stack.Item>
                                                        <input type="file" id="file" name="file" onChange={(e) => this.validateFileName(e.target.files)}></input>
                                                    </Stack.Item>
                                                    <DialogFooter>
                                                        <PrimaryButton onClick={this._onUploadClick.bind(this)} text="Upload" disabled={this.state.disableUploadButton} />
                                                        <DefaultButton onClick={this.closeUploadDialog.bind(this)} text="Cancel" />
                                                    </DialogFooter>
                                                </Dialog>

                                            </Stack.Item>
                                        </PivotItem>
                                    </Pivot>
                                </Stack.Item>
                                <Stack.Item styles={stackItemStyles} className="btn_fixed_bottom">
                                    <Stack horizontal styles={stackStyles}>
                                        <DefaultButton className="gry_btn" text="Cancel" onClick={this.closeEMailAllPanel.bind(this)} disabled={false} />
                                        <PrimaryButton className="blu_btn mar_l" text="Submit"
                                            onClick={this.submitEMailAllPanel.bind(this)}
                                            disabled={this.state.disableEMailAllSubmitBtn} />

                                    </Stack>
                                </Stack.Item>

                            </Stack>
                        </Panel>
                    </Stack.Item>



                </Stack>

                <PDFExport>
                    <div className="pdf_main_div">
                        <div ref={(container) => (this._pdfContainer = container)}>
                            <div className="pdf_category wid100">
                                <span className="pdf_heading">Alert By Category</span>
                                <div>
                                    <div className="topPieCharts">
                                        <Label className="mdLabel">Region</Label>
                                        <Chart style={{ height: 350 }}>
                                            <ChartLegend visible={false} />
                                            <ChartSeries>
                                                <ChartSeriesItem type="pie" data={this.state.pcRegionSeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                            </ChartSeries>
                                        </Chart>
                                    </div>
                                    <div className="topPieCharts">
                                        <Label className="mdLabel">Therapeutic Area</Label>
                                        <Chart style={{ height: 350 }}>
                                            <ChartLegend visible={false} />
                                            <ChartSeries>
                                                <ChartSeriesItem type="pie" data={this.state.pcTASeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                            </ChartSeries>
                                        </Chart>
                                    </div>
                                </div>
                                <div>
                                    <div className="topPieCharts">
                                        <Label className="mdLabel">Regulatory Topic</Label>
                                        <Chart style={{ height: 350 }}>
                                            <ChartLegend visible={false} />
                                            <ChartSeries>
                                                <ChartSeriesItem type="pie" data={this.state.pcRegTopicSeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                            </ChartSeries>
                                        </Chart>
                                    </div>
                                    <div className="topPieCharts">
                                        <Label className="mdLabel">Document Type</Label>
                                        <Chart style={{ height: 350 }}>
                                            <ChartLegend visible={false} />
                                            <ChartSeries>
                                                <ChartSeriesItem type="pie" data={this.state.pcDocTypeSeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                            </ChartSeries>
                                        </Chart>
                                    </div>
                                </div>
                            </div>
                            <div className="pdf_comparison wid100">
                                <span className="pdf_heading">Alert Comparison</span>
                                <span className="pdf_comparison_category">Selected Category: {this.state.selByCategoryText}</span>
                                <Chart>
                                    <ChartCategoryAxis>
                                        <ChartCategoryAxisItem labels={{ format: 'd', rotation: 'auto' }} categories={this.state.yearCategories}>
                                            <ChartCategoryAxisTitle text={this._yearByCategoryOptions.length > 0 ?
                                                this._yearByCategoryOptions.filter(x => { return x.key == this.state.selByCategory; })[0].text :
                                                null} />
                                        </ChartCategoryAxisItem>
                                    </ChartCategoryAxis>
                                    <ChartLegend position="top" orientation="horizontal" />
                                    <ChartSeries>
                                        {
                                            this.state.yearChartSeriesItemColl.map(item =>
                                                <ChartSeriesItem type="column" data={item.data} name={item.name}><ChartSeriesLabels format="0" /></ChartSeriesItem>
                                            )
                                        }
                                    </ChartSeries>
                                </Chart>
                            </div>
                            <div className="pdf_subscription_category wid100">
                                <span className="pdf_heading">Subscriptions By Category</span>
                                <div className="subByCatPieCharts">
                                    <Label className="mdLabel">Region</Label>
                                    <Chart style={{ height: 350 }}>
                                        <ChartLegend visible={false} />
                                        <ChartSeries>
                                            <ChartSeriesItem type="pie" data={this.state.pcSubCatRegionSeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                        </ChartSeries>
                                    </Chart>
                                </div>
                                <div className="subByCatPieCharts">
                                    <Label className="mdLabel">Therapeutic Area</Label>
                                    <Chart style={{ height: 350 }}>
                                        <ChartLegend visible={false} />
                                        <ChartSeries>
                                            <ChartSeriesItem type="pie" data={this.state.pcSubCatTASeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                        </ChartSeries>
                                    </Chart>
                                </div>
                                <div className="subByCatPieCharts">
                                    <Label className="mdLabel">Regulatory Topic</Label>
                                    <Chart style={{ height: 350 }}>
                                        <ChartLegend visible={false} />
                                        <ChartSeries>
                                            <ChartSeriesItem type="pie" data={this.state.pcSubCatRegTopicSeries} field="value" categoryField="category" labels={{ visible: true, content: labelContent }} />
                                        </ChartSeries>
                                    </Chart>
                                </div>
                            </div>
                            <div className="pdf_subscription wid100">
                                <span className="pdf_heading">Subscriptions</span>
                                <div className="subChartView">
                                    <div className="subChartTitle">
                                        <Label className="mdLabel">Subscriptions By Frequency</Label>
                                    </div>

                                    <Chart style={{ height: 350 }}>
                                        <ChartLegend visible={true} />
                                        <ChartSeries>
                                            <ChartSeriesItem type="pie" data={this.state.pcSubSeries} field="value"
                                                categoryField="category" labels={{ visible: true, content: labelContent }} />
                                        </ChartSeries>
                                    </Chart>
                                </div>
                                <div className="subListView">
                                    <Grid
                                        data={orderBy(this.state.gridSubData, this.state.subSort)}
                                        pageable={false}
                                        sort={this.state.subSort}
                                    >
                                        <GridColumn field="title" title="Subscriber" width={this._setColumnWidth(50, 'pdf_subscription')} filter="text"></GridColumn>
                                        <GridColumn field="office" title="Location" width={this._setColumnWidth(28, 'pdf_subscription')} filter="text"></GridColumn>
                                        <GridColumn field="created" title="Date Subscribed" width={this._setColumnWidth(21, 'pdf_subscription')} format="{0:MMM dd, yyyy}"></GridColumn>
                                    </Grid>
                                </div>
                            </div>
                            <div className="pdf_numberofvisits wid100">
                                <span className="pdf_heading">Number of Visits</span>
                                <Grid
                                    data={this.state.analyticsGridData}
                                >
                                    <GridColumn field="title" title="Page" width={this._setColumnWidth(40, 'pdf_numberofvisits')}></GridColumn>
                                    <GridColumn field="totalVisits" title="Number of Visits" width={this._setColumnWidth(30, 'pdf_numberofvisits')}></GridColumn>
                                    <GridColumn field="firstVisit" title="New Users" width={this._setColumnWidth(30, 'pdf_numberofvisits')}></GridColumn>
                                </Grid>
                            </div>
                            <div className="pdf_listview wid100">
                                <span className="pdf_heading">Alert List View</span>
                                <Grid
                                    data={orderBy(this.state.listViewData, this.state.sort)
                                    }
                                    {...this.state.dataState}
                                    onDataStateChange={this.dataStateChangeAlerts}
                                    total={this.state.result.total}
                                    cellRender={this._cellRender.bind(this)}
                                >
                                    <GridColumn field="titleLink" title="Title" width={this._setColumnWidth(17, 'pdf_listview')} filter="text"></GridColumn>
                                    <GridColumn field="region" title="Region" width={this._setColumnWidth(10, 'pdf_listview')}></GridColumn>
                                    <GridColumn field="therapeuticArea" title="Therapeutic Area" width={this._setColumnWidth(15, 'pdf_listview')}></GridColumn>
                                    <GridColumn field="regulatoryTopic" title="Regulatory Topic" width={this._setColumnWidth(15, 'pdf_listview')}></GridColumn>
                                    <GridColumn field="documentType" title="Document Type" width={this._setColumnWidth(15, 'pdf_listview')}></GridColumn>
                                    <GridColumn field="publicationDate" title="Publication Date" width={this._setColumnWidth(10, 'pdf_listview')} format="{0:MMM dd, yyyy}"></GridColumn>
                                    <GridColumn field="author" title="Author" width={this._setColumnWidth(8, 'pdf_listview')}></GridColumn>
                                    <GridColumn field="totalVisits" title="Number of Visits" width={this._setColumnWidth(5, 'pdf_listview')}></GridColumn>
                                    <GridColumn field="firstVisit" title="New Users" width={this._setColumnWidth(5, 'pdf_listview')}></GridColumn>
                                </Grid>
                            </div>
                        </div>
                    </div>
                </PDFExport>
                <BlockUIComp hideLoadingDialog={this.state.hideLoadingDialog} loadingText={this.state.loadingText}></BlockUIComp>
            </div>
        );
    }

    public _setColumnWidth = (value, valueClass) => {
        let columnWidth = 0;
        let gridWidth = document.querySelector(`.${valueClass} .k-grid`) ? parseInt(document.querySelector(`.${valueClass} .k-grid`)['offsetWidth']) - 40 : 1000;
        let widthAvailable = gridWidth - 0;
        columnWidth = Math.round(value * widthAvailable / 100);
        return columnWidth;
    }

    private onExportToExcelClick = (type): void => {
        try {
            if (type == "Alert List View") {
                LoggerService.auditLog("Alert List View - Export to excel button clicked", 'ChartComp > onExportToExcelClick');
                this._exportExcelformatting(this._alertGridExcelExport, type);
            }
            else if (type == "Subscriptions") {
                LoggerService.auditLog("Subscription - Export to excel button clicked", 'ChartComp > onExportToExcelClick');
                this._exportExcelformatting(this._subscriptionGridExcelExport, type);
            }
            else if (type == "Number of Visits") {
                LoggerService.auditLog("Number of Visits - Export to excel button clicked", 'ChartComp > onExportToExcelClick');
                this._exportExcelformatting(this._visitsGridExcelExport, type);
            }
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > onExportToExcelClick');
        }
    }

    public _exportExcelformatting(component, type) {
        try {
            const options = component.workbookOptions();
            const rows = options.sheets[0].rows;

            let altIdx = 0;
            rows.forEach((row) => {
                if (row.type === 'data') {
                    //convert from html to plain text          
                    let re = /\&nbsp;/gi;
                    for (let index = 0; index < row.cells.length; index++) {
                        if (row.cells[index].value && typeof row.cells[index].value == "string") {
                            row.cells[index].value = row.cells[index].value.toString().replace(/<\/?[^>]+>/ig, "").replace(re, " ");
                        }
                    }

                    //Format the column
                    if (type == "Alert List View") {
                        if (row.cells[5].value && typeof row.cells[5].value == "object") {
                            row.cells[5].format = "MMM dd, yyyy";
                        }
                        //row.cells[0].value = row.cells[0].value.title + ", " + row.cells[0].value.link;
                    }
                    else if (type == "Subscriptions") {
                        if (row.cells[2].value && typeof row.cells[2].value == "object") {
                            row.cells[2].format = "MMM dd, yyyy";
                        }
                        //make the items for first column as bold
                        row.cells[0].bold = true;
                    }
                    else if (type == "Number of Visits") {
                        //make the items for first column as bold
                        row.cells[0].bold = true;
                    }

                    //for alternate row coloring
                    if (altIdx % 2 !== 0) {
                        row.cells.forEach((cell) => {
                            cell.background = '#aabbcc';
                        });
                    }

                    altIdx++;
                }
                else if (row.type === 'header' && row.cells.length > 1) {
                    row.cells.forEach((cell) => {
                        cell.bold = true;
                    });
                }
                else if (row.type === 'header' && row.cells.length <= 1) {

                }
            });
            component.save(options);
        }
        catch (exception) {
            LoggerService.errorLog(exception, "ChartComp > _exportExcelformatting");
        }
    }

    private onExportToPDFClick = (): void => {
        try {
            LoggerService.auditLog("Export to PDF button clicked", 'ChartComp > onExportToPDFClick');
            savePDF(this._pdfContainer, {
                paperSize: "auto",
                margin: 40,
                fileName: `Metrics-And-Dashboard.pdf`
            });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > onExportToPDFClick');
        }
    }

    private onEmailAllClick = (): void => {
        try {
            this.setState({
                isShowEMailAllPanel: true, disableEMailAllSubmitBtn: true,
                eMailAllSubsData: {
                    subject: "",
                    body: ""
                }
            });

        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > onEmailAllClick');
        }
    }
    private closeEMailAllPanel() {
        try {
            this.setState({
                isShowEMailAllPanel: false, disableEMailAllSubmitBtn: true
            });
        }
        catch (error) {
            LoggerService.errorLog(error, 'ChartComp > closeEMailAllPanel');
        }
    }

    private submitEMailAllPanel() {
        try {
            let subscribersEMailLogList = Common.getConfigValue(this.props.configData, ConfigType.Lists, ConfigKey.SubscribersEMailLog);
            let tmpObj: any = {
                SESubject: this.state.eMailAllSubsData.subject,
                SEBody: this.state.eMailAllSubsData.body,
                SEStatus: "Not Started"
            };

            this.setState({
                isShowEMailAllPanel: false, disableEMailAllSubmitBtn: true
            });

            ListService.PostListData(tmpObj, subscribersEMailLogList).then(result => {
            }).catch(error => {
                LoggerService.errorLog(error, 'ChartComp > submitEMailAllPanel');
            });

        }
        catch (error) {
            LoggerService.errorLog(error, 'ChartComp > submitEMailAllPanel');
        }
    }

    private onSubjectTextChanged = (ev: React.FormEvent<HTMLInputElement>, eMailSubject?: string) => {
        try {
            this.setState(prevState => ({
                eMailAllSubsData: {
                    ...prevState.eMailAllSubsData,
                    subject: eMailSubject
                }
            }), () => {
                this._validate();
            });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > onSubjectTextChanged');
        }
    }

    private _onUploadClick() {
        try {
            this.setState({ hideLoadingDialog: false }, () => {
                let uniqueFile = this._uploadedFile[0].name.substr(0, this._uploadedFile[0].name.lastIndexOf('.')) + "-" +
                    new Date().getTime() + this._uploadedFile[0].name.substr(this._uploadedFile[0].name.lastIndexOf('.'));
                let yrFolder: string = new Date().getFullYear().toString();
                ListService.AddFile(`${this.props.context.pageContext.web.serverRelativeUrl}/${this._docUploadPath}/${yrFolder}`,
                    uniqueFile, this._uploadedFile[0], true)
                    .then(result => {
                        //success();
                        let alBody = this.state.eMailAllSubsData.body + "<a href='" + this.props.webURL + "/" + this._docUploadPath + "/" + yrFolder + "/" +
                            result.data["Name"] + "'>" + this._uploadedFile[0].name + "</a>";

                        this.setState(prevState => ({
                            eMailAllSubsData: {
                                ...prevState.eMailAllSubsData,
                                body: alBody
                            },
                            hideUploadDialog: true, hideLoadingDialog: true, showUploadMsg: "", disableUploadButton: true

                        }));
                    })
                    .catch((e) => {
                        this.setState({ hideLoadingDialog: true, showUploadMsg: 'Unable to upload file!', disableUploadButton: true });
                    });
            });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > _onUploadClick');
            this.setState({ hideLoadingDialog: true, showUploadMsg: "Something went wrong. Please contact administrator!", disableUploadButton: true });
        }
    }

    private closeUploadDialog = (): void => {
        this._uploadedFile = '';
        this.setState({ hideUploadDialog: true, disableUploadButton: true });
    }
    private uploadDoc(editor) {
        try {
            this.setState({ hideUploadDialog: false });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > uploadDoc');
        }
    }

    private _validate() {
        try {
            let isDisableSubmit = true;
            if (this.state.eMailAllSubsData.subject !== "" && this.state.eMailAllSubsData.body !== "")
                isDisableSubmit = false;
            else
                isDisableSubmit = true;

            this.setState({ disableEMailAllSubmitBtn: isDisableSubmit });
        } catch (error) {
            LoggerService.errorLog(error, 'AddEditAlerts > _validate');
        }
    }


    private onBodyEditorChange = (e, editor?) => {
        try {
            var newText = "";
            if (editor)
                newText = editor.getContent();
            else
                newText = e.target.getContent();

            this.setState(prevState => ({
                eMailAllSubsData: {
                    ...prevState.eMailAllSubsData,
                    body: newText
                }
            }), () => {
                this._validate();
            });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > onBodyEditorChange');
        }
    }


    private validateFileName(file: any) {
        try {
            var pattern = /[/\\*:?#<>|"%&{}]/;
            let specialChar = pattern.test(file[0].name);
            if (specialChar)
                this.setState({
                    showUploadMsg: 'A file name cannot contain any of the following caracters / \ * : ? # < > | " % & { }',
                    disableUploadButton: true
                });
            else {
                this._uploadedFile = file;
                this.setState({ showUploadMsg: "", disableUploadButton: false });
            }
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > validateFileName');
        }
    }



    private _onDDLByCategoryChange = (event, value): void => {
        LoggerService.auditLog("Alert Comparison dropdown value changed to - " + value.text, 'ChartComp > _onDDLByCategoryChange');
        this.setState({ selByCategory: value.key, selByCategoryText: value.text }, () => this.getYearChartSeriesItems());
    }

    private _sortChange = (event) => {
        try {
            this.setState({
                sort: event.sort
            }, () => {
                this.createDataStateAlerts({
                    take: this.state.take,
                    skip: this.state.skip,
                    sort: this.state.sort
                });
            });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > _sortChange');
        }
    }

    private _subSortChange = (event) => {
        try {
            this.setState({
                subSort: event.sort
            }, () => {
                this.createDataStateSubs({
                    take: this.state.subTake,
                    skip: this.state.subSkip,
                    sort: this.state.subSort
                });
            });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > _subSortChange');
        }
    }

    private getRegionData = (): void => {
        try {
            let arrRegions: any[] = [];
            let arrAllRegions: any[] = [];
            this.state.filteredData.map(ele => ele["G2Region"].map(eles => arrAllRegions.push({ termGuid: eles["TermID"], label: eles["Label"] })));
            let unique = [];
            let distinct = [];
            arrAllRegions.map(reg => {
                if (!unique[reg.termGuid]) {
                    distinct.push({ termGuid: reg.termGuid, label: reg.label });
                    unique[reg.termGuid] = 1;
                }
            });

            let series: any[] = [];
            distinct.map(itm =>
                series.push({
                    'category': itm.label, 'value':
                        (this.state.filteredData.filter(item => {
                            let terms = item.G2Region.map(eles => eles["TermID"]).toString();
                            return terms.indexOf(itm.termGuid) >= 0;
                        })).length
                })
            );

            this.setState({ pcRegionSeries: series }, () => { this._loadedRegionSeries = true; this.hideLoading(); });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getRegionData');
        }
    }

    private getTAData = (): void => {
        try {
            let arrAllTAs: any[] = [];
            this.state.filteredData.map(ele => ele["G2TherapeuticArea"].map(eles => arrAllTAs.push({ termGuid: eles["TermID"], label: eles["Label"] })));
            let unique = [];
            let distinct = [];
            arrAllTAs.map(ta => {
                if (!unique[ta.termGuid]) {
                    distinct.push({ termGuid: ta.termGuid, label: ta.label });
                    unique[ta.termGuid] = 1;
                }
            });

            let series: any[] = [];
            distinct.map(itm =>
                series.push({
                    'category': itm.label, 'value':
                        (this.state.filteredData.filter(item => {
                            let terms = item.G2TherapeuticArea.map(eles => eles["TermID"]).toString();
                            return terms.indexOf(itm.termGuid) >= 0;
                        })).length
                })
            );
            this.setState({ pcTASeries: series }, () => { this._loadedTASeries = true; this.hideLoading(); });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getTAData');
        }
    }

    private getRegTopicData = (): void => {
        try {
            let arrRegions: any[] = [];
            let arrAllRegTopics: any[] = [];
            this.state.filteredData.map(ele => ele["G2RegulatoryTopic"].map(eles => arrAllRegTopics.push({ termGuid: eles["TermID"], label: eles["Label"] })));
            let unique = [];
            let distinct = [];
            arrAllRegTopics.map(regT => {
                if (!unique[regT.termGuid]) {
                    distinct.push({ termGuid: regT.termGuid, label: regT.label });
                    unique[regT.termGuid] = 1;
                }
            });

            let series: any[] = [];
            distinct.map(itm =>
                series.push({
                    'category': itm.label, 'value':
                        (this.state.filteredData.filter(item => {
                            let terms = item.G2RegulatoryTopic.map(eles => eles["TermID"]).toString();
                            return terms.indexOf(itm.termGuid) >= 0;
                        })).length
                })
            );
            this.setState({ pcRegTopicSeries: series }, () => { this._loadedRegTopicSeries = true; this.hideLoading(); });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getRegTopicData');
        }
    }

    private getDocTypeData = (): void => {
        try {
            let arrRegions: any[] = [];
            let arrAllRegions: any[] = [];
            this.state.filteredData.map(ele => ele["G2DocumentType"].map(eles => arrAllRegions.push({ termGuid: eles["TermID"], label: eles["Label"] })));
            let unique = [];
            let distinct = [];
            for (let i = 0; i < arrAllRegions.length; i++) {
                if (!unique[arrAllRegions[i].termGuid]) {
                    distinct.push({ termGuid: arrAllRegions[i].termGuid, label: arrAllRegions[i].label });
                    unique[arrAllRegions[i].termGuid] = 1;
                }
            }

            let series: any[] = [];
            distinct.map(itm =>
                series.push({
                    'category': itm.label, 'value':
                        (this.state.filteredData.filter(item => {
                            let terms = item.G2DocumentType.map(eles => eles["TermID"]).toString();
                            return terms.indexOf(itm.termGuid) >= 0;
                        })).length
                })
            );
            this.setState({ pcDocTypeSeries: series }, () => { this._loadedDocTypeSeries = true; this.hideLoading(); });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getDocTypeData');
        }
    }

    private getSubCatRegionData = (filtSubData: any[]): void => {
        try {
            let arrRegions: any[] = [];
            let arrAllRegions: any[] = [];
            filtSubData.map(ele => ele["G2Region"].map(eles => arrAllRegions.push({ termGuid: eles["TermGuid"], label: eles["Label"] })));
            let unique = [];
            let distinct = [];
            arrAllRegions.map(reg => {
                if (!unique[reg.termGuid]) {
                    distinct.push({ termGuid: reg.termGuid, label: reg.label });
                    unique[reg.termGuid] = 1;
                }
            });

            let series: any[] = [];
            distinct.map(itm =>
                series.push({
                    'category': itm.label, 'value':
                        (filtSubData.filter(item => {
                            let terms = item.G2Region.map(eles => eles["TermGuid"]).toString();
                            return terms.indexOf(itm.termGuid) >= 0;
                        })).length
                })
            );

            this.setState({ pcSubCatRegionSeries: series }, () => { this._loadedSubRegionSeries = true; this.hideSubscriptionLoader(); });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getSubCatRegionData');
        }
    }

    private getSubCaTAData = (filtSubData: any[]): void => {
        try {
            let arrAllTAs: any[] = [];
            filtSubData.map(ele => ele["G2TherapeuticArea"].map(eles => arrAllTAs.push({ termGuid: eles["TermGuid"], label: eles["Label"] })));
            let unique = [];
            let distinct = [];
            arrAllTAs.map(ta => {
                if (!unique[ta.termGuid]) {
                    distinct.push({ termGuid: ta.termGuid, label: ta.label });
                    unique[ta.termGuid] = 1;
                }
            });

            let series: any[] = [];
            distinct.map(itm =>
                series.push({
                    'category': itm.label, 'value':
                        (filtSubData.filter(item => {
                            let terms = item.G2TherapeuticArea.map(eles => eles["TermGuid"]).toString();
                            return terms.indexOf(itm.termGuid) >= 0;
                        })).length
                })
            );
            this.setState({ pcSubCatTASeries: series }, () => { this._loadedSubTASeries = true; this.hideSubscriptionLoader(); });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getSubCaTAData');
        }
    }

    private getSubCatRegTopicData = (filtSubData: any[]): void => {
        try {
            let arrRegions: any[] = [];
            let arrAllRegTopics: any[] = [];
            filtSubData.map(ele => ele["G2RegulatoryTopic"].map(eles => arrAllRegTopics.push({ termGuid: eles["TermGuid"], label: eles["Label"] })));
            let unique = [];
            let distinct = [];
            arrAllRegTopics.map(regT => {
                if (!unique[regT.termGuid]) {
                    distinct.push({ termGuid: regT.termGuid, label: regT.label });
                    unique[regT.termGuid] = 1;
                }
            });

            let series: any[] = [];
            distinct.map(itm =>
                series.push({
                    'category': itm.label, 'value':
                        (filtSubData.filter(item => {
                            let terms = item.G2RegulatoryTopic.map(eles => eles["TermGuid"]).toString();
                            return terms.indexOf(itm.termGuid) >= 0;
                        })).length
                })
            );
            this.setState({ pcSubCatRegTopicSeries: series }, () => { this._loadedSubRegTopicSeries = true; this.hideSubscriptionLoader(); });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getSubCatRegTopicData');
        }
    }

    private getFilteredAlertsData = (): void => {

        try {

            if (this.props.chartData) {

                let alertDBListName = Common.getConfigValue(this.props.configData, ConfigType.Lists, ConfigKey.AlertsDatabase);

                let camlQ: string = "";
                let createdcamlQ = `<And><Geq><FieldRef Name='ADBPublicationDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>startDateVal</Value></Geq>
              <Leq><FieldRef Name='ADBPublicationDate' /><Value IncludeTimeValue='FALSE' Type='DateTime'>endDateVal</Value></Leq></And>`;

                let datecamlQ = "";
                let regionQuery = "";
                let tAQuery = "";
                let rtopicQuery = "";
                let docTypeQuery = "";
                let authorQuery = "";

                let filtDateRange = DateRangeType.Quarter;
                let filtQuarter = [moment().quarter()];
                let filtYear = moment().year();

                if (this.props.chartData.filtDateRange)
                    filtDateRange = this.props.chartData.filtDateRange;

                if (this.props.chartData.filtQuarter)
                    filtQuarter = this.props.chartData.filtQuarter;

                if (this.props.chartData.filtYear)
                    filtYear = this.props.chartData.filtYear;



                switch (filtDateRange) {
                    case DateRangeType.DateRange:

                        datecamlQ = this.processDateValues(moment.tz(this.getGMTDateString(this.props.chartData.filtFromDate), "GMT").format(),
                            moment.tz(this.getGMTDateString(this.props.chartData.filtToDate), "GMT").format(), createdcamlQ);
                        break;
                    case DateRangeType.Year:

                        this.props.chartData.filtYear.map(yearVal => {
                            let tempDatecamlQ = this.processDateValues(moment.tz(this.getGMTDateString(moment(yearVal + '-01-01').toDate()), "GMT").format(),
                                moment.tz(this.getGMTDateString(moment(yearVal + '-12-31').toDate()), "GMT").format(), createdcamlQ);
                            datecamlQ = this.applyCAMLCondition("Or", datecamlQ, tempDatecamlQ);
                        });

                        break;
                    case DateRangeType.Quarter:

                        filtQuarter.map(qrt => {
                            let qrtDate = moment().year(filtYear).quarter(qrt).toDate();
                            let qrtSt = moment(qrtDate).quarter(qrt).startOf('quarter').toDate();
                            let qrtEnd = moment(qrtDate).quarter(qrt).endOf('quarter').toDate();
                            let tempDatecamlQ = this.processDateValues(moment.tz(this.getGMTDateString(qrtSt), "GMT").format(),
                                moment.tz(this.getGMTDateString(qrtEnd), "GMT").format(), createdcamlQ);
                            datecamlQ = this.applyCAMLCondition("Or", datecamlQ, tempDatecamlQ);
                        });

                        break;
                    case DateRangeType.Month:
                        this.props.chartData.filtMonth.map(mnth => {
                            let mnthDate = moment().year(this.props.chartData.filtYear).month(mnth).toDate();
                            let mnthSt = moment(mnthDate).month(mnth).startOf('month').toDate();
                            let mnthEnd = moment(mnthDate).month(mnth).endOf('month').toDate();
                            let tempDatecamlQ = this.processDateValues(moment.tz(this.getGMTDateString(mnthSt), "GMT").format(),
                                moment.tz(this.getGMTDateString(mnthEnd), "GMT").format(), createdcamlQ);
                            datecamlQ = this.applyCAMLCondition("Or", datecamlQ, tempDatecamlQ);
                        });

                        break;
                    default: break;
                }
                //Filter by Regions
                if (this.props.chartData.filtRegion && this.props.chartData.filtRegion.length > 0) {
                    this.props.chartData.filtRegion.map(eles => {
                        let tempQ = "<Eq><FieldRef Name='G2Region' /><Value Type='TaxonomyFieldTypeMulti'>" + eles["text"] + "</Value></Eq>";
                        regionQuery = this.applyCAMLCondition("Or", regionQuery, tempQ);
                    });

                }
                //Filter by TA
                if (this.props.chartData.filtTA && this.props.chartData.filtTA.length > 0) {
                    this.props.chartData.filtTA.map(eles => {
                        let tempQ = "<Eq><FieldRef Name='G2TherapeuticArea' /><Value Type='TaxonomyFieldTypeMulti'>" + eles["text"] + "</Value></Eq>";
                        tAQuery = this.applyCAMLCondition("Or", tAQuery, tempQ);
                    });
                }
                //Filter by Reg Topic
                if (this.props.chartData.filtRegTopic && this.props.chartData.filtRegTopic.length > 0) {
                    this.props.chartData.filtRegTopic.map(eles => {
                        let tempQ = "<Eq><FieldRef Name='G2RegulatoryTopic' /><Value Type='TaxonomyFieldTypeMulti'>" + eles["text"] + "</Value></Eq>";
                        rtopicQuery = this.applyCAMLCondition("Or", rtopicQuery, tempQ);
                    });

                }
                //Filter by Doc Type
                if (this.props.chartData.filtDocType && this.props.chartData.filtDocType.length > 0) {
                    this.props.chartData.filtDocType.map(eles => {
                        let tempQ = "<Eq><FieldRef Name='G2DocumentType' /><Value Type='TaxonomyFieldTypeMulti'>" + eles["text"] + "</Value></Eq>";
                        docTypeQuery = this.applyCAMLCondition("Or", docTypeQuery, tempQ);
                    });
                }
                //Filter by Author
                if (this.props.chartData.filtAuthor && this.props.chartData.filtAuthor.length > 0) {
                    this.props.chartData.filtAuthor.map(auth => {
                        let tempQ = "<Eq><FieldRef Name='ADBAuthor' LookupId='TRUE' /><Value Type='Lookup'>" + auth + "</Value></Eq>";
                        authorQuery = this.applyCAMLCondition("Or", authorQuery, tempQ);
                    });
                }

                camlQ = `<Eq><FieldRef Name='ADBStatus' /><Value Type='Text'>${AlertStatus.Publish}</Value></Eq>`;
                camlQ = this.processFilterValues(this.props.chartData.filtRegion, camlQ, regionQuery);
                camlQ = this.processFilterValues(this.props.chartData.filtTA, camlQ, tAQuery);
                camlQ = this.processFilterValues(this.props.chartData.filtRegTopic, camlQ, rtopicQuery);
                camlQ = this.processFilterValues(this.props.chartData.filtDocType, camlQ, docTypeQuery);
                camlQ = this.processFilterValues(this.props.chartData.filtAuthor, camlQ, authorQuery);
                camlQ = this.applyCAMLCondition("And", camlQ, datecamlQ);


                camlQ = `<View><Query>
                    <Where>${camlQ}</Where></Query>
                    <ViewFields><FieldRef Name='ID' /><FieldRef Name='Title' /><FieldRef Name='G2Region' /><FieldRef Name='G2DocumentType' /><FieldRef Name='G2RegulatoryTopic' />
                        <FieldRef Name='G2TherapeuticArea' /><FieldRef Name='ADBPublicationDate' /><FieldRef Name='ADBAuthor' /></ViewFields><RowLimit Paged="TRUE">4999</RowLimit>
                    <ExpandUserField>True</ExpandUserField></View>`;



                ListService.getDataFromLargeList(alertDBListName, camlQ).then(data => {
                    if (data) {

                        this.setState({ filteredData: data.Row }, () => {
                            this.getRegionData();
                            this.getTAData();
                            this.getRegTopicData();
                            this.getDocTypeData();

                            this.getYearChartSeriesItems();
                            this.getListViewData();
                        });

                    }
                }).catch(error => {
                    LoggerService.errorLog(error, 'ChartComp > getFilteredAlertsData');
                });


            }
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getFilteredAlertsData');
        }

    }

    private processFilterValues = (dataColl: any, totalQuery: string, filterQuery: string): string => {
        let finalQueryVal = "";
        try {
            finalQueryVal = totalQuery;
            if (dataColl && dataColl.length > 0)
                finalQueryVal = this.applyCAMLCondition("And", totalQuery, filterQuery);
            return finalQueryVal;

        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > processFilterValues');
        }
        return finalQueryVal;

    }

    private processDateValues = (startDate: string, endDate: string, createdcamlQ: string): string => {

        try {
            createdcamlQ = createdcamlQ.replace("startDateVal", startDate);
            createdcamlQ = createdcamlQ.replace("endDateVal", endDate);
            return createdcamlQ;
        }
        catch (error) {
            LoggerService.errorLog(error, 'ChartComp > processDateValues');
        }
        return createdcamlQ;
    }
    private applyCAMLCondition = (operator: string, query1: string, query2: string,): string => {
        let returnVal: string = "";
        try {
            if (query1 && query2) {
                if (operator.toLowerCase() == "and") {
                    returnVal = "<And>" + query1 + query2 + "</And>";
                }
                else if (operator.toLowerCase() == "or") {
                    returnVal = "<Or>" + query1 + query2 + "</Or>";
                }
            }
            else if (query1 == "" && query2 != "")
                returnVal = query2;

            else if (query1 != "" && query2 == "")
                returnVal = query1;
        }
        catch (error) {
            LoggerService.errorLog(error, 'ChartComp > applyCAMLCondition');
        }
        return returnVal;
    }

    private applyRestCondition = (operator: string, query1: string, query2: string,): string => {
        let returnVal: string = "";
        try {
            if (query1 && query2) {
                if (operator.toLowerCase() == "and") {
                    returnVal = "(" + query1 + " and " + query2 + ")";
                }
                else if (operator.toLowerCase() == "or") {
                    returnVal = "(" + query1 + " or " + query2 + ")";
                }
            }
            else if (query1 == "" && query2 != "")
                returnVal = query2;

            else if (query1 != "" && query2 == "")
                returnVal = query1;
        }
        catch (error) {
            LoggerService.errorLog(error, 'ChartComp > applyRestCondition');
        }
        return returnVal;
    }

    private getfilterSubscriptionData = (): void => {

        try {
            if (this.props.chartData) {
                let subListName = Common.getConfigValue(this.props.configData, ConfigType.Lists, ConfigKey.Subscriptions);
                let restQ = "";

                let createdRestQ = `((Created ge datetime'startDateVal') and (Created le datetime'endDateVal'))`;
                let dateRestQ = "";

                let filtDateRange = DateRangeType.Quarter;
                let filtQuarter = [moment().quarter()];
                let filtYear = moment().year();

                if (this.props.chartData.filtDateRange)
                    filtDateRange = this.props.chartData.filtDateRange;

                if (this.props.chartData.filtQuarter)
                    filtQuarter = this.props.chartData.filtQuarter;

                if (this.props.chartData.filtYear)
                    filtYear = this.props.chartData.filtYear;



                switch (filtDateRange) {
                    case DateRangeType.DateRange:

                        dateRestQ = this.processDateValues(moment.tz(this.getGMTDateString(this.props.chartData.filtFromDate), "GMT").format(),
                            moment.tz(this.getGMTDateString(this.props.chartData.filtToDate), "GMT").format(), createdRestQ);
                        break;
                    case DateRangeType.Year:

                        this.props.chartData.filtYear.map(yearVal => {
                            let tempDateRestQ = this.processDateValues(moment.tz(this.getGMTDateString(moment(yearVal + '-01-01').toDate()), "GMT").format(),
                                moment.tz(this.getGMTDateString(moment(yearVal + '-12-31').toDate()), "GMT").format(), createdRestQ);
                            dateRestQ = this.applyRestCondition("Or", dateRestQ, tempDateRestQ);
                        });
                        break;
                    case DateRangeType.Quarter:

                        filtQuarter.map(qrt => {
                            let qrtDate = moment().year(filtYear).quarter(qrt).toDate();
                            let qrtSt = moment(qrtDate).quarter(qrt).startOf('quarter').toDate();
                            let qrtEnd = moment(qrtDate).quarter(qrt).endOf('quarter').toDate();
                            let tempDateRestQ = this.processDateValues(moment.tz(this.getGMTDateString(qrtSt), "GMT").format(),
                                moment.tz(this.getGMTDateString(qrtEnd), "GMT").format(), createdRestQ);
                            dateRestQ = this.applyRestCondition("Or", dateRestQ, tempDateRestQ);
                        });

                        break;
                    case DateRangeType.Month:
                        this.props.chartData.filtMonth.map(mnth => {

                            let mnthDate = moment().year(this.props.chartData.filtYear).month(mnth).toDate();
                            let mnthSt = moment(mnthDate).month(mnth).startOf('month').toDate();
                            let mnthEnd = moment(mnthDate).month(mnth).endOf('month').toDate();

                            let tempDateRestQ = this.processDateValues(moment.tz(this.getGMTDateString(mnthSt), "GMT").format(),
                                moment.tz(this.getGMTDateString(mnthEnd), "GMT").format(), createdRestQ);
                            dateRestQ = this.applyRestCondition("Or", dateRestQ, tempDateRestQ);

                        });

                        break;
                    default: break;
                }

                let titleQ = `Title ne ''`;
                restQ = this.applyRestCondition("and", titleQ, dateRestQ);

                ListService.GetDataByFilterWithExpandTop(subListName, restQ,
                    'ASFrequency, G2Region, G2RegulatoryTopic, G2TherapeuticArea, Created, ASSubscriber/Id, ASSubscriber/Title, ASSubscriber/Office',
                    'ASSubscriber', 4999, 'ID', true).then(data => {
                        if (data) {
                            let arrFiltData = data;
                            //get distinct subscribers

                            let arrAllSubs: any[] = [];
                            arrFiltData.map(ele => {

                                arrAllSubs.push({
                                    id: ele.ASSubscriber["Id"], title: ele.ASSubscriber["Title"],
                                    created: ele["Created"], office: ele.ASSubscriber["Office"]
                                });
                            });
                            let uniqSub = [];
                            let distSub = [];
                            arrAllSubs.map(sub => {
                                if (!uniqSub[sub.id]) {
                                    distSub.push({ id: sub.id, title: sub.title, created: moment(sub.created).toDate(), office: sub.office });
                                    uniqSub[sub.id] = 1;
                                }
                            });
                            //get distinct Frequency
                            let arrAllFreq: any[] = [];
                            arrFiltData.map(ele => arrAllFreq.push(ele["ASFrequency"]));
                            let unique = [];
                            let distinct = [];
                            arrAllFreq.map(freq => {
                                if (!unique[freq]) {
                                    distinct.push(freq);
                                    unique[freq] = 1;
                                }
                            });

                            let series: any[] = [];
                            distinct.map(itm =>
                                series.push({
                                    'category': itm, 'value':
                                        (arrFiltData.filter(item => {
                                            return item["ASFrequency"] == itm;
                                        })).length
                                })
                            );

                            this.getSubCatRegionData(arrFiltData);
                            this.getSubCaTAData(arrFiltData);
                            this.getSubCatRegTopicData(arrFiltData);

                            this.setState({ gridSubData: distSub, pcSubSeries: series }, () => {
                                this.createDataStateSubs({ take: this.state.subTake, skip: this.state.subSkip, sort: this.state.subSort });
                                this._loadedSubsGridData = true;
                                this.hideSubscriptionLoader();
                            });

                        }
                    }).catch(error => {
                        LoggerService.errorLog(error, 'ChartComp > getfilterSubscriptionData');
                    });
            }




        }
        catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getfilterSubscriptionData');
        }

    }
    private filterAnalyticsData = (): void => {

        try {
            let camlData: string = "";
            let filtDateRange = DateRangeType.Quarter;
            let filtQuarter = [moment().quarter()];
            let filtYear = moment().year();

            if (this.props.chartData.filtDateRange)
                filtDateRange = this.props.chartData.filtDateRange;

            if (this.props.chartData.filtQuarter)
                filtQuarter = this.props.chartData.filtQuarter;

            if (this.props.chartData.filtYear)
                filtYear = this.props.chartData.filtYear;


            switch (filtDateRange) {
                case DateRangeType.DateRange:
                    camlData = '<And><Geq><FieldRef Name="Created" />' +
                        '<Value Type="DateTime">' +
                        moment.tz(this.getGMTDateString(this.props.chartData.filtFromDate), "GMT").format() + '</Value></Geq>' +
                        '<Leq><FieldRef Name="Created" />' +
                        '<Value Type="DateTime">' +
                        moment.tz(this.getGMTDateString(this.props.chartData.filtToDate), "GMT").format() + '</Value></Leq></And>';
                    break;
                case DateRangeType.Year:
                    this.props.chartData.filtYear.map(yr => {
                        if (camlData == "") {
                            camlData = '<And><Geq><FieldRef Name="Created" />' +
                                '<Value Type="DateTime">' +
                                moment.tz(this.getGMTDateString(moment(yr + '-01-01').toDate()), "GMT").format() + '</Value></Geq>' +
                                '<Leq><FieldRef Name="Created" />' +
                                '<Value Type="DateTime">' +
                                moment.tz(this.getGMTDateString(moment(yr + '-12-31').toDate()), "GMT").format() + '</Value></Leq></And>';
                        } else {
                            camlData = '<Or>' + camlData + '<And><Geq><FieldRef Name="Created" />' +
                                '<Value Type="DateTime">' +
                                moment.tz(this.getGMTDateString(moment(yr + '-01-01').toDate()), "GMT").format() + '</Value></Geq>' +
                                '<Leq><FieldRef Name="Created" />' +
                                '<Value Type="DateTime">' +
                                moment.tz(this.getGMTDateString(moment(yr + '-12-31').toDate()), "GMT").format() + '</Value> </Leq></And></Or>';
                        }
                    });
                    break;
                case DateRangeType.Quarter:
                    filtQuarter.map(qrt => {
                        let qrtDate = moment().year(filtYear).quarter(qrt).toDate();
                        let qrtSt = moment(qrtDate).quarter(qrt).startOf('quarter').toDate();
                        let qrtEnd = moment(qrtDate).quarter(qrt).endOf('quarter').toDate();

                        if (camlData == "") {
                            camlData = '<And><Geq><FieldRef Name="Created" />' +
                                '<Value Type="DateTime">' +
                                moment.tz(this.getGMTDateString(qrtSt), "GMT").format() + '</Value></Geq>' +
                                '<Leq><FieldRef Name="Created" />' +
                                '<Value Type="DateTime">' +
                                moment.tz(this.getGMTDateString(qrtEnd), "GMT").format() + '</Value></Leq></And>';
                        } else {
                            camlData = '<Or>' + camlData + '<And><Geq><FieldRef Name="Created" />' +
                                '<Value Type="DateTime">' +
                                moment.tz(this.getGMTDateString(qrtSt), "GMT").format() + '</Value></Geq>' +
                                '<Leq><FieldRef Name="Created" />' +
                                '<Value Type="DateTime">' +
                                moment.tz(this.getGMTDateString(qrtEnd), "GMT").format() + '</Value></Leq></And></Or>';
                        }
                    });
                    break;
                case DateRangeType.Month:
                    this.props.chartData.filtMonth.map(mnth => {
                        let mnthDate = moment().year(this.props.chartData.filtYear).month(mnth).toDate();
                        let mnthSt = moment(mnthDate).month(mnth).startOf('month').toDate();
                        let mnthEnd = moment(mnthDate).month(mnth).endOf('month').toDate();

                        if (camlData == "") {
                            camlData = '<And><Geq><FieldRef Name="Created" />' +
                                '<Value Type="DateTime">' +
                                moment.tz(this.getGMTDateString(mnthSt), "GMT").format() + '</Value></Geq>' +
                                '<Leq><FieldRef Name="Created" />' +
                                '<Value Type="DateTime">' +
                                moment.tz(this.getGMTDateString(mnthEnd), "GMT").format() + '</Value></Leq></And>';
                        } else {
                            camlData = '<Or>' + camlData + '<And><Geq><FieldRef Name="Created" />' +
                                '<Value Type="DateTime">' +
                                moment.tz(this.getGMTDateString(mnthSt), "GMT").format() + '</Value></Geq>' +
                                '<Leq><FieldRef Name="Created" />' +
                                '<Value Type="DateTime">' + moment.tz(this.getGMTDateString(mnthEnd), "GMT").format() + '</Value></Leq></And></Or>';
                        }
                    });
                    break;
                default: break;
            }
            let query: string = `<View><Query><Where>${camlData}</Where><OrderBy><FieldRef Name="Created"  Ascending="False" /></OrderBy></Query><RowLimit Paged="TRUE">4999</RowLimit></View>`;


            let analyticsListName = Common.getConfigValue(this.props.configData, ConfigType.Lists, ConfigKey.AlertAnalytics);


            ListService.GetDataByCAMLStream(analyticsListName, query).then(alertAn => {
                if (alertAn) {
                    if (alertAn.Row.length > 0) {
                        this._filteredAnalytics = alertAn.Row;
                        this.getUniquePageVisits();
                    } else {
                        this._filteredAnalytics = [];
                        this.setState({ analyticsGridData: [] });

                        this._loadedPageVisits = true;
                        this.hideLoading();
                    }

                }
            });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > filterAnalyticsData');
        }

    }

    private isDateFiltersModified = (prevPropsObj, currentPropsObj): boolean => {
        let returnVal = true;
        try {

            let filtDateRange = DateRangeType.Quarter;
            let filtQuarter = [moment().quarter()];
            let filtYear = moment().year();

            if (currentPropsObj.chartData.filtDateRange)
                filtDateRange = currentPropsObj.chartData.filtDateRange;

            if (currentPropsObj.chartData.filtQuarter)
                filtQuarter = currentPropsObj.chartData.filtQuarter;

            if (currentPropsObj.chartData.filtYear)
                filtYear = currentPropsObj.chartData.filtYear;



            if (prevPropsObj.chartData.filtDateRange && currentPropsObj.chartData.filtDateRange &&
                prevPropsObj.chartData.filtDateRange == currentPropsObj.chartData.filtDateRange) {

                switch (filtDateRange) {
                    case DateRangeType.DateRange:

                        let prevFromDate = (prevPropsObj.chartData.filtFromDate) ? moment.tz(this.getGMTDateString(prevPropsObj.chartData.filtFromDate), "GMT").format() : "";
                        let prevToDate = (prevPropsObj.chartData.filtToDate) ? moment.tz(this.getGMTDateString(prevPropsObj.chartData.filtToDate), "GMT").format() : "";
                        let currentFromDate = (currentPropsObj.chartData.filtFromDate) ? moment.tz(this.getGMTDateString(currentPropsObj.chartData.filtFromDate), "GMT").format() : "";
                        let currentToDate = (currentPropsObj.chartData.filtToDate) ? moment.tz(this.getGMTDateString(currentPropsObj.chartData.filtToDate), "GMT").format() : "";
                        if (prevFromDate && prevToDate && currentFromDate && currentToDate && prevFromDate == currentFromDate && prevToDate == currentToDate)
                            returnVal = false;
                        else
                            returnVal = true;
                        break;
                    case DateRangeType.Year:
                        let filtYear_Prev_Y = (prevPropsObj.chartData.filtYear) ? prevPropsObj.chartData.filtYear : "";
                        let filtYear_Cur_Y = (currentPropsObj.chartData.filtYear) ? currentPropsObj.chartData.filtYear : "";

                        if (filtYear_Prev_Y && filtYear_Cur_Y && filtYear_Prev_Y == filtYear_Cur_Y)
                            returnVal = false;

                        else
                            returnVal = true;
                        break;
                    case DateRangeType.Quarter:

                        let filtYear_Prev_q = (prevPropsObj.chartData.filtYear) ? prevPropsObj.chartData.filtYear : "";
                        let filtYear_Current_q = (currentPropsObj.chartData.filtYear) ? currentPropsObj.chartData.filtYear : "";
                        if (filtYear_Prev_q && filtYear_Current_q && filtYear_Prev_q == filtYear_Current_q) {

                            let filtQuarter_Prev_Y = (prevPropsObj.chartData.filtQuarter) ? prevPropsObj.chartData.filtQuarter : "";
                            let filtQuarter_Cur_Y = (currentPropsObj.chartData.filtQuarter) ? currentPropsObj.chartData.filtQuarter : "";

                            if (filtQuarter_Prev_Y && filtQuarter_Cur_Y && filtQuarter_Prev_Y == filtQuarter_Cur_Y) {
                                returnVal = false;
                            }
                            else
                                returnVal = true;

                        }
                        else
                            returnVal = true;

                        break;
                    case DateRangeType.Month:
                        let filtYear_Prev_M = (prevPropsObj.chartData.filtYear) ? prevPropsObj.chartData.filtYear : "";
                        let filtYear_Current_M = (currentPropsObj.chartData.filtYear) ? currentPropsObj.chartData.filtYear : "";
                        if (filtYear_Prev_M && filtYear_Current_M && filtYear_Prev_M == filtYear_Current_M) {

                            let filtMonth_Prev_M = (prevPropsObj.chartData.filtMonth) ? prevPropsObj.chartData.filtMonth : "";
                            let filtMonth_Cur_M = (currentPropsObj.chartData.filtMonth) ? currentPropsObj.chartData.filtMonth : "";

                            if (filtMonth_Prev_M && filtMonth_Cur_M && filtMonth_Prev_M == filtMonth_Cur_M) {
                                returnVal = false;
                            }
                            else
                                returnVal = true;
                        }
                        else
                            returnVal = true;

                        break;
                    default: break;
                }

            }
            else {
                returnVal = true;
            }


        }
        catch (error) {
            LoggerService.errorLog(error, 'ChartComp > isDateFiltersModified');
        }
        return returnVal;
    }

    private async getSubEmail() {
        try {
            let userEmails: string = "";
            for (let index = 0; index < this.state.gridSubData.length; index++) {
                await sp.web.siteUsers.getById(this.state.gridSubData[index]['id']).get().then(usr => {
                    if (usr.Email)
                        userEmails += ";" + usr.Email;
                });
            }
            window.location.href = ("mailto:" + userEmails.substr(1));
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getSubEmail');
        }
    }

    private getYearChartSeriesItems = (): void => {
        try {

            //identify series        
            this.getCategoryArr();

            let filtDateRange = DateRangeType.Quarter;

            if (this.props.chartData.filtDateRange)
                filtDateRange = this.props.chartData.filtDateRange;

            switch (filtDateRange) {
                case DateRangeType.DateRange:
                    this.getDateRangeSeries();
                    break;
                case DateRangeType.Year:
                    this.getYearSeries();
                    break;
                case DateRangeType.Quarter:

                    this.getQuarterSeries();
                    break;
                case DateRangeType.Month:
                    this.getMonthSeries();
                    break;
                default:
                    break;
            }
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getYearChartSeriesItems');
        }
    }

    private getDateRangeSeries = (): void => {
        try {
            let tempSeries: any = [];
            let tempFinalSeries: any[] = [];
            let tempCat: any[] = [];
            tempSeries.push(moment(this.props.chartData.filtFromDate).year());

            //For the series get data
            if (this._filterCategory.length > 0) {
                tempSeries.map(ser => {
                    let valArr: any = [];
                    this._filterCategory.map((cat) => {
                        valArr.push(
                            this.state.filteredData.filter(item => {
                                //moment(itm.ADBPublicationDate).isBetween(this.props.chartData.filtFromDate, this.props.chartData.filtToDate, undefined, '[]')
                                if (this.state.selByCategory == CategoryType.Author)
                                    return (moment(item.ADBPublicationDate).isBetween(this.props.chartData.filtFromDate, this.props.chartData.filtToDate, undefined, '[]')
                                        && item.ADBAuthor[0]["id"] == cat);
                                else
                                    return (moment(item.ADBPublicationDate).isBetween(this.props.chartData.filtFromDate, this.props.chartData.filtToDate, undefined, '[]')
                                        && item[this._filterCatField].filter(x => { return x.TermID == cat.key; }).length > 0);
                            }).length);
                    });
                    tempFinalSeries.push({ name: ser, data: valArr });
                });
                this._filterCategory.map(x => tempCat.push(x.text));
            } else { //else get all regions
                let arrAllRegions: any[] = [];
                if (this.state.selByCategory == CategoryType.Author)
                    this.state.filteredData.map(ele => arrAllRegions.push({ termGuid: ele.ADBAuthor[0]["id"], label: ele.ADBAuthor[0]["title"] }));
                else
                    this.state.filteredData.map(ele => ele[this._filterCatField].map(eles => arrAllRegions.push({ termGuid: eles["TermID"], label: eles["Label"] })));
                let unique = [];
                let distinct = [];
                arrAllRegions.map(reg => {
                    if (!unique[reg.termGuid]) {
                        distinct.push({ key: reg.termGuid, text: reg.label });
                        unique[reg.termGuid] = 1;
                    }
                });
                tempSeries.map(ser => {
                    let valArr: any = [];
                    distinct.map((cat) => {
                        valArr.push(
                            this.state.filteredData.filter(item => {
                                if (this.state.selByCategory == CategoryType.Author)
                                    return (moment(item.ADBPublicationDate).isBetween(this.props.chartData.filtFromDate, this.props.chartData.filtToDate, undefined, '[]')
                                        && item.ADBAuthor[0]["id"] == cat.key);
                                else
                                    return (moment(item.ADBPublicationDate).isBetween(this.props.chartData.filtFromDate, this.props.chartData.filtToDate, undefined, '[]')
                                        && item[this._filterCatField].filter(x => { return x.TermID == cat.key; }).length > 0);
                            }).length);
                    });
                    tempFinalSeries.push({ name: ser, data: valArr });
                });
                distinct.map(x => tempCat.push(x.text));
            }
            this.setState({ yearChartSeriesItemColl: tempFinalSeries, yearCategories: tempCat }, () => { this._loadedDateRangeSeries = true; this.hideLoading(); });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getDateRangeSeries');
        }
    }

    private getYearSeries = (): void => {
        try {
            let tempSeries: any = [];
            let tempFinalSeries: any[] = [];
            let tempCat: any[] = [];
            this.props.chartData.filtYear.map(x => tempSeries.push(x));
            tempSeries.sort();

            //For the series get data
            if (this._filterCategory.length > 0) {
                tempSeries.map(ser => {
                    let valArr: any = [];
                    this._filterCategory.map((cat) => {
                        valArr.push(
                            this.state.filteredData.filter(item => {
                                if (this.state.selByCategory == CategoryType.Author)
                                    return (moment(item.ADBPublicationDate).year() == ser && item.ADBAuthor[0]["id"] == cat);
                                else
                                    return (moment(item.ADBPublicationDate).year() == ser && item[this._filterCatField].filter(x => { return x.TermID == cat.key; }).length > 0);
                            }).length);
                    });
                    tempFinalSeries.push({ name: ser, data: valArr });
                });
                this._filterCategory.map(x => tempCat.push(x.text));
            } else { //else get all regions
                let arrAllRegions: any[] = [];
                if (this.state.selByCategory == CategoryType.Author)
                    this.state.filteredData.map(ele => arrAllRegions.push({ termGuid: ele.ADBAuthor[0]["id"], label: ele.ADBAuthor[0]['title'] }));
                else
                    this.state.filteredData.map(ele => ele[this._filterCatField].map(eles => arrAllRegions.push({ termGuid: eles["TermID"], label: eles["Label"] })));
                let unique = [];
                let distinct = [];
                arrAllRegions.map(reg => {
                    if (!unique[reg.termGuid]) {
                        distinct.push({ key: reg.termGuid, text: reg.label });
                        unique[reg.termGuid] = 1;
                    }
                });
                tempSeries.map(ser => {
                    let valArr: any = [];
                    distinct.map((cat) => {
                        valArr.push(
                            this.state.filteredData.filter(item => {
                                if (this.state.selByCategory == CategoryType.Author)
                                    return (moment(item.ADBPublicationDate).year() == ser && item.ADBAuthor[0]["id"] == cat.key);
                                else
                                    return (moment(item.ADBPublicationDate).year() == ser && item[this._filterCatField].filter(x => { return x.TermID == cat.key; }).length > 0);
                            }).length);
                    });
                    tempFinalSeries.push({ name: ser, data: valArr });
                });
                distinct.map(x => tempCat.push(x.text));
            }
            this.setState({ yearChartSeriesItemColl: tempFinalSeries, yearCategories: tempCat }, () => { this._loadedDateRangeSeries = true; this.hideLoading(); });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getYearSeries');
        }
    }

    private getQuarterSeries = (): void => {
        try {

            let tempSeries: any = [];
            let tempFinalSeries: any[] = [];
            let tempCat: any[] = [];


            let filtDateRange = DateRangeType.Quarter;
            let filtQuarter = [moment().quarter()];
            let filtYear = moment().year();


            if (this.props.chartData.filtDateRange)
                filtDateRange = this.props.chartData.filtDateRange;

            if (this.props.chartData.filtYear)
                filtYear = this.props.chartData.filtYear;

            if (this.props.chartData.filtQuarter)
                filtQuarter = this.props.chartData.filtQuarter;


            filtQuarter.map(x => tempSeries.push(x));
            tempSeries.sort();

            //For the series get data
            if (this._filterCategory.length > 0) {
                tempSeries.map(ser => {
                    let valArr: any = [];
                    this._filterCategory.map((cat) => {
                        valArr.push(
                            this.state.filteredData.filter(item => {
                                if (this.state.selByCategory == CategoryType.Author)
                                    return (moment(item.ADBPublicationDate).year() == (
                                        filtDateRange == DateRangeType.Year ?
                                            filtYear[0] :
                                            filtYear
                                    ) &&
                                        moment(item.ADBPublicationDate).quarter() == ser &&
                                        item.ADBAuthor[0]["id"] == cat);
                                else
                                    return (moment(item.ADBPublicationDate).year() == (
                                        filtDateRange == DateRangeType.Year ?
                                            filtYear[0] :
                                            filtYear
                                    ) &&
                                        moment(item.ADBPublicationDate).quarter() == ser &&
                                        item[this._filterCatField].filter(x => { return x.TermID == cat.key; }).length > 0);
                            }).length);
                    });
                    tempFinalSeries.push({ name: this.DayPickerStrings.shortQuarter[ser - 1], data: valArr });
                });
                this._filterCategory.map(x => tempCat.push(x.text));
            } else { //else get all regions
                let arrAllRegions: any[] = [];
                if (this.state.selByCategory == CategoryType.Author)
                    this.state.filteredData.map(ele => arrAllRegions.push({ termGuid: ele.ADBAuthor[0]["id"], label: ele.ADBAuthor[0]["title"] }));
                else
                    this.state.filteredData.map(ele => ele[this._filterCatField].map(eles => arrAllRegions.push({ termGuid: eles["TermID"], label: eles["Label"] })));
                let unique = [];
                let distinct = [];
                arrAllRegions.map(reg => {
                    if (!unique[reg.termGuid]) {
                        distinct.push({ key: reg.termGuid, text: reg.label });
                        unique[reg.termGuid] = 1;
                    }
                });
                tempSeries.map(ser => {
                    let valArr: any = [];
                    distinct.map((cat) => {
                        valArr.push(
                            this.state.filteredData.filter(item => {
                                if (this.state.selByCategory == CategoryType.Author)
                                    return (moment(item.ADBPublicationDate).year() == (
                                        (filtDateRange == DateRangeType.Year ?
                                            filtYear[0] :
                                            filtYear)
                                    ) &&
                                        moment(item.ADBPublicationDate).quarter() == ser &&
                                        item.ADBAuthor[0]["id"] == cat.key);
                                else
                                    return (moment(item.ADBPublicationDate).year() == (
                                        (filtDateRange == DateRangeType.Year ?
                                            filtYear[0] :
                                            filtYear)
                                    ) &&
                                        moment(item.ADBPublicationDate).quarter() == ser &&
                                        item[this._filterCatField].filter(x => { return x.TermID == cat.key; }).length > 0);
                            }).length);
                    });
                    tempFinalSeries.push({ name: this.DayPickerStrings.shortQuarter[ser - 1], data: valArr });
                });
                distinct.map(x => tempCat.push(x.text));
            }
            this.setState({ yearChartSeriesItemColl: tempFinalSeries, yearCategories: tempCat }, () => { this._loadedDateRangeSeries = true; this.hideLoading(); });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getQuarterSeries');
        }
    }

    private getMonthSeries = (): void => {
        try {
            let tempSeries: any = [];
            let tempFinalSeries: any[] = [];
            let tempCat: any[] = [];
            this.props.chartData.filtMonth.map(x => tempSeries.push(x));
            tempSeries.sort();

            //For the series get data
            if (this._filterCategory.length > 0) {
                tempSeries.map(ser => {
                    let valArr: any = [];
                    this._filterCategory.map((cat) => {
                        valArr.push(
                            this.state.filteredData.filter(item => {
                                if (this.state.selByCategory == CategoryType.Author)
                                    return (moment(item.ADBPublicationDate).year() ==
                                        (this.props.chartData.filtDateRange == DateRangeType.Year ?
                                            this.props.chartData.filtYear[0] :
                                            this.props.chartData.filtYear) &&
                                        moment(item.ADBPublicationDate).month() == ser &&
                                        item.ADBAuthor[0]["id"] == cat);
                                else
                                    return (moment(item.ADBPublicationDate).year() ==
                                        (this.props.chartData.filtDateRange == DateRangeType.Year ?
                                            this.props.chartData.filtYear[0] :
                                            this.props.chartData.filtYear) &&
                                        moment(item.ADBPublicationDate).month() == ser &&
                                        item[this._filterCatField].filter(x => { return x.TermID == cat.key; }).length > 0);
                            }).length);
                    });
                    tempFinalSeries.push({ name: this.DayPickerStrings.months[ser], data: valArr });
                });
                this._filterCategory.map(x => tempCat.push(x.text));
            } else { //else get all regions
                let arrAllRegions: any[] = [];
                if (this.state.selByCategory == CategoryType.Author)
                    this.state.filteredData.map(ele => arrAllRegions.push({ termGuid: ele.ADBAuthor[0]["id"], label: ele.ADBAuthor[0]["title"] }));
                else
                    this.state.filteredData.map(ele => ele[this._filterCatField].map(eles => arrAllRegions.push({ termGuid: eles["TermID"], label: eles["Label"] })));
                let unique = [];
                let distinct = [];
                arrAllRegions.map(reg => {
                    if (!unique[reg.termGuid]) {
                        distinct.push({ key: reg.termGuid, text: reg.label });
                        unique[reg.termGuid] = 1;
                    }
                });
                tempSeries.map(ser => {
                    let valArr: any = [];
                    distinct.map((cat) => {
                        valArr.push(
                            this.state.filteredData.filter(item => {
                                if (this.state.selByCategory == CategoryType.Author)
                                    return (moment(item.ADBPublicationDate).year() ==
                                        (this.props.chartData.filtDateRange == DateRangeType.Year ?
                                            this.props.chartData.filtYear[0] :
                                            this.props.chartData.filtYear)
                                        &&
                                        moment(item.ADBPublicationDate).month() == ser &&
                                        item.ADBAuthor[0]["id"] == cat.key);
                                else
                                    return (moment(item.ADBPublicationDate).year() ==
                                        (this.props.chartData.filtDateRange == DateRangeType.Year ?
                                            this.props.chartData.filtYear[0] :
                                            this.props.chartData.filtYear)
                                        &&
                                        moment(item.ADBPublicationDate).month() == ser &&
                                        item[this._filterCatField].filter(x => { return x.TermID == cat.key; }).length > 0);
                            }).length);
                    });
                    tempFinalSeries.push({ name: this.DayPickerStrings.months[ser], data: valArr });
                });
                distinct.map(x => tempCat.push(x.text));
            }
            this.setState({ yearChartSeriesItemColl: tempFinalSeries, yearCategories: tempCat }, () => { this._loadedDateRangeSeries = true; this.hideLoading(); });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getMonthSeries');
        }
    }

    private getCategoryArr = (): void => {
        try {

            switch (this.state.selByCategory) {
                case CategoryType.Region:
                    let filtRegion = [];
                    if (this.props.chartData.filtRegion)
                        filtRegion = this.props.chartData.filtRegion;
                    this._filterCategory = filtRegion;
                    this._filterCatField = "G2Region";
                    break;
                case CategoryType.TherapeuticArea:
                    this._filterCategory = this.props.chartData.filtTA;
                    this._filterCatField = "G2TherapeuticArea";
                    break;
                case CategoryType.RegulatoryTopic:
                    this._filterCategory = this.props.chartData.filtRegTopic;
                    this._filterCatField = "G2RegulatoryTopic";
                    break;
                case CategoryType.DocumentType:
                    this._filterCategory = this.props.chartData.filtDocType;
                    this._filterCatField = "G2DocumentType";
                    break;
                case CategoryType.Author:
                    this._filterCategory = this.props.chartData.filtAuthor;
                    this._filterCatField = "ADBAuthor";
                    break;
                default:
                    break;
            }
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getCategoryArr');
        }
    }

    private getListViewData = (): void => {
        try {
            let viewAlertPage = Common.getConfigValue(this.props.configData, ConfigType.Page, ConfigKey.ViewAlert);

            let listViewData: any[] = [];
            this.state.filteredData.map((alert) => {
                listViewData.push({
                    id: alert['ID'],
                    title: alert['Title'],
                    titleLink: {
                        "title": alert['Title'],
                        "id": alert['ID'],
                        "link": this.props.webURL + viewAlertPage + "#Id=" + alert['ID']
                    },
                    publicationDate: moment(alert["ADBPublicationDate"]).toDate(),
                    region: Common.getManagedMetadataString(alert["G2Region"]),
                    documentType: Common.getManagedMetadataString(alert["G2DocumentType"]),
                    regulatoryTopic: Common.getManagedMetadataString(alert["G2RegulatoryTopic"]),
                    therapeuticArea: Common.getManagedMetadataString(alert["G2TherapeuticArea"]), author: alert["ADBAuthor"][0]['title']
                });
            });

            this.setState({ listViewData: listViewData }, () => {
                this.createDataStateAlerts({ take: this.state.take, skip: this.state.skip, sort: this.state.sort });
                this._loadedListViewData = true;
                this.hideLoading();
            });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getListViewData');
        }
    }

    private showLinkToViewForm = (props) => {
        try {
            let viewAlertPage = Common.getConfigValue(this.props.configData, ConfigType.Page, ConfigKey.ViewAlert);
            return (<td><Link className="listViewTitleLink" href={this.props.webURL + viewAlertPage + "#Id=" + props.dataItem.id}>{props.dataItem.title}</Link></td>);
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > showLinkToViewForm');
        }
    }

    private getGMTDateString = (dateToConert: Date): string => {
        let dateStr = dateToConert.getFullYear() + '-' + ('0' + (dateToConert.getMonth() + 1)).slice(-2) + '-' + ('0' + (dateToConert.getDate())).slice(-2);
        return (dateStr + "T10:00:00Z");
    }

    private getUniquePageVisits = (): void => {
        try {
            let arrDistPages: any[] = [];
            let arrGridData: any[] = [];
            let arrAlertVisits: any[] = [];
            //arrDistPages = [...new Set(this._filteredAnalytics.map(x => x.Title))];
            let unique = [];
            this._filteredAnalytics.map(pv => {
                if (!unique[pv.Title]) {
                    arrDistPages.push(pv.Title);
                    unique[pv.Title] = 1;
                }
            });
            arrDistPages.sort();
            //Page specific data
            arrDistPages.map(pg => {
                if (pg !== PageName.Alerts) {
                    let totVisits = this._filteredAnalytics.filter(item => {
                        return item.Title == pg;
                    });
                    let totFirstTimeVis = this._filteredAnalytics.filter(item => {
                        return item.Title == pg && item.AAIsFirstVisit == 'Yes';
                    });
                    arrGridData.push({ title: pg, totalVisits: totVisits.length, firstVisit: totFirstTimeVis.length });
                }
            });
            //Alert specific data
            let listViewData = this.state.listViewData;

            listViewData.map(ele => {
                let totVisits = this._filteredAnalytics.filter(item => {
                    return item.ADBId.replace(/,/g, "") == ele.id;
                });
                let totFirstTimeVis = this._filteredAnalytics.filter(item => {
                    return item.ADBId.replace(/,/g, "") == ele.id && item.AAIsFirstVisit == 'Yes';
                });
                ele['totalVisits'] = totVisits.length;
                ele['firstVisit'] = totFirstTimeVis.length;
            });
            this.setState({ analyticsGridData: arrGridData, listViewData: listViewData }, () => { this._loadedPageVisits = true; this.hideLoading(); });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > getUniquePageVisits');
        }
    }

    private dataStateChangeAlerts = (event) => {
        this.createDataStateAlerts(event.data);
    }

    private createDataStateAlerts(dataState: any) {
        try {
            if (this.state) {
                this.setState({ result: process(this.state.listViewData.slice(0), dataState), dataState: dataState });
            }
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > createDataStateAlerts');
        }
    }

    private dataStateChangeSubs = (event) => {
        this.createDataStateSubs(event.data);
    }

    private createDataStateSubs(dataState: any) {
        try {
            if (this.state)
                this.setState({ subResult: process(this.state.gridSubData.slice(0), dataState), subDataState: dataState });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > createDataStateSubs');
        }
    }

    private hideLoading() {
        try {

            if (this._loadedRegionSeries && this._loadedTASeries && this._loadedRegTopicSeries && this._loadedDocTypeSeries &&
                this._loadedDateRangeSeries && this._loadedListViewData && this._loadedPageVisits) {
                this.setState({ hideLoadingDialog: true });
            }
            else
                this.setState({ hideLoadingDialog: false });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > hideLoading');
        }
    }

    private hideSubscriptionLoader() {
        try {

            if (this._loadedSubsGridData && this._loadedSubRegionSeries && this._loadedSubTASeries && this._loadedSubRegTopicSeries) {
                this.setState({ hideSubscrLoadingDialog: true });
            }
            else
                this.setState({ hideSubscrLoadingDialog: false });
        } catch (error) {
            LoggerService.errorLog(error, 'ChartComp > hideSubscriptionLoader');
        }
    }

    private _cellRender(tdElement, cellProps) {
        try {
            if (cellProps.rowType === 'data') {
                if (cellProps.field == "titleLink") {
                    return (
                        <td>
                            <Link className="listViewTitleLink" href={cellProps.dataItem[cellProps.field].link}>
                                {cellProps.dataItem[cellProps.field].title}</Link>
                        </td>
                    );
                }
            }
            return tdElement;
        }
        catch (exception) {
            LoggerService.errorLog(exception, "ChartComp > _cellRender");
        }
    }
}
