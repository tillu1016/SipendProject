import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IMetricsAndDashboardProps {
  context: WebPartContext;
  webURL: string;
}
