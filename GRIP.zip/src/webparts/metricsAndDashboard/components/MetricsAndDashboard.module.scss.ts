/* tslint:disable */
require("./MetricsAndDashboard.module.css");
const styles = {
  metricsAndDashboard: 'metricsAndDashboard_abdd5a0e',
  container: 'container_abdd5a0e',
  row: 'row_abdd5a0e',
  column: 'column_abdd5a0e',
  'ms-Grid': 'ms-Grid_abdd5a0e',
  title: 'title_abdd5a0e',
  subTitle: 'subTitle_abdd5a0e',
  description: 'description_abdd5a0e',
  button: 'button_abdd5a0e',
  label: 'label_abdd5a0e'
};

export default styles;
/* tslint:enable */