// import 'core-js/es7/map';
// import 'core-js/es6/array';
// import 'core-js/fn/string/includes';
import * as React from 'react';
import styles from './MetricsAndDashboard.module.scss';
import { IMetricsAndDashboardProps } from './IMetricsAndDashboardProps';
import { escape } from '@microsoft/sp-lodash-subset';
import FilterDashboardComp from './FilterDashboardComp';
import ChartComp from './chartComp';
import { LoggerService } from '../../../services/LoggerService';
import { Common } from '../../../common/common';
import { ConfigType, ConfigKey, IConfiguration } from '../../../models/IConfiguration';
import { ListService } from '../../../services/ListService';
import { AlertStatus } from '../../../models/IAlert';
import { AlertFrequency } from '../../../models/ISubscription';
import { Stack } from '@fluentui/react';
import { sp } from '@pnp/sp';


import * as moment from 'moment-timezone';
interface IMetricsAndDashboardState {
  chartData: any[]; allAlerts: any[]; allSubscriptions: any[]; configData: IConfiguration[];
}

export default class MetricsAndDashboard extends React.Component<IMetricsAndDashboardProps, IMetricsAndDashboardState> {

  constructor(props) {
    super(props);
    this.state = {
      chartData: [], allAlerts: [], allSubscriptions: [], configData: []
    };
  }

  public componentDidMount() {

    try {
      Common.getConfigData().then(resp => {
        if (resp) {

          let adminGrpName: string = Common.getConfigValue(resp, ConfigType.Roles, ConfigKey.Administrator);
          Common.checkIfUserAdmin(adminGrpName).then(isUsrAdm => {
            if (!isUsrAdm) {
              alert('You are not authorized to view this page. Please contact GRIP Administrator');
              window.location.href = this.props.webURL;
            }
          });
          this.setState({ configData: resp });
        }
      });
    } catch (error) {
      LoggerService.errorLog(error, 'MetricsAndDashboard > componentDidMount');
    }

  }

  public render(): React.ReactElement<IMetricsAndDashboardProps> {
    return (
      <Stack className={styles.metricsAndDashboard}>
        <Stack.Item className="madTitle">
          <h1>Metrics & Dashboard</h1>
        </Stack.Item>
        <Stack.Item>
          {this.state.configData.length > 0 &&
            <FilterDashboardComp
              webURL={this.props.webURL}
              updateCharts={this.updateCharts.bind(this)}
              allAlerts={this.state.allAlerts}
              allSubscriptions={this.state.allSubscriptions}
              configData={this.state.configData}
            ></FilterDashboardComp>
          }
        </Stack.Item>
        <Stack.Item>
          {this.state.configData.length > 0 &&
            <ChartComp
              webURL={this.props.webURL}
              chartData={this.state.chartData}
              allAlerts={this.state.allAlerts}
              allSubscriptions={this.state.allSubscriptions}
              configData={this.state.configData}
              context={this.props.context}
            ></ChartComp>
          }
        </Stack.Item>
      </Stack>
    );
  }

  private updateCharts = (chartData: any): void => {
    try {
      this.setState({ chartData: chartData });
    } catch (error) {
      LoggerService.errorLog(error, 'MetricsAndDashboard > updateCharts');
    }
  }
}
