// import 'core-js/es7/map';
// import 'core-js/es6/array';
// import 'core-js/fn/string/includes';
import * as React from 'react';
import { ListService } from '../../../services/ListService';
import { LoggerService } from '../../../services/LoggerService';
import { Common } from '../../../common/common';
import { ConfigType, ConfigKey, IConfiguration } from '../../../models/IConfiguration';
import { AlertStatus, IAlert } from '../../../models/IAlert';
import { List, Stack, Dropdown, PrimaryButton, SearchBox, DefaultButton, DatePicker, SpinnerSize, Spinner } from '@fluentui/react';
import { ISubscription, AlertFrequency } from '../../../models/ISubscription';
import * as moment from 'moment-timezone';
import { DateRangeType } from '../../../models/IMetricsDashboard';

interface FilterDashboardCompState {
    alertCount: number; subsCount: number;
    immediateSubsCount: number; dailySubsCount: number; weeklySubsCount: number; alertRegionOptions: any[]; alertTAOptions: any[];
    alertRegTopicOptions: any[]; alertDocTypeOptions: any[]; alertAuthorOptions: any[]; selRegion: any[]; selTA: any[];
    selRegTopic: any[]; selDocType: any[]; selAuthor: any[]; yearOptions: any[]; selDateRange: string; selYears: number[]; selYear: number;
    selQuarter: number[]; selMonth: number[]; selFromDate: Date; selToDate: Date; disableApply: boolean;
}

interface FilterDashboardCompProps {
    webURL: string;
    updateCharts: any;
    allAlerts: any[];
    allSubscriptions: any[];
    configData: IConfiguration[];
}

export default class FilterDashboardComp extends React.Component<FilterDashboardCompProps, FilterDashboardCompState>{
    private _selRegionsObj: any[] = [];
    private _selTAObj: any[] = [];
    private _selRegTopicObj: any[] = [];
    private _selDocTypeObj: any[] = [];
    private _selAuthorObj: any[] = [];
    private _dateRngOptions: any[] = [];
    private _quarterOptions: any[] = [];
    private _monthOptions: any[] = [];

    constructor(props) {
        super(props);
        this.state = {
            alertCount: 0, subsCount: 0, immediateSubsCount: 0, dailySubsCount: 0, weeklySubsCount: 0,
            alertRegionOptions: [], alertTAOptions: [], alertRegTopicOptions: [], alertDocTypeOptions: [], alertAuthorOptions: [],
            selRegion: [], selTA: [], selRegTopic: [], selDocType: [], selAuthor: [], yearOptions: [], selDateRange: DateRangeType.Quarter,
            selYears: [], selYear: 0, selQuarter: [], selMonth: [], selFromDate: moment().toDate(), selToDate: moment().toDate(), disableApply: false
        };
    }

    public componentDidUpdate(prevProps: FilterDashboardCompProps) {


        try {
            //this.updateCharts();
        } catch (error) {
            LoggerService.errorLog(error, 'FilterDashboardComp > componentDidUpdate');
        }

    }
    public componentDidMount() {

        try {
            Common.timeZone = moment.tz.guess();
            moment.tz.setDefault(Common.timeZone);

            this._dateRngOptions = [{ key: DateRangeType.DateRange, text: 'Date Range' }, { key: DateRangeType.Year, text: 'Year' },
            { key: DateRangeType.Quarter, text: 'Quarter' }, { key: DateRangeType.Month, text: 'Month' }];

            this._quarterOptions = [{ key: 1, text: 'Q1' }, { key: 2, text: 'Q2' }, { key: 3, text: 'Q3' }, { key: 4, text: 'Q4' }];

            this._monthOptions = [{ key: 0, text: 'January' }, { key: 1, text: 'February' }, { key: 2, text: 'March' },
            { key: 3, text: 'April' }, { key: 4, text: 'May' }, { key: 5, text: 'June' }, { key: 6, text: 'July' },
            { key: 7, text: 'August' }, { key: 8, text: 'September' }, { key: 9, text: 'October' },
            { key: 10, text: 'November' }, { key: 11, text: 'December' }];
            this.getAlertSubscriptionSummary();

            Common.getTermSetData(this.props.configData, ConfigType.Taxonomy, ConfigKey.Region).then(regions => {
                this.setState({ alertRegionOptions: regions });
            });
            Common.getTermSetData(this.props.configData, ConfigType.Taxonomy, ConfigKey.RegulatoryTopic).then(regTopics => {
                this.setState({ alertRegTopicOptions: regTopics });
            });
            Common.getTermSetData(this.props.configData, ConfigType.Taxonomy, ConfigKey.TherapeuticArea).then(tas => {
                this.setState({ alertTAOptions: tas });
            });
            Common.getTermSetData(this.props.configData, ConfigType.Taxonomy, ConfigKey.DocumentType).then(docT => {
                this.setState({ alertDocTypeOptions: docT });
            });


            this.getDistinctAuthorAndYear();

        } catch (error) {
            LoggerService.errorLog(error, 'FilterDashboardComp > componentDidMount');
        }

    }

    public render(): JSX.Element {

        return (
            <div>
                <Stack>
                    <Stack.Item>
                        <div className="mini_dashboard">
                            <div className="mini_box blue_box">
                                <h2>Overall Alerts</h2>
                                <h1>{this.state.alertCount}</h1>
                            </div>
                            <div className="mini_box skyblue_box">
                                <h2>All Subscribed Users</h2>
                                <h1>{this.state.subsCount}</h1>
                            </div>
                            <div className="mini_box grn_box">
                                <h2>Immediate Subscriptions </h2>
                                <h1>{this.state.immediateSubsCount}</h1>
                            </div>
                            <div className="mini_box red_box">
                                <h2>Daily Subscriptions </h2>
                                <h1>{this.state.dailySubsCount}</h1>
                            </div>
                            <div className="mini_box grey_box">
                                <h2>Weekly Subscriptions </h2>
                                <h1>{this.state.weeklySubsCount}</h1>
                            </div>
                        </div>
                    </Stack.Item>
                    <Stack.Item className="filter_bg">
                        <div>
                            <div className="mdFiltersDropdown">
                                <Dropdown
                                    placeholder="Select an option"
                                    label="Region"
                                    options={this.state.alertRegionOptions}
                                    multiSelect
                                    onChange={this._onDDLRegionChange.bind(this)}
                                    selectedKeys={this.state.selRegion}
                                />
                            </div>
                            <div className="mdFiltersDropdown">
                                <Dropdown
                                    placeholder="Select an option"
                                    label="Therapeutic Area"
                                    multiSelect
                                    options={this.state.alertTAOptions}
                                    onChange={this._onDDLTAChange.bind(this)}
                                    selectedKeys={this.state.selTA}
                                />
                            </div>
                            <div className="mdFiltersDropdown">
                                <Dropdown
                                    placeholder="Select an option"
                                    label="Regulatory Topic"
                                    multiSelect
                                    options={this.state.alertRegTopicOptions}
                                    onChange={this._onDDLRegTopicChange.bind(this)}
                                    selectedKeys={this.state.selRegTopic}
                                />
                            </div>
                            <div className="mdFiltersDropdown">
                                <Dropdown
                                    placeholder="Select an option"
                                    label="Document Type"
                                    multiSelect
                                    options={this.state.alertDocTypeOptions}
                                    onChange={this._onDDLDocTypeChange.bind(this)}
                                    selectedKeys={this.state.selDocType}
                                />
                            </div>
                        </div>
                        <div className="filterSectionLeft">
                            <div className="mdFiltersDropdown">
                                <Dropdown
                                    placeholder="Select an option"
                                    label="Author"
                                    multiSelect
                                    options={this.state.alertAuthorOptions}
                                    onChange={this._onDDLAuthorChange.bind(this)}
                                    selectedKeys={this.state.selAuthor}
                                />
                            </div>
                            <div className="dateControls">
                                <Dropdown
                                    placeholder="Select an option"
                                    label="Date Range"
                                    options={this._dateRngOptions}
                                    onChange={this._onDDLDateRangeChange.bind(this)}
                                    selectedKey={this.state.selDateRange}
                                    required={true}
                                />
                            </div>
                            {this.state.selDateRange == DateRangeType.DateRange ?
                                <div className="datePickerContainer">
                                    <div className="datePicker">
                                        <DatePicker
                                            label='From'
                                            showWeekNumbers={true}
                                            firstWeekOfYear={1}
                                            showMonthPickerAsOverlay={true}
                                            placeholder="Select a date..."
                                            ariaLabel="Select a date"
                                            value={this.state.selFromDate}
                                            onSelectDate={this.onFromDateSelect.bind(this)}
                                            isRequired={true}
                                        />
                                    </div>
                                    <div className="datePicker">
                                        <DatePicker
                                            label='To'
                                            showWeekNumbers={true}
                                            firstWeekOfYear={1}
                                            showMonthPickerAsOverlay={true}
                                            placeholder="Select a date..."
                                            ariaLabel="Select a date"
                                            value={this.state.selToDate}
                                            onSelectDate={this.onToDateSelect.bind(this)}
                                            isRequired={true}
                                        />
                                    </div>
                                </div> : null}
                            {this.state.selDateRange == DateRangeType.Year ?
                                <div className="dateControls">
                                    <Dropdown
                                        placeholder="Select an option"
                                        label="Year"
                                        multiSelect
                                        options={this.state.yearOptions}
                                        onChange={this._onDDLYearsChange.bind(this)}
                                        selectedKeys={this.state.selYears}
                                        required={true}
                                    />
                                </div> : null}
                            {this.state.selDateRange == DateRangeType.Quarter || this.state.selDateRange == DateRangeType.Month ?
                                <div className="dateControls">
                                    <Dropdown
                                        placeholder="Select an option"
                                        label="Year"
                                        options={this.state.yearOptions}
                                        onChange={this._onDDLYearChange.bind(this)}
                                        selectedKey={this.state.selYear}
                                        required={true}
                                    />
                                </div> : null}
                            {this.state.selDateRange == DateRangeType.Quarter ?
                                <div className="dateControls">
                                    <Dropdown
                                        placeholder="Select an option"
                                        label="Quarter"
                                        multiSelect
                                        options={this._quarterOptions}
                                        onChange={this._onDDLQuarterChange.bind(this)}
                                        selectedKeys={this.state.selQuarter}
                                        required={true}
                                    />
                                </div> : null}
                            {this.state.selDateRange == DateRangeType.Month ?
                                <div className="dateControls">
                                    <Dropdown
                                        placeholder="Select an option"
                                        label="Month"
                                        multiSelect
                                        options={this._monthOptions}
                                        onChange={this._onDDLMonthChange.bind(this)}
                                        selectedKeys={this.state.selMonth}
                                        required={true}
                                    />
                                </div> : null}
                        </div>
                        <div className="filterSectionRight">
                            <div className="mdApplyContainer">
                                <DefaultButton className='md_grey_button' text="Clear" onClick={this.onClearClick.bind(this)} />
                            </div>
                            <div className="mdApplyContainer">
                                <PrimaryButton className="md_red_button" text="Apply" disabled={this.state.disableApply} onClick={this.onApplyClick.bind(this)} />
                            </div>
                        </div>
                    </Stack.Item>
                </Stack>
            </div>
        );
    }

    private _onDDLRegionChange = (event, value): void => {
        this.setMultiselectState(ConfigKey.Region, "selRegion", value);
    }

    private _onDDLTAChange = (event, value): void => {
        this.setMultiselectState(ConfigKey.TherapeuticArea, "selTA", value);
    }

    private _onDDLRegTopicChange = (event, value): void => {
        this.setMultiselectState(ConfigKey.RegulatoryTopic, "selRegTopic", value);
    }

    private _onDDLDocTypeChange = (event, value): void => {
        this.setMultiselectState(ConfigKey.DocumentType, "selDocType", value);
    }

    private _onDDLAuthorChange = (event, value): void => {
        this.setMultiselectState('Author', "selAuthor", value);
    }

    private _onDDLDateRangeChange = (event, value): void => {
        this.setState({ selDateRange: value.key }, () => this.validate());
    }

    private _onDDLYearChange = (event, value): void => {
        this.setState({ selYear: value.key }, () => this.validate());
    }

    private _onDDLYearsChange = (event, value): void => {
        this.setMultiselectState('Year', "selYears", value);
    }

    private _onDDLQuarterChange = (event, value): void => {
        this.setMultiselectState('Quarter', "selQuarter", value);
    }

    private _onDDLMonthChange = (event, value): void => {
        this.setMultiselectState('Month', "selMonth", value);
    }

    private onApplyClick() {
        try {
            LoggerService.auditLog("Filter apply button clicked", 'FilterDashboardComp > onApplyClick');
            this.updateCharts();
        } catch (error) {
            LoggerService.errorLog(error, 'FilterDashboardComp > onApplyClick');
        }
    }

    private onClearClick() {
        try {
            LoggerService.auditLog("Filter clear button clicked", 'FilterDashboardComp > onClearClick');
            this._selRegionsObj = [];
            this._selTAObj = [];
            this._selRegTopicObj = [];
            this._selDocTypeObj = [];
            this.setState({
                selRegion: [], selTA: [], selRegTopic: [], selDocType: [], selAuthor: [], selDateRange: DateRangeType.Quarter,
                selYear: moment().year(), selYears: [], selQuarter: [moment().quarter()], selMonth: [moment().month()],
                selFromDate: moment().toDate(), selToDate: moment().toDate()
            }, () => this.updateCharts());
        } catch (error) {
            LoggerService.errorLog(error, 'FilterDashboardComp > onClearClick');
        }
    }

    private updateCharts = (): void => {
        try {

            let filtObj = {
                filtRegion: this._selRegionsObj,
                filtTA: this._selTAObj,
                filtRegTopic: this._selRegTopicObj,
                filtDocType: this._selDocTypeObj,
                filtAuthor: this.state.selAuthor,
                filtDateRange: this.state.selDateRange,
                filtFromDate: this.state.selFromDate,
                filtToDate: this.state.selToDate,
                filtYear: this.state.selDateRange == DateRangeType.Year ? this.state.selYears : this.state.selYear,
                filtQuarter: this.state.selQuarter,
                filtMonth: this.state.selMonth
            };
            this.props.updateCharts(filtObj);
        } catch (error) {
            LoggerService.errorLog(error, 'FilterDashboardComp > updateCharts');
        }
    }

    private onFromDateSelect = (date: Date | null | undefined): void => {
        this.setState({ selFromDate: date }, () => this.validate());
    }

    private onToDateSelect = (date: Date | null | undefined): void => {
        this.setState({ selToDate: date }, () => this.validate());
    }

    private getDistinctAuthorAndYear(): void {
        try {

            let arrYears: any[] = [];
            let arrAuthors: any[] = [];

            let alertDBListName = Common.getConfigValue(this.props.configData, ConfigType.Lists, ConfigKey.AlertsDatabase);
            let camlQ: string = `<View><Query>
              <Where>                     
              <Eq><FieldRef Name='ADBStatus'/><Value Type='Text'>${AlertStatus.Publish}</Value></Eq>            
              </Where></Query>
          <ViewFields><FieldRef Name='ID'/><FieldRef Name='ADBPublicationDate'/><FieldRef Name='ADBAuthor' /></ViewFields><ExpandUserField>True</ExpandUserField>
          </View>`;

            ListService.getDataFromLargeList(alertDBListName, camlQ).then(data => {
                if (data) {
                    data.Row.map(x => {

                        arrYears.push(moment(x.ADBPublicationDate).year());
                        arrAuthors.push({ key: x.ADBAuthor[0]["id"], text: x.ADBAuthor[0]["title"] });
                    });

                    arrYears.sort((a, b) => { return b - a; });
                    let unique = [];
                    let distinct = [];
                    arrYears.map(yrs => {
                        if (!unique[yrs]) {
                            distinct.push({ key: yrs, text: yrs });
                            unique[yrs] = 1;
                        }
                    });


                    let uniqueAuth = [];
                    let distinctAuth = [];
                    arrAuthors.map(auth => {
                        if (!uniqueAuth[auth.key]) {
                            distinctAuth.push({ key: auth.key, text: auth.text });
                            uniqueAuth[auth.key] = 1;
                        }
                    });
                    this.setState({
                        alertAuthorOptions: distinctAuth, yearOptions: distinct, selYears: [distinct[0].key], selYear: distinct[0].key, selQuarter: [moment().quarter()],
                        selMonth: [moment().month()]
                    });
                }
            }).catch(error => {
                LoggerService.errorLog(error, 'MetricsAndDashboard > getDistinctAuthorAndYear');
            });


        } catch (error) {
            LoggerService.errorLog(error, 'FilterDashboardComp > getDistinctAuthorAndYear');
        }
    }


    private setMultiselectState = (stateName: string, selStateName: string, ddlVal: any[]) => {
        try {
            let selIDs = this.state[selStateName];
            let keyIdx: number = -1;

            if (ddlVal["selected"]) {
                selIDs.push(ddlVal["key"]);
            } else {
                var keyIdx2 = selIDs.findIndex(x => x == ddlVal["key"]);
                if (keyIdx2 !== -1) {
                    selIDs.splice(keyIdx2, 1);
                }
            }
            selIDs.sort();
            switch (stateName) {
                case ConfigKey.Region:
                    if (ddlVal["selected"]) {
                        this._selRegionsObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
                    } else {
                        keyIdx = this._selRegionsObj.findIndex(x => x.key == ddlVal["key"]);
                        if (keyIdx !== -1) {
                            this._selRegionsObj.splice(keyIdx2, 1);
                        }
                    }
                    this.setState({ selRegion: [...selIDs] });
                    break;
                case ConfigKey.TherapeuticArea:
                    if (ddlVal["selected"]) {
                        this._selTAObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
                    } else {
                        keyIdx = this._selTAObj.findIndex(x => x.key == ddlVal["key"]);
                        if (keyIdx !== -1) {
                            this._selTAObj.splice(keyIdx2, 1);
                        }
                    }
                    this.setState({ selTA: [...selIDs] });
                    break;
                case ConfigKey.RegulatoryTopic:
                    if (ddlVal["selected"]) {
                        this._selRegTopicObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
                    } else {
                        keyIdx = this._selRegTopicObj.findIndex(x => x.key == ddlVal["key"]);
                        if (keyIdx !== -1) {
                            this._selRegTopicObj.splice(keyIdx2, 1);
                        }
                    }
                    this.setState({ selRegTopic: [...selIDs] });
                    break;
                case ConfigKey.DocumentType:
                    if (ddlVal["selected"]) {
                        this._selDocTypeObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
                    } else {
                        keyIdx = this._selDocTypeObj.findIndex(x => x.key == ddlVal["key"]);
                        if (keyIdx !== -1) {
                            this._selDocTypeObj.splice(keyIdx2, 1);
                        }
                    }
                    this.setState({ selDocType: [...selIDs] });
                    break;
                case "Author":
                    if (ddlVal["selected"]) {
                        this._selAuthorObj.push({ key: ddlVal["key"], text: ddlVal["text"] });
                    } else {
                        keyIdx = this._selAuthorObj.findIndex(x => x.key == ddlVal["key"]);
                        if (keyIdx !== -1) {
                            this._selAuthorObj.splice(keyIdx2, 1);
                        }
                    }
                    this.setState({ selAuthor: [...selIDs] });
                    break;
                case DateRangeType.Year:
                    if (this.state.selDateRange == DateRangeType.Year)
                        this.setState({ selYears: [...selIDs] }, () => this.validate());
                    else
                        this.setState({ selYear: selIDs }, () => this.validate());
                    break;
                case DateRangeType.Quarter:
                    this.setState({ selQuarter: [...selIDs] }, () => this.validate());
                    break;
                case DateRangeType.Month:
                    this.setState({ selMonth: [...selIDs] }, () => this.validate());
                    break;
                default:
                    break;
            }
        } catch (error) {
            LoggerService.errorLog(error, 'FilterDashboardComp > setMultiselectState');
        }
    }

    private validate = (): void => {
        try {
            let isInvalid: boolean = false;
            switch (this.state.selDateRange) {
                case DateRangeType.DateRange:
                    if (moment(this.state.selToDate).isBefore(moment(this.state.selFromDate)))
                        isInvalid = true;
                    break;
                case DateRangeType.Year:
                    if (this.state.selYears.length == 0)
                        isInvalid = true;
                    break;
                case DateRangeType.Quarter:
                    if (this.state.selYear <= 0 || this.state.selQuarter.length <= 0)
                        isInvalid = true;
                    break;
                case DateRangeType.Month:
                    if (this.state.selYear <= 0 || this.state.selMonth.length <= 0)
                        isInvalid = true;
                    break;
                default:
                    break;
            }
            this.setState({ disableApply: isInvalid });

        } catch (error) {
            LoggerService.errorLog(error, 'FilterDashboardComp > validate');
        }
    }

    private getAlertSubscriptionSummary(): Promise<any> {
        try {
            return new Promise<any>((resolve, reject) => {
                ListService.GetAllData(ConfigKey.AlertsSubscriptionSummary).then(response => {
                    if (response) {
                        let metricsData = [];
                        response.map((item) => {

                            let titleVal = item['Title'];
                            let countVal = item['ASCount'];
                            this.setAlertSubscriptionSummaryState(titleVal, countVal);

                            metricsData.push({
                                title: item['Title'], count: item['ASCount']
                            });
                        });
                        resolve(metricsData);
                    }
                }).catch(error => {
                    reject(error);
                });
            });
        } catch (error) {
            LoggerService.errorLog(error, 'FilterDashboardComp > getAlertSubscriptionSummary');
        }
    }

    private setAlertSubscriptionSummaryState(titleVal: string, count: number) {
        try {

            switch (titleVal) {
                case "Overall Alerts": this.setState({ alertCount: count });
                    break;

                case "Subscribed Users": this.setState({ subsCount: count });
                    break;

                case "Daily Subscriptions": this.setState({ dailySubsCount: count });
                    break;

                case "Weekly Subscriptions": this.setState({ weeklySubsCount: count });
                    break;

                case "Immediate Subscriptions": this.setState({ immediateSubsCount: count });
                    break;

                default: break;

            }
        }
        catch (error) {
            LoggerService.errorLog(error, 'setAlertSubscriptionSummaryState > setAlertSubscriptionSummaryState');
        }
    }
}
