declare interface IMetricsAndDashboardWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MetricsAndDashboardWebPartStrings' {
  const strings: IMetricsAndDashboardWebPartStrings;
  export = strings;
}
