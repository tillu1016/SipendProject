export enum UserAlertsLogFrequency {
    Immediately = "Immediately",
    Daily = "Daily",
    Weekly = "Weekly"
}

export enum UserAlertsLogStatus {
    New = "New",
    EmailSent = "Email Sent"
}

export interface IUserAlertsLog {
    id: number;
    title: string;
    alertItemId: number;
    frequency: string;
    status: string;
    users: string;
}