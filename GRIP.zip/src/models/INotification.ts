export enum NotificationType {
    info = 1,
    warn,
    error,
    success
}

export interface INotification {
    type: NotificationType;
    message: string;
}