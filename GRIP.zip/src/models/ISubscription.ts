export enum AlertFrequency {
  Immediate = "Immediate",
  Daily = "Daily",
  Weekly = "Weekly"
}

export enum DayOfTheWeek {
  Monday = "Monday",
  Tuesday = "Tuesday",
  Wednesday = "Wednesday",
  Thursday = "Thursday",
  Friday = "Friday",
  Saturday = "Saturday",
  Sunday = "Sunday"
}

export interface ISubscription {
  id: number;
  title: string;
  region: string;
  regulatoryTopic: string;
  therapeuticArea: string;
  subscriber: string;
  subscriberId: number;
  subscriberEmail: string;
  onBehalf: string;
  onBehalfId: number;
  onBehalfEmail: string;
  frequency: string;
  //dayOfTheWeek: string;
  createdDate: Date;
  count: number;
}

export interface IUser {
  id: number;
  title: string;
  email: string;
}
