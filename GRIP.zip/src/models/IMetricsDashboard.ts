export enum DateRangeType {
    DateRange = "Date Range",
    Year = "Year",
    Quarter = "Quarter",
    Month = "Month",
}

export enum CategoryType {
    Region = "Region",
    TherapeuticArea = "TherapeuticArea",
    RegulatoryTopic = "RegulatoryTopic",
    DocumentType = "DocumentType",
    Author = "Author",
}