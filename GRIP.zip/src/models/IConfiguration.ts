export enum ConfigType {
    Roles = "Roles",
    Taxonomy = "Taxonomy",
    Lists = "Lists",
    Page = "Page",
    ImagePath = "ImagePath",
    AboutUs = "AboutUs",
    Grid = "Grid",
    Email = "Email",
    HomePage = "HomePage",
    Subscription = "Subscription",
    API = "API"
}

export enum ConfigKey {
    Administrator = "Administrator",
    User = "User",
    TermStoreId = "TermStoreId",
    DocumentType = "DocumentType",
    Region = "Region",
    RegulatoryTopic = "RegulatoryTopic",
    TherapeuticArea = "TherapeuticArea",
    Subscriber = "Subscriber",
    AlertsDatabase = "AlertsDatabase",
    Configurations = "Configurations",
    Subscriptions = "Subscriptions",
    SubscriptionsDatabase = "SubscriptionsDatabase",
    AlertsDatabaseComments = "AlertsDatabaseComments",
    EmailTemplates = "EmailTemplates",
    UserAlertsLog = "UserAlertsLog",
    ErrorLog = "ErrorLog",
    AuditLog = "AuditLog",
    OurNetwork = "OurNetwork",
    AlertAnalytics = "AlertAnalytics",
    ManageAlerts = "ManageAlerts",
    ViewAlert = "ViewAlert",
    AddEditAlerts = "AddEditAlerts",
    MetricsAndDashboard = "MetricsAndDashboard",
    AlertFrequency = "AlertFrequency",
    DayOfTheWeek = "DayOfTheWeek",
    AlertsSubmitRItoTeam = "SubmitRItoTeam",
    ManageSubmitRItoTeam = "ManageSubmitRItoTeam",
    ViewSubmitRItoTeam = "ViewSubmitRItoTeam",
    ManageSubscriptions = "ManageSubscriptions",
    AddEditSubmitRItoTeam = "AddEditSubmitRItoTeam",
    AboutUsPage = "AboutUs",
    PrivacyPolicy = "PrivacyPolicy",
    Vision = "Vision",
    Mission = "Mission",
    PageSize = "PageSize",
    GRIPLogo = "GRIPLogo",
    ImmediateEmailBanner = "ImmediateEmailBanner",
    FooterLinks = "FooterLinks",
    BannerHTML = "BannerHTML",
    ImageUploadPath = "ImageUploadPath",
    DocUploadPath = "DocUploadPath",
    SubscriptionShowMessage = "SubscriptionShowMessage",
    SubscriptionDailyMessage = "SubscriptionDailyMessage",
    SubscriptionWeeklyMessage = "SubscriptionWeeklyMessage",
    TAOrder = "TAOrder",
    Path = "Path",
    AlertsSubscriptionSummary = "Alerts Subscription Summary",
    SubscribersEMailLog = "SubscribersEMailLog"
}

export interface IConfiguration {
    title: string;
    key: string;
    value: string;
    richTextValue: string;
}
