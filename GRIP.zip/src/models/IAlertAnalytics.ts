export enum PageName {
    Home = "Home",
    AboutUs = "About Us",
    ManageAlerts = "Manage Alerts",
    ManageSubscriptions = "Manage Subscriptions",
    ManageSubmitRItoTeam = "Manage Submit RI To Team",
    Search = "Search",
    Alerts = "Alerts"
}

export interface IAlertAnalytics {
    id: number;
    title: string;
    isAdmin: boolean;
    currentURL: string;
    sourceURL: string;
    alertId: number;
    isFirstVisit: boolean;
}