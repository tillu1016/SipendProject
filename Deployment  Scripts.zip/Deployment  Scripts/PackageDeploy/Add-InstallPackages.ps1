﻿Param(
 [Parameter(Mandatory=$true)]
 [string]$siteCollectionURL,
 [Parameter(Mandatory=$true)]
 [string]$appCatalogURL
 )

$solPackages = Get-ChildItem D:\Deployment -Recurse *.sppkg
$currentTime= $(get-date).ToString("yyyyMMddHHmmss")
$logFile = "\$currentTime LogReport.csv" 
$csvInput = Import-Csv D:\Deployment\AddInstallWebparts.csv
 
 function AddApp  
{ 
Connect-PnPOnline -URL $appCatalogURL -UseWebLogin
foreach ($solution in $solPackages){

$packagepath=$solution.Name

Write-Host $packagepath
try  
        {  
            # Add the app to the app catalog and publish it             
            Add-PnPApp -Path $packagepath -Scope Site -Overwrite -Publish                                 
           
        }  
        Catch  
        {   
            add-content $logFile  "$($siteCollectionURL),No , $($_.Exception.Message)"   
            Continue;  
        } 

}
 Disconnect-PnPOnline  
 }

function InstallApp  
{  
Connect-PnPOnline -URL $siteCollectionURL -UseWebLogin
foreach ($input in $csvInput) {
        
        try  
        {  
        Write-Host $input.WebPartName
            
            # Get the app which is published in the site collection app catalog  
            $app=Get-PnPApp -Scope Site | Where Title -EQ $input.WebPartName
            # Install the app at the root site  
            Install-PnpApp -Identity $app.Id  -Scope Site   
        }  
        Catch  
        {   
            add-content $logFile  "$($siteCollectionURL),No , $($_.Exception.Message)"   
            Continue;  
        }  
        }
         Disconnect-PnPOnline
        
} 
AddApp   
InstallApp   