Param(
 [Parameter(Mandatory=$true)]
 [string]$SiteUrl,
 [Parameter(Mandatory=$false)]
 [string]$XMLTermsFileName = "_ListSchema.xml"
 )
 
 
 Set-Location $PSScriptRoot

 function LoadAndConnectToSharePoint($url)
 {
	
  ##Using PnP library
  Connect-PnPOnline -Url $SiteUrl -Credentials (Get-Credential) #-UseWebLogin
  #Connect-SPOnline -Url $SiteUrl -CurrentCredentials
  #$spContext =  Get-SPOContext
  $spContext =  Get-PnPContext
  return $spContext
}

$Context = LoadAndConnectToSharePoint  $SiteUrl

Write-Host "Creating List from Template..."
Apply-PnPProvisioningTemplate -Path $XMLTermsFileName


